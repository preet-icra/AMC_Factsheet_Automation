from __future__ import annotations

import io
import re
import tempfile
import time
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from time import perf_counter

import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
TOP_HOLDING_LIMIT = 10

# PowerPoint PpBorderType values.
PP_BORDER_TOP = 1
PP_BORDER_LEFT = 2
PP_BORDER_BOTTOM = 3
PP_BORDER_RIGHT = 4

RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
COM_RETRY_ATTEMPTS = 8
COM_RETRY_INITIAL_DELAY_SECONDS = 0.75
COM_RETRY_MAX_DELAY_SECONDS = 4.0

EXCEL_HEADER_ALIASES = {
    "instrument": {
        "instrument type issuer name",
        "instrument type/issuer name",
        "instrument issuer name",
        "issuer name",
        "instrument name",
        "security name",
    },
    "nav_percent": {
        "% of nav",
        "% of net asset",
        "% of net assets",
        "percentage of nav",
        "percent of nav",
    },
}

PPT_HEADER_ALIASES = {
    "instrument": {
        "top 10 holdings",
        "instrument",
        "instrument name",
        "security name",
        "holding",
        "holdings",
    },
    "nav_percent": {
        "% to net assets",
        "% of net assets",
        "% of net asset",
        "% of nav",
        "% to nav",
    },
}

# Add genuine Excel-to-PowerPoint naming differences here.
# Left side is the Excel fund name; right side is FundDetails in PowerPoint.
PORTFOLIO_FUND_ALIASES = {
    # Existing historical name difference.
    "Axis Focused 25 Fund": "Axis Focused Fund",

    # Shortened names used in the workbook INDEX and fund worksheets.
    "Axis CRISIL IBX50:50 Gilt Plus SDL Sep 2027 Index Fund": (
        "AXIS CRISIL IBX 50:50 GILT PLUS SDL "
        "SEPTEMBER 2027 INDEX FUND"
    ),
    "Axis CRISIL-IBX AAA Bond Fin Ser. Sep27 Index Fund": (
        "AXIS CRISIL-IBX AAA BOND FINANCIAL "
        "SERVICES - SEP 2027 INDEX FUND"
    ),
    "Axis CRISIL-IBX AAA Bond NBFC-HFC-Jun27 Index Fund": (
        "AXIS CRISIL-IBX AAA BOND NBFC-HFC - "
        "JUN 2027 INDEX FUND"
    ),
    "Axis CRISIL-IBX Fin. Svcs 3-6 Mon Debt Index Fund": (
        "AXIS CRISIL-IBX FINANCIAL SERVICES "
        "3-6 MONTHS DEBT INDEX FUND"
    ),
}

# Summary/category labels that must never be treated as portfolio instruments.
SUMMARY_LABELS = {
    "equity",
    "debt",
    "debt instruments",
    "exchange traded fund",
    "exchange traded funds",
    "mutual fund units",
    "money market instruments",
    "government securities",
    "treps",
    "cash",
    "cash and cash equivalents",
    "cash and other current assets",
    "debt cash and other current assets",
    "grand total",
    "total",
    "net assets",
    "composition by asset",
    "composition by sector",
}

IGNORED_SHEET_NAMES = {
    "index",
    "contents",
    "cover",
    "summary",
}


@dataclass(frozen=True)
class PortfolioHolding:
    instrument: str
    nav_percent: Decimal
    source_row: int


@dataclass(frozen=True)
class PortfolioRecord:
    excel_fund_name: str
    canonical_fund_name: str
    holdings: tuple[PortfolioHolding, ...]
    sheet_name: str
    header_row: int


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
        "\r": " ",
        "\n": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _canonical_fund_name(value: object) -> str:
    clean_name = _clean_text(value)
    aliases = {
        _text_key(excel_name): ppt_name
        for excel_name, ppt_name in PORTFOLIO_FUND_ALIASES.items()
    }
    return aliases.get(_text_key(clean_name), clean_name)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _header_type(value: object, aliases: dict[str, set[str]]) -> str | None:
    key = _text_key(value)
    for header_type, names in aliases.items():
        if key in {_text_key(name) for name in names}:
            return header_type
    return None


def _find_portfolio_header(worksheet) -> tuple[int, dict[str, int]] | None:
    """Find Instrument and % of NAV columns without fixed cell addresses."""
    max_scan_row = min(worksheet.max_row, 80)
    max_scan_column = min(worksheet.max_column, 30)

    for row in range(1, max_scan_row + 1):
        columns: dict[str, int] = {}
        for column in range(1, max_scan_column + 1):
            header_type = _header_type(
                worksheet.cell(row, column).value,
                EXCEL_HEADER_ALIASES,
            )
            if header_type and header_type not in columns:
                columns[header_type] = column

        if set(EXCEL_HEADER_ALIASES).issubset(columns):
            return row, columns

    return None


def _looks_like_fund_name(value: object) -> bool:
    text = _clean_text(value)
    key = _text_key(text)
    text_lower = text.casefold()
    contains_fund_identifier = (
        "fund" in text_lower
        or re.search(r"\bfof\b", text_lower) is not None
    )
    return (
        bool(text)
        and contains_fund_identifier
        and key not in {_text_key(label) for label in SUMMARY_LABELS}
        and not key.startswith("fundmanager")
    )


def _find_fund_name(
    worksheet,
    header_row: int,
    instrument_column: int,
) -> str:
    """Find the fund heading above the portfolio header row."""
    # First inspect the cells above the instrument column, matching the layout
    # shown in the workbook image where the fund name appears above the header.
    for row in range(header_row - 1, max(0, header_row - 12), -1):
        value = worksheet.cell(row, instrument_column).value
        if _looks_like_fund_name(value):
            return _clean_text(value)

    # Then inspect all cells above the header in case the heading is merged or
    # placed in a different column.
    for row in range(header_row - 1, max(0, header_row - 15), -1):
        for column in range(1, min(worksheet.max_column, 12) + 1):
            value = worksheet.cell(row, column).value
            if _looks_like_fund_name(value):
                return _clean_text(value)

    raise ValueError(
        f"Fund name could not be found above the portfolio header in "
        f"worksheet '{worksheet.title}'."
    )


def _to_nav_percent(value: object, number_format: str = "") -> Decimal | None:
    """Convert Excel numeric or text percentages into percentage points."""
    if value is None:
        return None

    text = _clean_text(value)
    if text.casefold() in {"", "na", "n/a", "-", "nil"}:
        return None

    try:
        if isinstance(value, str):
            normalized = value.strip().replace(",", "")
            if normalized.endswith("%"):
                return Decimal(normalized[:-1].strip())
            number = Decimal(normalized)
        else:
            number = Decimal(str(value))
    except InvalidOperation:
        return None

    # A percentage-formatted Excel value such as 9.63% is stored as 0.0963.
    if "%" in str(number_format):
        number *= Decimal("100")

    return number


def _is_summary_or_invalid_instrument(value: object) -> bool:
    text = _clean_text(value)
    key = _text_key(text)

    if not text:
        return True
    if key in {_text_key(label) for label in SUMMARY_LABELS}:
        return True
    if text.upper() == text and len(text.split()) <= 6 and not any(
        character.isdigit() for character in text
    ):
        # This catches category rows such as EQUITY while retaining normal
        # title-cased company and instrument names.
        return True
    return False


def _read_sheet_record(worksheet, logger) -> PortfolioRecord | None:
    header_result = _find_portfolio_header(worksheet)
    if header_result is None:
        logger.info(
            "PORTFOLIO_SHEET_SKIPPED | sheet=%s | reason=headers_not_found",
            worksheet.title,
        )
        return None

    header_row, columns = header_result
    fund_name = _find_fund_name(
        worksheet,
        header_row,
        columns["instrument"],
    )

    holdings: list[PortfolioHolding] = []
    empty_streak = 0

    for row in range(header_row + 1, worksheet.max_row + 1):
        instrument_cell = worksheet.cell(
            row,
            columns["instrument"],
        )
        instrument = _clean_text(instrument_cell.value)
        nav_cell = worksheet.cell(row, columns["nav_percent"])
        nav_percent = _to_nav_percent(
            nav_cell.value,
            nav_cell.number_format,
        )

        if not instrument and nav_percent is None:
            empty_streak += 1
            if empty_streak >= 8 and holdings:
                break
            continue

        empty_streak = 0

        # In the source workbook, category/section rows such as EQUITY,
        # Certificate of Deposit, Commercial Paper, Corporate Bond, and
        # Government Bond are bold. Those rows are aggregate labels, not
        # individual holdings, so they must never consume a Top 10 position.
        if bool(instrument_cell.font.bold):
            logger.info(
                "PORTFOLIO_BOLD_ROW_SKIPPED | sheet=%s | row=%s | "
                "text=%s",
                worksheet.title,
                row,
                instrument,
            )
            continue

        if _is_summary_or_invalid_instrument(instrument):
            continue
        if nav_percent is None or nav_percent <= 0:
            continue

        holdings.append(
            PortfolioHolding(
                instrument=instrument,
                nav_percent=nav_percent,
                source_row=row,
            )
        )

        # Preserve the order shown in Excel. Stop as soon as the first ten
        # genuine instrument rows have been collected. Do not continue into
        # later categories, Net Current Assets, totals, or summary sections.
        if len(holdings) >= TOP_HOLDING_LIMIT:
            break

    if not holdings:
        logger.warning(
            "PORTFOLIO_SHEET_SKIPPED | sheet=%s | fund=%s | "
            "reason=no_valid_holdings",
            worksheet.title,
            fund_name,
        )
        return None

    # Holdings are already in worksheet order and are capped at ten.
    return PortfolioRecord(
        excel_fund_name=fund_name,
        canonical_fund_name=_canonical_fund_name(fund_name),
        holdings=tuple(holdings),
        sheet_name=worksheet.title,
        header_row=header_row,
    )


def read_portfolio_excel(
    excel_bytes: bytes,
    logger,
    source_file: str = "",
) -> dict[str, PortfolioRecord]:
    """Scan all worksheets and return the first ten valid holdings by fund."""
    logger.info(
        "PORTFOLIO_FILE_START | file=%s | bytes=%s",
        source_file or "uploaded.xlsx",
        len(excel_bytes),
    )

    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )

    records: dict[str, PortfolioRecord] = {}

    for worksheet in workbook.worksheets:
        if _text_key(worksheet.title) in {
            _text_key(name) for name in IGNORED_SHEET_NAMES
        }:
            logger.info(
                "PORTFOLIO_SHEET_SKIPPED | sheet=%s | reason=index_sheet",
                worksheet.title,
            )
            continue

        try:
            record = _read_sheet_record(worksheet, logger)
        except ValueError as error:
            logger.warning(
                "PORTFOLIO_SHEET_SKIPPED | sheet=%s | reason=%s",
                worksheet.title,
                error,
            )
            continue

        if record is None:
            continue

        key = _fund_key(record.canonical_fund_name)
        existing = records.get(key)

        if existing is None:
            records[key] = record
        else:
            # Prefer the sheet with more valid top holdings if duplicate fund
            # sheets exist in the workbook.
            if len(record.holdings) > len(existing.holdings):
                records[key] = record

        logger.info(
            "PORTFOLIO_FUND_FOUND | sheet=%s | fund=%s | holdings=%s",
            record.sheet_name,
            record.excel_fund_name,
            len(record.holdings),
        )

    if not records:
        raise ValueError(
            "No portfolio fund records were found. Expected each fund sheet "
            "to contain Instrument Type/Issuer Name and % of NAV headers."
        )

    logger.info(
        "PORTFOLIO_FILE_COMPLETE | sheets=%s | funds=%s",
        len(workbook.worksheets),
        len(records),
    )
    return records


def format_nav_percent(value: Decimal | None) -> str:
    if value is None:
        return ""
    rounded = value.quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )
    return f"{rounded:.2f}%"


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if shape.Type == 6:  # msoGroup
            for index in range(1, shape.GroupItems.Count + 1):
                text = _shape_text(shape.GroupItems.Item(index))
                if text:
                    parts.append(text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    cell = table.Cell(row, column).Shape
                    if cell.HasTextFrame and cell.TextFrame.HasText:
                        parts.append(cell.TextFrame.TextRange.Text)
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""

    return " ".join(
        _clean_text(part)
        for part in parts
        if _clean_text(part)
    )


def _map_portfolio_table(shape) -> tuple[int, dict[str, int]]:
    if not shape.HasTable:
        raise ValueError("PortfolioTable exists but is not a PowerPoint table.")

    table = shape.Table
    for row in range(1, table.Rows.Count + 1):
        columns: dict[str, int] = {}
        for column in range(1, table.Columns.Count + 1):
            cell = table.Cell(row, column).Shape
            text = ""
            if cell.HasTextFrame and cell.TextFrame.HasText:
                text = cell.TextFrame.TextRange.Text

            header_type = _header_type(text, PPT_HEADER_ALIASES)
            if header_type and header_type not in columns:
                columns[header_type] = column

        if set(PPT_HEADER_ALIASES).issubset(columns):
            return row, columns

    raise ValueError(
        "PortfolioTable headers could not be mapped. Expected Top 10 "
        "Holdings and % to Net Assets."
    )


def _capture_line_format(line) -> dict[str, object]:
    """Capture available PowerPoint LineFormat properties safely."""
    result: dict[str, object] = {}
    for attribute in (
        "Visible",
        "Weight",
        "Transparency",
        "DashStyle",
        "Style",
    ):
        try:
            result[attribute] = getattr(line, attribute)
        except Exception:
            pass
    try:
        result["ForeColor.RGB"] = line.ForeColor.RGB
    except Exception:
        pass
    return result


def _apply_line_format(line, values: dict[str, object]) -> None:
    """Restore a captured PowerPoint LineFormat without failing the workflow."""
    for attribute, value in values.items():
        try:
            if attribute == "ForeColor.RGB":
                line.ForeColor.RGB = value
            else:
                setattr(line, attribute, value)
        except Exception:
            pass


def _capture_outer_border_format(table) -> dict[str, object]:
    """Capture the template table's outer border before rows are deleted."""
    last_row = table.Rows.Count
    last_column = table.Columns.Count
    bottom = {
        column: _capture_line_format(
            table.Cell(last_row, column).Borders.Item(PP_BORDER_BOTTOM)
        )
        for column in range(1, last_column + 1)
    }
    return {
        "bottom": bottom,
        "bottom_left": _capture_line_format(
            table.Cell(last_row, 1).Borders.Item(PP_BORDER_LEFT)
        ),
        "bottom_right": _capture_line_format(
            table.Cell(last_row, last_column).Borders.Item(PP_BORDER_RIGHT)
        ),
    }


def _restore_outer_border_format(
    table,
    header_row: int,
    border_format: dict[str, object],
) -> None:
    """Restore the bottom, lower-left, and lower-right outer table borders."""
    if table.Rows.Count <= header_row:
        return

    last_row = table.Rows.Count
    last_column = table.Columns.Count
    for column in range(1, last_column + 1):
        values = border_format.get("bottom", {}).get(column, {})
        _apply_line_format(
            table.Cell(last_row, column).Borders.Item(PP_BORDER_BOTTOM),
            values,
        )

    _apply_line_format(
        table.Cell(last_row, 1).Borders.Item(PP_BORDER_LEFT),
        border_format.get("bottom_left", {}),
    )
    _apply_line_format(
        table.Cell(last_row, last_column).Borders.Item(PP_BORDER_RIGHT),
        border_format.get("bottom_right", {}),
    )


def _copy_row_format(table, source_row: int, target_row: int) -> None:
    """Copy basic cell formatting from the template's last data row."""
    for column in range(1, table.Columns.Count + 1):
        source = table.Cell(source_row, column).Shape
        target = table.Cell(target_row, column).Shape
        try:
            target.Fill.Visible = source.Fill.Visible
            target.Fill.ForeColor.RGB = source.Fill.ForeColor.RGB
        except Exception:
            pass
        try:
            target.TextFrame.TextRange.Font.Name = (
                source.TextFrame.TextRange.Font.Name
            )
            target.TextFrame.TextRange.Font.Size = (
                source.TextFrame.TextRange.Font.Size
            )
            target.TextFrame.TextRange.Font.Bold = (
                source.TextFrame.TextRange.Font.Bold
            )
            target.TextFrame.TextRange.Font.Color.RGB = (
                source.TextFrame.TextRange.Font.Color.RGB
            )
            target.TextFrame.TextRange.ParagraphFormat.Alignment = (
                source.TextFrame.TextRange.ParagraphFormat.Alignment
            )
        except Exception:
            pass


def _resize_data_rows(
    table,
    header_row: int,
    required_rows: int,
) -> None:
    """Resize PortfolioTable to the exact number of available holdings."""
    required_rows = max(0, min(TOP_HOLDING_LIMIT, required_rows))
    existing_rows = table.Rows.Count - header_row
    outer_border_format = _capture_outer_border_format(table)

    while existing_rows < required_rows:
        source_row = table.Rows.Count
        table.Rows.Add()
        new_row = table.Rows.Count
        if source_row > header_row:
            _copy_row_format(table, source_row, new_row)
        existing_rows += 1

    # Delete all unused blank rows when fewer than ten holdings exist.
    while existing_rows > required_rows:
        table.Rows.Item(table.Rows.Count).Delete()
        existing_rows -= 1

    # Row deletion in PowerPoint can remove the lower table border. Restore
    # the original template border on the new final data row.
    _restore_outer_border_format(
        table,
        header_row,
        outer_border_format,
    )


def _update_portfolio_table(shape, record: PortfolioRecord) -> int:
    header_row, columns = _map_portfolio_table(shape)
    table = shape.Table
    required_rows = len(record.holdings)
    _resize_data_rows(table, header_row, required_rows)

    changed = 0
    for position, holding in enumerate(record.holdings):
        target_row = header_row + position + 1
        instrument = holding.instrument
        nav_percent = format_nav_percent(holding.nav_percent)

        table.Cell(
            target_row,
            columns["instrument"],
        ).Shape.TextFrame.TextRange.Text = instrument
        table.Cell(
            target_row,
            columns["nav_percent"],
        ).Shape.TextFrame.TextRange.Text = nav_percent
        changed += 2

    return changed


def _com_error_code(error: Exception) -> int | None:
    hresult = getattr(error, "hresult", None)
    if isinstance(hresult, int):
        return hresult
    if getattr(error, "args", None) and isinstance(error.args[0], int):
        return error.args[0]
    return None


def _is_retryable_com_error(error: Exception) -> bool:
    return _com_error_code(error) in {
        RPC_E_CALL_REJECTED,
        RPC_E_SERVERCALL_RETRYLATER,
    }


def _retry_com_call(operation_name: str, operation, logger, attempts: int = COM_RETRY_ATTEMPTS):
    delay = COM_RETRY_INITIAL_DELAY_SECONDS
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            if not _is_retryable_com_error(error) or attempt >= attempts:
                raise
            logger.warning(
                "PORTFOLIO_COM_RETRY | operation=%s | attempt=%s/%s | "
                "hresult=%s | wait_seconds=%.2f",
                operation_name,
                attempt,
                attempts,
                _com_error_code(error),
                delay,
            )
            time.sleep(delay)
            delay = min(delay * 1.7, COM_RETRY_MAX_DELAY_SECONDS)


def _start_powerpoint(logger):
    try:
        return _retry_com_call(
            "DispatchEx PowerPoint.Application",
            lambda: win32com.client.DispatchEx("PowerPoint.Application"),
            logger,
        )
    except pywintypes.com_error as first_error:
        logger.warning(
            "PORTFOLIO_NEW_POWERPOINT_FAILED | hresult=%s | "
            "fallback=existing_instance",
            _com_error_code(first_error),
        )
        try:
            return _retry_com_call(
                "Dispatch PowerPoint.Application",
                lambda: win32com.client.Dispatch("PowerPoint.Application"),
                logger,
                attempts=4,
            )
        except pywintypes.com_error as second_error:
            raise RuntimeError(
                "PowerPoint rejected the portfolio automation request. Close "
                "open PowerPoint dialogs or Protected View prompts and retry."
            ) from second_error


def apply_portfolio(
    current_ppt_bytes: bytes,
    portfolio_excel_bytes: bytes,
    fund_object: str,
    portfolio_table_object: str,
    logger,
    strict: bool = False,
    source_file: str = "",
) -> bytes:
    """Match FundDetails and update PortfolioTable in worksheet order."""
    records = read_portfolio_excel(
        portfolio_excel_bytes,
        logger,
        source_file=source_file,
    )

    logger.info(
        "PORTFOLIO_START | ppt_bytes=%s | records=%s | strict=%s",
        len(current_ppt_bytes),
        len(records),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None
    operation_start = perf_counter()

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "portfolio_input.pptx"
            output_path = Path(temp_dir) / "portfolio_output.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = _start_powerpoint(logger)
            _retry_com_call(
                "set DisplayAlerts",
                lambda: setattr(powerpoint, "DisplayAlerts", False),
                logger,
            )

            presentation = _retry_com_call(
                "open portfolio presentation",
                lambda: powerpoint.Presentations.Open(
                    str(input_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            updated_slides = 0
            skipped_slides = 0
            total_changes = 0

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                table_shape = find_shape_recursive(
                    slide.Shapes,
                    portfolio_table_object,
                )

                # Only slides with PortfolioTable are portfolio slides. This
                # prevents unnecessary FundDetails processing on other slides.
                if table_shape is None:
                    continue

                fund_shape = find_shape_recursive(slide.Shapes, fund_object)
                if fund_shape is None:
                    message = (
                        f"Object '{fund_object}' missing on slide "
                        f"{slide_number}."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "PORTFOLIO_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped_slides += 1
                    continue

                ppt_fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(ppt_fund_name))

                if record is None:
                    message = (
                        f"No portfolio worksheet matched PowerPoint fund "
                        f"'{ppt_fund_name}'."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "PORTFOLIO_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped_slides += 1
                    continue

                try:
                    changes = _update_portfolio_table(table_shape, record)
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "PORTFOLIO_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        ppt_fund_name,
                        error,
                    )
                    skipped_slides += 1
                    continue

                updated_slides += 1
                total_changes += changes
                logger.info(
                    "PORTFOLIO_UPDATED | slide=%s | fund=%s | sheet=%s | "
                    "holdings=%s | changes=%s",
                    slide_number,
                    ppt_fund_name,
                    record.sheet_name,
                    len(record.holdings),
                    changes,
                )

            _retry_com_call(
                "save portfolio presentation",
                lambda: presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            _retry_com_call(
                "close portfolio presentation",
                presentation.Close,
                logger,
                attempts=4,
            )
            presentation = None
            output = output_path.read_bytes()

            logger.info(
                "PORTFOLIO_COMPLETE | slides_updated=%s | "
                "slides_skipped=%s | changes=%s | bytes=%s | "
                "seconds=%.3f",
                updated_slides,
                skipped_slides,
                total_changes,
                len(output),
                perf_counter() - operation_start,
            )
            return output

    except Exception:
        logger.exception("PORTFOLIO_FAILED")
        raise

    finally:
        if presentation is not None:
            try:
                _retry_com_call(
                    "cleanup close portfolio presentation",
                    presentation.Close,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass
        if powerpoint is not None:
            try:
                _retry_com_call(
                    "quit PowerPoint",
                    powerpoint.Quit,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass
        presentation = None
        powerpoint = None
        pythoncom.CoUninitialize()
