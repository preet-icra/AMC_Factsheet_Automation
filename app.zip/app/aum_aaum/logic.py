from __future__ import annotations

import io
import re
import tempfile
import time
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize, shape_texts

try:
    from config import AUM_FUND_NAME_ALIASES as CONFIG_AUM_ALIASES
except ImportError:
    CONFIG_AUM_ALIASES: dict[str, str] = {}


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
RUPEES_PER_CRORE = Decimal("10000000")

# Excel Name of the Scheme -> PowerPoint FundDetails name.
BUILTIN_AUM_FUND_NAME_ALIASES: dict[str, str] = {
    "AXIS NIFTY MIDCAP 50 INDEX FUND": "Axis Nifty Midcap 50 Index Fund",
    "AXIS NIFTY SMALLCAP 50 INDEX FUND": "Axis Nifty Smallcap 50 Index Fund",
    "Axis Children’s Fund": "Axis Children's Fund",
    "Axis CRISIL IBX50:50 Gilt Plus SDL June 2028 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL June 2028 Index Fund"
    ),
    "Axis CRISIL IBX50:50 Gilt Plus SDL Sep 2027 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL September 2027 Index Fund"
    ),
    "Axis CRISIL IBX AAA Bond NBFC Jun 2027 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC - Jun 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond Fin Ser. Sep27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond Financial Services - Sep 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond NBFC-HFC-Jun27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC-HFC - JUN 2027 Index Fund"
    ),
    "Axis CRISIL-IBX Fin. Svcs 3-6 Mon Debt Index Fund": (
        "Axis CRISIL-IBX Financial Services 3-6 Months Debt Index Fund"
    ),
}

AUM_FUND_NAME_ALIASES: dict[str, str] = {
    **BUILTIN_AUM_FUND_NAME_ALIASES,
    **CONFIG_AUM_ALIASES,
}

NORMALIZED_AUM_ALIASES = {
    normalize(source): normalize(target)
    for source, target in AUM_FUND_NAME_ALIASES.items()
}


@dataclass(frozen=True)
class AumRecord:
    scheme_name: str
    canonical_scheme_name: str
    aum_rupees: Decimal
    monthly_aaum_rupees: Decimal
    aum_crore: Decimal
    monthly_aaum_crore: Decimal
    sheet_name: str
    source_row: int

    # Backward-compatible properties for callers using record.aum/record.aaum.
    @property
    def aum(self) -> Decimal:
        return self.aum_crore

    @property
    def aaum(self) -> Decimal:
        return self.monthly_aaum_crore


def _clean_text(value: object) -> str:
    # Preserve numeric zero; ``value or ""`` would incorrectly turn 0 into
    # blank text and break valid zero-AUM schemes.
    if value is None:
        return ""
    return " ".join(str(value).replace("\xa0", " ").split())


def _to_decimal(value: object, field_name: str, row_number: int) -> Decimal:
    if value in (None, ""):
        raise ValueError(
            f"Blank {field_name} value found on Excel row {row_number}."
        )
    text = _clean_text(value).replace(",", "")
    try:
        return Decimal(text)
    except InvalidOperation as error:
        raise ValueError(
            f"Invalid {field_name} value on Excel row {row_number}: {value!r}."
        ) from error


def rupees_to_crore(value: Decimal) -> Decimal:
    return value / RUPEES_PER_CRORE


def format_crore(value: Decimal) -> str:
    rounded = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return f"{rounded:,.2f}"


def _canonical_scheme_name(excel_name: str) -> str:
    direct = AUM_FUND_NAME_ALIASES.get(excel_name)
    if direct:
        return direct
    excel_key = normalize(excel_name)
    for source, target in AUM_FUND_NAME_ALIASES.items():
        if normalize(source) == excel_key:
            return target
    return excel_name


def _record_key(excel_name: str) -> str:
    return NORMALIZED_AUM_ALIASES.get(
        normalize(excel_name),
        normalize(_canonical_scheme_name(excel_name)),
    )


def _is_aum_header(value: object) -> bool:
    text = normalize(value)
    return text.startswith("aum as on") and "avg" not in text


def _is_monthly_aaum_header(value: object) -> bool:
    text = normalize(value)
    return (
        text.startswith("avg aum")
        and "monthly" in text
        and "quarterly" not in text
    )


def _find_columns(worksheet) -> tuple[int, int, int, int]:
    """Find Name, AUM, and Monthly AAUM columns by header text."""
    for row in range(1, min(worksheet.max_row, 30) + 1):
        name_column = None
        aum_column = None
        monthly_column = None

        for column in range(1, worksheet.max_column + 1):
            value = worksheet.cell(row, column).value
            text = normalize(value)
            if text in {"name of the scheme", "scheme name"}:
                name_column = column
            elif _is_aum_header(value):
                aum_column = column
            elif _is_monthly_aaum_header(value):
                monthly_column = column

        if (
            name_column is not None
            and aum_column is not None
            and monthly_column is not None
        ):
            return row, name_column, aum_column, monthly_column

    raise ValueError(
        f"Required columns were not found in sheet '{worksheet.title}'. "
        "Expected Name of the Scheme, AUM as on ..., and "
        "Avg AUM - Monthly ...."
    )


def _is_non_scheme_row(name: str) -> bool:
    key = normalize(name)
    return (
        not key
        or key == "fund of fund"
        or key.startswith("total ")
        or key.startswith("equity total")
        or key.startswith("debt total")
        or key.startswith("debt + equity")
        or key.startswith("equity + debt")
        or key.startswith("notes ")
    )


def read_aum_excel(
    excel_bytes: bytes,
    logger,
) -> dict[str, AumRecord]:
    """
    Read scheme AUM and Monthly AAUM from the first compatible worksheet.

    Source amounts are rupees. Stored PowerPoint values are crores.
    Quarterly AAUM is intentionally ignored.
    """
    if not isinstance(excel_bytes, bytes) or not excel_bytes:
        raise ValueError("A non-empty AUM Excel file is required.")

    logger.info("AUM_EXCEL_START | bytes=%s", len(excel_bytes))
    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )

    try:
        compatible_sheet = None
        column_details = None
        for worksheet in workbook.worksheets:
            try:
                column_details = _find_columns(worksheet)
                compatible_sheet = worksheet
                break
            except ValueError:
                logger.info(
                    "AUM_SHEET_SKIPPED | sheet=%s | reason=headers_not_found",
                    worksheet.title,
                )

        if compatible_sheet is None or column_details is None:
            raise ValueError(
                "No worksheet contains Name of the Scheme, AUM as on, and "
                "Avg AUM - Monthly columns."
            )

        header_row, name_column, aum_column, monthly_column = column_details
        records: dict[str, AumRecord] = {}

        for row in range(header_row + 1, compatible_sheet.max_row + 1):
            name = _clean_text(
                compatible_sheet.cell(row, name_column).value
            )
            if _is_non_scheme_row(name):
                continue

            aum_value = compatible_sheet.cell(row, aum_column).value
            monthly_value = compatible_sheet.cell(row, monthly_column).value

            # Note/footer rows may contain text but no numeric AUM values.
            if aum_value in (None, "") and monthly_value in (None, ""):
                continue

            aum_rupees = _to_decimal(aum_value, "AUM", row)
            monthly_aaum_rupees = _to_decimal(
                monthly_value,
                "Monthly AAUM",
                row,
            )
            canonical_name = _canonical_scheme_name(name)
            key = _record_key(name)

            if key in records:
                raise ValueError(
                    f"Duplicate/colliding scheme in AUM Excel after aliases: "
                    f"'{name}'."
                )

            record = AumRecord(
                scheme_name=name,
                canonical_scheme_name=canonical_name,
                aum_rupees=aum_rupees,
                monthly_aaum_rupees=monthly_aaum_rupees,
                aum_crore=rupees_to_crore(aum_rupees),
                monthly_aaum_crore=rupees_to_crore(monthly_aaum_rupees),
                sheet_name=compatible_sheet.title,
                source_row=row,
            )
            records[key] = record
            logger.info(
                "AUM_SCHEME_READ | sheet=%s | row=%s | excel_scheme=%s | "
                "canonical_scheme=%s | aum_rupees=%s | "
                "monthly_aaum_rupees=%s | aum_crore=%s | "
                "monthly_aaum_crore=%s",
                compatible_sheet.title,
                row,
                name,
                canonical_name,
                aum_rupees,
                monthly_aaum_rupees,
                format_crore(record.aum_crore),
                format_crore(record.monthly_aaum_crore),
            )

        if not records:
            raise ValueError("No valid scheme AUM records were found.")

        logger.info(
            "AUM_EXCEL_COMPLETE | sheet=%s | schemes=%s",
            compatible_sheet.title,
            len(records),
        )
        return records
    finally:
        workbook.close()


def _matched_scheme(
    fund_shape,
    records: dict[str, AumRecord],
) -> AumRecord | None:
    for text in shape_texts(fund_shape):
        key = normalize(text)
        record = records.get(key)
        if record:
            return record
        alias_key = NORMALIZED_AUM_ALIASES.get(key)
        if alias_key and alias_key in records:
            return records[alias_key]
    return None


def _clean_metric_text(value: object) -> str:
    return normalize(value).rstrip(":").strip()


def _find_metric_row(table, label: str) -> int | None:
    target = normalize(label)
    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                cell_shape = table.Cell(row, column).Shape
            except Exception:
                continue
            if not cell_shape.HasTextFrame:
                continue
            text = _clean_metric_text(
                cell_shape.TextFrame.TextRange.Text
            )
            if text == target:
                return row
            if text.startswith(target + " "):
                return row
            if text.startswith(target + "("):
                return row
    return None


def _find_value_cell(table, row: int):
    """Return the rightmost accessible text cell on a metric row."""
    for column in range(table.Columns.Count, 0, -1):
        try:
            shape = table.Cell(row, column).Shape
        except Exception:
            continue
        if shape.HasTextFrame:
            text = str(shape.TextFrame.TextRange.Text or "").strip()
            if text:
                return shape, column
    for column in range(table.Columns.Count, 0, -1):
        try:
            shape = table.Cell(row, column).Shape
        except Exception:
            continue
        if shape.HasTextFrame:
            return shape, column
    raise ValueError(f"No accessible value cell found in table row {row}.")


def _replace_number_preserve_format(
    text_range,
    new_number: str,
) -> tuple[str, str]:
    """
    Replace only the numeric part, preserving the existing ₹ and Cr text.

    Example: ₹ 59,926.91 Cr -> ₹ 12,083.74 Cr
    """
    old_text = str(text_range.Text or "")
    match = re.search(
        r"[-+]?\d[\d,]*(?:\.\d+)?",
        old_text,
    )
    if not match:
        raise ValueError(f"Numeric value not found in {old_text!r}.")

    text_range.Characters(
        match.start() + 1,
        match.end() - match.start(),
    ).Text = new_number
    return old_text, str(text_range.Text or "")


def _com_code(error: Exception) -> int | None:
    return getattr(
        error,
        "hresult",
        error.args[0]
        if error.args and isinstance(error.args[0], int)
        else None,
    )


def _retry_com(name: str, operation, logger, attempts: int = 8):
    delay = 0.75
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            if _com_code(error) not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "AUM_COM_RETRY | operation=%s | attempt=%s/%s | wait=%.2f",
                name,
                attempt,
                attempts,
                delay,
            )
            time.sleep(delay)
            delay = min(4.0, delay * 1.7)


def apply_aum_aaum(
    current_ppt_bytes: bytes,
    excel_bytes: bytes,
    fund_object: str,
    scheme_details_object: str,
    logger,
) -> bytes:
    records = read_aum_excel(excel_bytes, logger)
    logger.info(
        "AUM_STEP_START | ppt_bytes=%s | records=%s | unit=crore | "
        "aaum_period=monthly",
        len(current_ppt_bytes),
        len(records),
    )

    pythoncom.CoInitialize()
    powerpoint = presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "working.pptx"
            output_path = Path(temp_dir) / "aum_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = _retry_com(
                "start PowerPoint",
                lambda: win32com.client.DispatchEx(
                    "PowerPoint.Application"
                ),
                logger,
            )
            _retry_com(
                "set DisplayAlerts",
                lambda: setattr(powerpoint, "DisplayAlerts", False),
                logger,
            )
            presentation = _retry_com(
                "open presentation",
                lambda: powerpoint.Presentations.Open(
                    str(input_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            matched = changed = unmatched = 0

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                details_shape = find_shape_recursive(
                    slide.Shapes,
                    scheme_details_object,
                )
                if details_shape is None:
                    continue

                fund_shape = find_shape_recursive(
                    slide.Shapes,
                    fund_object,
                )
                if fund_shape is None:
                    logger.warning(
                        "AUM_SLIDE_SKIPPED | slide=%s | reason=no %s",
                        slide_number,
                        fund_object,
                    )
                    continue

                record = _matched_scheme(fund_shape, records)
                ppt_scheme = " | ".join(shape_texts(fund_shape))
                if record is None:
                    unmatched += 1
                    logger.warning(
                        "AUM_SCHEME_NOT_MATCHED | slide=%s | "
                        "ppt_scheme=%r | no_changes",
                        slide_number,
                        ppt_scheme,
                    )
                    continue

                if not details_shape.HasTable:
                    raise ValueError(
                        f"'{scheme_details_object}' on slide {slide_number} "
                        "is not a table."
                    )

                matched += 1
                table = details_shape.Table
                logger.info(
                    "AUM_SCHEME_MATCHED | slide=%s | scheme=%s",
                    slide_number,
                    record.canonical_scheme_name,
                )

                for metric, value in (
                    ("AUM", record.aum_crore),
                    ("AAUM", record.monthly_aaum_crore),
                ):
                    row = _find_metric_row(table, metric)
                    if row is None:
                        raise ValueError(
                            f"'{metric}' row missing in "
                            f"'{scheme_details_object}' on slide "
                            f"{slide_number}."
                        )

                    value_cell, column = _find_value_cell(table, row)
                    old_text, new_text = _replace_number_preserve_format(
                        value_cell.TextFrame.TextRange,
                        format_crore(value),
                    )
                    changed += 1
                    logger.info(
                        "AUM_VALUE_CHANGED | metric=%s | scheme=%s | "
                        "slide=%s | cell=%s,%s | %s -> %s",
                        metric,
                        record.canonical_scheme_name,
                        slide_number,
                        row,
                        column,
                        old_text,
                        new_text,
                    )

            _retry_com(
                "save presentation",
                lambda: presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            _retry_com(
                "close presentation",
                presentation.Close,
                logger,
                attempts=4,
            )
            presentation = None

            output = output_path.read_bytes()
            if not output:
                raise RuntimeError("The generated PowerPoint file is empty.")

            logger.info(
                "AUM_STEP_COMPLETE | matched=%s | unmatched=%s | "
                "values_changed=%s | bytes=%s",
                matched,
                unmatched,
                changed,
                len(output),
            )
            return output

    except Exception:
        logger.exception("AUM_STEP_FAILED")
        raise

    finally:
        if presentation is not None:
            try:
                _retry_com(
                    "cleanup close presentation",
                    presentation.Close,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass

        if powerpoint is not None:
            try:
                _retry_com(
                    "quit PowerPoint",
                    powerpoint.Quit,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass

        pythoncom.CoUninitialize()
