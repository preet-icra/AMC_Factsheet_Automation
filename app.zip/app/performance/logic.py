from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive

PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_GROUP = 6
POINTS_PER_CM = 72.0 / 2.54
PERFORMANCE_TABLE_WIDTH_CM = 18.83
PERFORMANCE_TABLE_FONT_NAME = "Arial"
PERFORMANCE_TABLE_FONT_SIZE = 8.0
PERFORMANCE_TABLE_HEADER_GAP_CM = 0.25
PERFORMANCE_TABLE_HEADER_GAP_PT = (
    PERFORMANCE_TABLE_HEADER_GAP_CM * POINTS_PER_CM
)

PERFORMANCE_FUND_ALIASES = {
    "Axis Focused 25 Fund": "Axis Focused Fund",
    "Axis Childrens Fund": "Axis Children's Fund",
}


@dataclass(frozen=True)
class PerformanceRecord:
    source_slide_number: int
    source_fund_name: str
    canonical_fund_name: str
    table_values: tuple[tuple[str, ...], ...]
    as_on_date: str
    note: str


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    for old, new in {
        "\u2018": "'", "\u2019": "'", "\u2013": "-", "\u2014": "-",
        "\xa0": " ", "\r": " ", "\n": " ",
    }.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", "", _clean_text(value).casefold().replace("&", " and "))


def _base_fund_name(value: object) -> str:
    text = _clean_text(value)
    for pattern in (
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
    ):
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base = _base_fund_name(value)
    aliases = {_text_key(k): v for k, v in PERFORMANCE_FUND_ALIASES.items()}
    return aliases.get(_text_key(base), base)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for i in range(1, shape.GroupItems.Count + 1):
                parts.append(_shape_text(shape.GroupItems.Item(i)))
        elif shape.HasTable:
            table = shape.Table
            for r in range(1, table.Rows.Count + 1):
                for c in range(1, table.Columns.Count + 1):
                    parts.append(_cell_text(table, r, c))
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(str(shape.TextFrame.TextRange.Text or ""))
    except Exception:
        return ""
    return " ".join(_clean_text(x) for x in parts if _clean_text(x))


def _cell_text(table, row: int, column: int) -> str:
    try:
        shape = table.Cell(row, column).Shape
        if shape.HasTextFrame:
            return _clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def _shape_name_key(shape) -> str:
    try:
        return _text_key(shape.Name)
    except Exception:
        return ""


def _find_with_owner(slide, name: str):
    wanted = _text_key(name)
    def walk(shape, owner):
        if _shape_name_key(shape) == wanted:
            return shape, owner
        try:
            if int(shape.Type) == MSO_GROUP:
                for i in range(1, shape.GroupItems.Count + 1):
                    result = walk(shape.GroupItems.Item(i), owner)
                    if result:
                        return result
        except Exception:
            pass
        return None
    for i in range(1, slide.Shapes.Count + 1):
        owner = slide.Shapes.Item(i)
        result = walk(owner, owner)
        if result:
            return result
    return None, None


def _find_shape(slide, name: str):
    shape, _ = _find_with_owner(slide, name)
    return shape or find_shape_recursive(slide.Shapes, name)


def _find_table_shape(shape):
    if shape is None:
        return None
    try:
        if shape.HasTable:
            return shape
        if int(shape.Type) == MSO_GROUP:
            for i in range(1, shape.GroupItems.Count + 1):
                found = _find_table_shape(shape.GroupItems.Item(i))
                if found:
                    return found
    except Exception:
        pass
    return None


def _read_table(shape) -> tuple[tuple[str, ...], ...]:
    table_shape = _find_table_shape(shape)
    if table_shape is None:
        raise ValueError("PerformanceTable does not contain a PowerPoint table.")
    table = table_shape.Table
    return tuple(
        tuple(_cell_text(table, r, c) for c in range(1, table.Columns.Count + 1))
        for r in range(1, table.Rows.Count + 1)
    )


def _is_valid_fund_name(text: str) -> bool:
    key = _text_key(text)
    return bool(text) and len(text) < 160 and "axis" in key and "fund" in key and "http" not in key


def _build_source_index(source, logger) -> dict[str, PerformanceRecord]:
    records: dict[str, PerformanceRecord] = {}
    pending_name = ""
    pending_slide = 0
    for slide_number in range(1, source.Slides.Count + 1):
        slide = source.Slides.Item(slide_number)
        fund_shape = _find_shape(slide, "FundName")
        current_name = _shape_text(fund_shape) if fund_shape else ""
        if not _is_valid_fund_name(current_name):
            current_name = ""
        if current_name:
            pending_name, pending_slide = current_name, slide_number

        table_shape = _find_shape(slide, "PerformanceTable")
        if _find_table_shape(table_shape) is None:
            if current_name:
                logger.info("PERFORMANCE_SOURCE_FUND_PENDING | slide=%s | fund=%s", slide_number, current_name)
            continue

        fund_name = current_name or pending_name
        if not fund_name:
            logger.warning("PERFORMANCE_SOURCE_TABLE_UNASSIGNED | slide=%s", slide_number)
            continue
        values = _read_table(table_shape)
        date_shape = _find_shape(slide, "AsOnDate")
        note_shape = _find_shape(slide, "PerformanceNote")
        record = PerformanceRecord(
            source_slide_number=slide_number,
            source_fund_name=fund_name,
            canonical_fund_name=_canonical_fund_name(fund_name),
            table_values=values,
            as_on_date=_shape_text(date_shape),
            note=_shape_text(note_shape),
        )
        records.setdefault(_fund_key(fund_name), record)
        logger.info(
            "PERFORMANCE_SOURCE_FOUND | fund_slide=%s | table_slide=%s | fund=%s | rows=%s | columns=%s | date=%s | note=%s",
            pending_slide or slide_number, slide_number, record.canonical_fund_name,
            len(values), max(len(row) for row in values), bool(record.as_on_date), bool(record.note),
        )
        pending_name, pending_slide = "", 0
    if not records:
        raise ValueError("No usable source PerformanceTable records were found. Target was not modified.")
    logger.info("PERFORMANCE_SOURCE_INDEX_COMPLETE | funds=%s", len(records))
    return records


def _table_dimensions(shape) -> tuple[int, int]:
    table_shape = _find_table_shape(shape)
    if table_shape is None:
        raise ValueError("The PerformanceTable object does not contain a table.")
    return int(table_shape.Table.Rows.Count), int(table_shape.Table.Columns.Count)


def _table_values(shape) -> tuple[tuple[str, ...], ...]:
    table_shape = _find_table_shape(shape)
    if table_shape is None:
        raise ValueError("The PerformanceTable object does not contain a table.")
    table = table_shape.Table
    return tuple(
        tuple(
            _cell_text(table, row, column)
            for column in range(1, table.Columns.Count + 1)
        )
        for row in range(1, table.Rows.Count + 1)
    )


def _apply_performance_table_font(table_shape, logger) -> int:
    """
    Apply Arial 8 pt to every accessible cell in PerformanceTable.

    PowerPoint merged tables can expose the same merged cell through several
    row/column coordinates or reject access to covered coordinates. Each
    unique cell shape is therefore formatted once, while inaccessible merged
    coordinates are skipped safely.
    """
    actual_table_shape = _find_table_shape(table_shape)
    if actual_table_shape is None:
        raise ValueError(
            "Cannot apply font because PerformanceTable is not a table."
        )

    table = actual_table_shape.Table
    formatted_shape_ids: set[int] = set()
    formatted_cells = 0

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                cell_shape = table.Cell(row, column).Shape
                if not cell_shape.HasTextFrame:
                    continue

                try:
                    shape_id = int(cell_shape.Id)
                except Exception:
                    shape_id = hash((row, column))

                if shape_id in formatted_shape_ids:
                    continue
                formatted_shape_ids.add(shape_id)

                text_range = cell_shape.TextFrame.TextRange
                text_range.Font.Name = PERFORMANCE_TABLE_FONT_NAME
                text_range.Font.Size = PERFORMANCE_TABLE_FONT_SIZE
                formatted_cells += 1
            except Exception as error:
                logger.debug(
                    "PERFORMANCE_FONT_CELL_SKIPPED | row=%s | column=%s | "
                    "reason=%s",
                    row,
                    column,
                    error,
                )

    if formatted_cells == 0:
        raise ValueError(
            "Arial 8 pt could not be applied to any PerformanceTable cell."
        )

    logger.info(
        "PERFORMANCE_TABLE_FONT_APPLIED | font=%s | size=%.1f | cells=%s",
        PERFORMANCE_TABLE_FONT_NAME,
        PERFORMANCE_TABLE_FONT_SIZE,
        formatted_cells,
    )
    return formatted_cells


def _verify_performance_table_font(table_shape) -> None:
    """Verify that every accessible unique table cell uses Arial 8 pt."""
    actual_table_shape = _find_table_shape(table_shape)
    if actual_table_shape is None:
        raise ValueError(
            "Cannot verify font because PerformanceTable is not a table."
        )

    table = actual_table_shape.Table
    checked_shape_ids: set[int] = set()
    failures: list[str] = []

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                cell_shape = table.Cell(row, column).Shape
                if not cell_shape.HasTextFrame:
                    continue

                try:
                    shape_id = int(cell_shape.Id)
                except Exception:
                    shape_id = hash((row, column))

                if shape_id in checked_shape_ids:
                    continue
                checked_shape_ids.add(shape_id)

                font = cell_shape.TextFrame.TextRange.Font
                actual_name = _clean_text(font.Name)
                actual_size = float(font.Size)
                if (
                    actual_name.casefold()
                    != PERFORMANCE_TABLE_FONT_NAME.casefold()
                    or abs(actual_size - PERFORMANCE_TABLE_FONT_SIZE) > 0.01
                ):
                    failures.append(
                        f"r{row}c{column}: font={actual_name!r}, "
                        f"size={actual_size}"
                    )
                    if len(failures) >= 5:
                        break
            except Exception:
                # Covered coordinates in merged cells are not independent cells
                # and therefore do not need separate font verification.
                continue
        if len(failures) >= 5:
            break

    if failures:
        raise ValueError(
            "PerformanceTable font verification failed: "
            + "; ".join(failures)
        )


def _performance_header_bottom(target_slide, logger) -> float | None:
    """
    Return the lowest edge of the Performance heading and icon group.

    The visible header can be a group containing the PERFORMANCE label and
    circular icon, or the icon can be a separate nearby group. The search uses
    the exact PERFORMANCE text first, then includes only compact shapes close
    to that heading. This avoids relying on unstable Selection Pane names.
    """
    performance_token = _text_key("PERFORMANCE")
    header_owners: dict[str, object] = {}

    def add_owner(owner) -> None:
        if owner is None:
            return
        try:
            key = str(owner.Id)
        except Exception:
            key = f"header:{_shape_name_key(owner)}:{id(owner)}"
        header_owners[key] = owner

    # Find the owner containing the exact visible heading text.
    for candidate, owner in _iter_shapes_with_owner(target_slide):
        try:
            if _text_key(_shape_text(candidate)) == performance_token:
                add_owner(owner)
        except Exception:
            continue

    if not header_owners:
        logger.warning(
            "PERFORMANCE_HEADER_NOT_FOUND_FOR_TABLE_GAP | slide=%s",
            target_slide.SlideIndex,
        )
        return None

    # Union the semantic heading owners first.
    semantic_bounds: list[tuple[float, float, float, float]] = []
    for owner in header_owners.values():
        try:
            left = float(owner.Left)
            top = float(owner.Top)
            width = float(owner.Width)
            height = float(owner.Height)
            semantic_bounds.append(
                (left, top, left + width, top + height)
            )
        except Exception:
            continue

    if not semantic_bounds:
        return None

    header_left = min(item[0] for item in semantic_bounds)
    header_top = min(item[1] for item in semantic_bounds)
    header_right = max(item[2] for item in semantic_bounds)
    header_bottom = max(item[3] for item in semantic_bounds)
    header_center_y = (header_top + header_bottom) / 2.0

    # Include a separately grouped circular icon only when it sits immediately
    # beside the semantic PERFORMANCE heading and overlaps its vertical band.
    for candidate, owner in _iter_shapes_with_owner(target_slide):
        try:
            if candidate.HasTable:
                continue
            c_left = float(candidate.Left)
            c_top = float(candidate.Top)
            c_width = float(candidate.Width)
            c_height = float(candidate.Height)
            c_right = c_left + c_width
            c_bottom = c_top + c_height
            c_center_y = c_top + c_height / 2.0
        except Exception:
            continue

        is_compact = (
            8.0 <= c_width <= 110.0
            and 8.0 <= c_height <= 110.0
        )
        near_heading_left = (
            header_left - 90.0 <= c_left <= header_left + 50.0
            and c_right >= header_left - 35.0
        )
        vertically_aligned = (
            abs(c_center_y - header_center_y)
            <= max(35.0, (header_bottom - header_top) * 0.85)
        )

        if not (is_compact and near_heading_left and vertically_aligned):
            continue

        add_owner(owner)
        try:
            owner_bottom = float(owner.Top) + float(owner.Height)
            header_bottom = max(header_bottom, owner_bottom)
        except Exception:
            header_bottom = max(header_bottom, c_bottom)

    logger.info(
        "PERFORMANCE_HEADER_BOTTOM_DETECTED | slide=%s | bottom=%.2f | "
        "owners=%s | gap_cm=%.2f",
        target_slide.SlideIndex,
        header_bottom,
        len(header_owners),
        PERFORMANCE_TABLE_HEADER_GAP_CM,
    )
    return header_bottom


def _copy_source_table_to_target(
    source_wrapper,
    target_wrapper,
    target_slide,
    target_object_name: str,
    logger,
) -> tuple[object, int]:
    """
    Replace the target table with an exact copy of the source table.

    Performance tables contain merged multi-row and multi-column headers.
    Adding/deleting target columns destroys those merge relationships in
    PowerPoint. Copying the complete source table preserves every merge, row,
    column, label, and value. The copied table is then moved into the target
    table's position, renamed, and forced to 18.83 cm wide.
    """
    source_table_shape = _find_table_shape(source_wrapper)
    target_table_shape = _find_table_shape(target_wrapper)
    if source_table_shape is None:
        raise ValueError("Source PerformanceTable is not a PowerPoint table.")
    if target_table_shape is None:
        raise ValueError("Target PerformanceTable is not a PowerPoint table.")

    source_values = _table_values(source_table_shape)
    source_rows, source_columns = _table_dimensions(source_table_shape)

    target_left = float(target_table_shape.Left)
    target_top = float(target_table_shape.Top)
    target_rotation = float(target_table_shape.Rotation)

    # Copy first while both source and target table COM objects are valid.
    source_table_shape.Copy()
    pythoncom.PumpWaitingMessages()
    pasted_range = target_slide.Shapes.Paste()
    if pasted_range is None or pasted_range.Count < 1:
        raise RuntimeError("PowerPoint did not paste the source PerformanceTable.")
    pasted_shape = pasted_range.Item(1)

    # Keep the old target table until the pasted table has passed all geometry
    # and content checks. This provides a safe rollback if PowerPoint rejects a
    # property or the copied table is incomplete.
    pasted_shape.Name = target_object_name + "_Pending"
    pasted_shape.Left = target_left

    header_bottom = _performance_header_bottom(target_slide, logger)
    if header_bottom is None:
        adjusted_top = target_top
    else:
        adjusted_top = max(
            target_top,
            header_bottom + PERFORMANCE_TABLE_HEADER_GAP_PT,
        )
    pasted_shape.Top = adjusted_top

    logger.info(
        "PERFORMANCE_TABLE_TOP_POSITIONED | slide=%s | original_top=%.2f | "
        "new_top=%.2f | shift_cm=%.3f | gap_cm=%.2f",
        target_slide.SlideIndex,
        target_top,
        adjusted_top,
        (adjusted_top - target_top) / POINTS_PER_CM,
        PERFORMANCE_TABLE_HEADER_GAP_CM,
    )

    # Tables copied from some source presentations are locked against rotation.
    # Rotation is not required for this workflow, so apply it only when the
    # pasted shape permits the property to be changed.
    try:
        if abs(float(pasted_shape.Rotation) - target_rotation) > 0.01:
            pasted_shape.Rotation = target_rotation
    except (pywintypes.com_error, AttributeError, TypeError, ValueError) as error:
        logger.info(
            "PERFORMANCE_ROTATION_UNCHANGED | target_rotation=%.2f | "
            "reason=%s",
            target_rotation,
            error,
        )

    # PowerPoint may lock a pasted table's aspect ratio. Disable that lock when
    # possible, then set only the required target width. Height remains
    # proportional to the exact source table and its merged-cell structure.
    try:
        pasted_shape.LockAspectRatio = 0
    except (pywintypes.com_error, AttributeError):
        pass
    pasted_shape.Width = PERFORMANCE_TABLE_WIDTH_CM * POINTS_PER_CM

    # PowerPoint can finish table recalculation after Paste returns.
    pythoncom.PumpWaitingMessages()
    time.sleep(0.05)

    pasted_table_shape = _find_table_shape(pasted_shape)
    if pasted_table_shape is None:
        raise RuntimeError("The pasted PerformanceTable is not a table.")

    _apply_performance_table_font(pasted_table_shape, logger)
    _verify_performance_table_font(pasted_table_shape)

    actual_rows, actual_columns = _table_dimensions(pasted_table_shape)
    if (actual_rows, actual_columns) != (source_rows, source_columns):
        raise ValueError(
            "Pasted PerformanceTable dimensions do not match the source. "
            f"Source={source_rows}x{source_columns}; "
            f"target={actual_rows}x{actual_columns}."
        )

    actual_values = _table_values(pasted_table_shape)
    mismatches: list[str] = []
    for row in range(source_rows):
        for column in range(source_columns):
            if actual_values[row][column] != source_values[row][column]:
                mismatches.append(
                    f"r{row + 1}c{column + 1}: "
                    f"source={source_values[row][column]!r}, "
                    f"target={actual_values[row][column]!r}"
                )
                if len(mismatches) >= 5:
                    break
        if len(mismatches) >= 5:
            break
    if mismatches:
        pasted_shape.Delete()
        raise ValueError(
            "Pasted PerformanceTable verification failed: "
            + "; ".join(mismatches)
        )

    # Verification succeeded. Remove the old table and assign the requested
    # Selection Pane name to the exact copied source table.
    target_table_shape.Delete()
    pasted_shape.Name = target_object_name

    logger.info(
        "PERFORMANCE_TABLE_COPY_VERIFIED | rows=%s | columns=%s | "
        "width_cm=%.2f | font=%s | font_size=%.1f | "
        "header_gap_cm=%.2f | cells=%s",
        source_rows,
        source_columns,
        PERFORMANCE_TABLE_WIDTH_CM,
        PERFORMANCE_TABLE_FONT_NAME,
        PERFORMANCE_TABLE_FONT_SIZE,
        PERFORMANCE_TABLE_HEADER_GAP_CM,
        source_rows * source_columns,
    )
    return pasted_table_shape, source_rows * source_columns


def _set_text(shape, value: str) -> None:
    if shape is not None and shape.HasTextFrame:
        shape.TextFrame.TextRange.Text = value


def _iter_shapes_with_owner(slide):
    """Yield each top-level and nested shape with its top-level owner."""
    def walk(shape, owner):
        yield shape, owner
        try:
            if int(shape.Type) == MSO_GROUP:
                for child_index in range(1, shape.GroupItems.Count + 1):
                    child = shape.GroupItems.Item(child_index)
                    yield from walk(child, owner)
        except Exception:
            pass

    for index in range(1, slide.Shapes.Count + 1):
        try:
            owner = slide.Shapes.Item(index)
        except Exception:
            continue
        yield from walk(owner, owner)


def _delete_section(
    slide,
    names: tuple[str, ...],
    logger,
) -> int:
    """
    Delete the complete Performance section.

    Exact configured names are resolved first. The visible PERFORMANCE header
    is then resolved independently because many templates assign the header
    group an automatic PowerPoint name instead of PerformaceIconText. If text
    lookup is unavailable, the fallback uses the original PerformanceTableBox
    top-left geometry and selects only compact or shallow header shapes in a
    narrow band around that box corner.
    """
    owners: dict[str, tuple[object, set[str]]] = {}

    def add_owner(owner, reason: str) -> None:
        if owner is None:
            return
        try:
            key = str(owner.Id)
        except Exception:
            key = f"{_shape_name_key(owner)}:{id(owner)}"
        if key not in owners:
            owners[key] = (owner, set())
        owners[key][1].add(reason)

    # Capture the exact box geometry before any object is deleted.
    box_name = next(
        (name for name in names if _text_key(name) == _text_key("PerformanceTableBox")),
        "PerformanceTableBox",
    )
    box_shape, _ = _find_with_owner(slide, box_name)
    box_geometry = None
    if box_shape is not None:
        try:
            box_geometry = (
                float(box_shape.Left),
                float(box_shape.Top),
                float(box_shape.Width),
                float(box_shape.Height),
            )
        except Exception:
            box_geometry = None

    exact_owner_ids: set[int] = set()
    for name in names:
        matched, owner = _find_with_owner(slide, name)
        if owner is None:
            logger.info(
                "PERFORMANCE_OBJECT_NAME_NOT_FOUND | slide=%s | object=%s",
                slide.SlideIndex,
                name,
            )
            continue
        add_owner(owner, name)
        try:
            exact_owner_ids.add(int(owner.Id))
        except Exception:
            pass

    # Semantic fallback. The screenshot shows the exact visible word
    # PERFORMANCE inside a purple rounded header group.
    performance_token = _text_key("PERFORMANCE")
    semantic_owners = 0
    for candidate, candidate_owner in _iter_shapes_with_owner(slide):
        try:
            visible_key = _text_key(_shape_text(candidate))
        except Exception:
            continue
        if visible_key != performance_token:
            continue
        add_owner(candidate_owner, "performance_heading_text")
        semantic_owners += 1

    # Geometry fallback for grouped or blank header artwork. The search is
    # strictly local to the original PerformanceTableBox upper-left corner.
    geometry_candidates = 0
    if box_geometry is not None:
        box_left, box_top, box_width, box_height = box_geometry
        box_right = box_left + box_width
        corner_x = box_left
        corner_y = box_top

        for candidate, candidate_owner in _iter_shapes_with_owner(slide):
            try:
                owner_id = int(candidate_owner.Id)
                if owner_id in exact_owner_ids:
                    continue
                if candidate.HasTable:
                    continue
                c_left = float(candidate.Left)
                c_top = float(candidate.Top)
                c_width = float(candidate.Width)
                c_height = float(candidate.Height)
                c_right = c_left + c_width
                c_bottom = c_top + c_height
                c_center_x = c_left + c_width / 2.0
                c_center_y = c_top + c_height / 2.0
            except Exception:
                continue

            # Purple rounded heading bar near the box top edge.
            is_heading_bar = (
                45.0 <= c_width <= min(box_width + 30.0, 500.0)
                and 5.0 <= c_height <= 75.0
                and c_right >= box_left - 10.0
                and c_left <= box_right
                and c_bottom >= box_top - 45.0
                and c_top <= box_top + 30.0
            )

            # Circular orange/purple icon at the upper-left box corner.
            corner_distance = (
                (c_center_x - corner_x) ** 2
                + (c_center_y - corner_y) ** 2
            ) ** 0.5
            is_header_icon = (
                4.0 <= c_width <= 100.0
                and 4.0 <= c_height <= 100.0
                and corner_distance <= 82.0
            )

            if is_heading_bar or is_header_icon:
                add_owner(
                    candidate_owner,
                    "performance_header_box_geometry",
                )
                geometry_candidates += 1

        logger.info(
            "PERFORMANCE_HEADER_FALLBACK | slide=%s | semantic=%s | "
            "geometry_candidates=%s",
            slide.SlideIndex,
            semantic_owners,
            geometry_candidates,
        )
    else:
        logger.warning(
            "PERFORMANCE_BOX_GEOMETRY_UNAVAILABLE | slide=%s",
            slide.SlideIndex,
        )

    deleted = 0
    owner_items = list(owners.values())
    owner_items.sort(
        key=lambda item: int(getattr(item[0], "ZOrderPosition", 0)),
        reverse=True,
    )

    for owner, reasons in owner_items:
        try:
            owner_name = str(owner.Name)
        except Exception:
            owner_name = "<group>"
        try:
            owner.Delete()
            deleted += 1
            logger.info(
                "PERFORMANCE_OWNER_DELETED | slide=%s | owner=%s | "
                "reasons=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
            )
        except Exception as error:
            logger.warning(
                "PERFORMANCE_OWNER_DELETE_FAILED | slide=%s | owner=%s | "
                "reasons=%s | error=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
                error,
            )

    return deleted


def _retry_com(name, operation, logger, attempts=6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(error, "hresult", error.args[0] if error.args and isinstance(error.args[0], int) else None)
            if code not in {RPC_E_CALL_REJECTED, RPC_E_SERVERCALL_RETRYLATER} or attempt == attempts:
                raise
            logger.warning("PERFORMANCE_COM_RETRY | operation=%s | attempt=%s/%s", name, attempt, attempts)
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def apply_performance(
    current_ppt_bytes: bytes,
    performance_source_ppt_bytes: bytes,
    fund_object: str,
    performance_table_object: str,
    performance_box_object: str,
    performance_note_object: str,
    as_on_date_object: str,
    performance_icon_text_object: str,
    logger,
    strict: bool = False,
    source_file: str = "",
) -> bytes:
    if not current_ppt_bytes or not performance_source_ppt_bytes:
        raise ValueError("Both target and source PowerPoint files are required.")
    pythoncom.CoInitialize()
    powerpoint = source = target = None
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path, target_path, output_path = temp / "performance_source.pptx", temp / "performance_target.pptx", temp / "performance_output.pptx"
            source_path.write_bytes(performance_source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)
            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.DisplayAlerts = False
            source = _retry_com("open performance source", lambda: powerpoint.Presentations.Open(str(source_path.resolve()), True, False, False), logger)
            target = _retry_com("open performance target", lambda: powerpoint.Presentations.Open(str(target_path.resolve()), False, False, False), logger)
            records = _build_source_index(source, logger)
            updated = deleted = unmatched = changes = 0
            section_names = (performance_table_object, performance_box_object, performance_note_object, as_on_date_object, performance_icon_text_object)
            for slide_number in range(1, target.Slides.Count + 1):
                slide = target.Slides.Item(slide_number)
                target_table = _find_shape(slide, performance_table_object)
                if target_table is None:
                    continue
                fund_shape = _find_shape(slide, fund_object)
                if fund_shape is None:
                    if strict:
                        raise ValueError(f"'{fund_object}' missing on target slide {slide_number}.")
                    continue
                fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(fund_name))
                if record is None:
                    unmatched += 1
                    deleted += _delete_section(slide, section_names, logger)
                    logger.info("PERFORMANCE_DATA_ABSENT | slide=%s | fund=%s", slide_number, fund_name)
                    continue
                old_target_table = _find_table_shape(target_table)
                old_height = float(old_target_table.Height)
                source_slide = source.Slides.Item(
                    record.source_slide_number
                )
                source_table = _find_shape(
                    source_slide,
                    "PerformanceTable",
                )
                actual_table, count = _copy_source_table_to_target(
                    source_wrapper=source_table,
                    target_wrapper=target_table,
                    target_slide=slide,
                    target_object_name=performance_table_object,
                    logger=logger,
                )
                date_shape = _find_shape(slide, as_on_date_object)
                note_shape = _find_shape(slide, performance_note_object)
                box_shape = _find_shape(slide, performance_box_object)
                _set_text(date_shape, record.as_on_date)
                _set_text(note_shape, record.note)
                new_height = float(actual_table.Height)
                delta = new_height - old_height
                if note_shape is not None:
                    note_shape.Top = float(actual_table.Top) + new_height + 3.0
                if box_shape is not None:
                    bottoms = [float(actual_table.Top) + new_height]
                    if note_shape is not None:
                        bottoms.append(float(note_shape.Top) + float(note_shape.Height))
                    box_shape.Height = max(1.0, max(bottoms) + 5.0 - float(box_shape.Top))
                updated += 1
                changes += count + int(bool(record.as_on_date)) + int(bool(record.note))
                logger.info(
                    "PERFORMANCE_UPDATED | target_slide=%s | source_slide=%s | "
                    "fund=%s | rows=%s | columns=%s | width_cm=%.2f | "
                    "height_delta_cm=%.3f | mode=exact_table_copy",
                    slide_number,
                    record.source_slide_number,
                    record.canonical_fund_name,
                    len(record.table_values),
                    max(len(row) for row in record.table_values),
                    PERFORMANCE_TABLE_WIDTH_CM,
                    delta / POINTS_PER_CM,
                )
            _retry_com("save performance target", lambda: target.SaveAs(str(output_path.resolve()), PP_SAVE_AS_OPEN_XML_PRESENTATION), logger)
            target.Close(); target = None
            source.Close(); source = None
            output = output_path.read_bytes()
            logger.info("PERFORMANCE_COMPLETE | source_funds=%s | updated=%s | unmatched=%s | deleted=%s | changes=%s | bytes=%s", len(records), updated, unmatched, deleted, changes, len(output))
            return output
    except Exception:
        logger.exception("PERFORMANCE_FAILED")
        raise
    finally:
        for presentation in (target, source):
            if presentation is not None:
                try: presentation.Close()
                except Exception: pass
        if powerpoint is not None:
            try: powerpoint.Quit()
            except Exception: pass
        pythoncom.CoUninitialize()
