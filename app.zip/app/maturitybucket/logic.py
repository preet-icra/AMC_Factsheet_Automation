from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_CHART = 3
MSO_GROUP = 6
MSO_EMBEDDED_OLE_OBJECT = 7
MSO_LINKED_PICTURE = 11
MSO_PICTURE = 13
MSO_GRAPHIC = 28
MSO_LINKED_GRAPHIC = 29
POINTS_PER_CM = 72.0 / 2.54

MATURITY_GRAPH_WIDTH_CM = 8.77
MATURITY_GRAPH_HEIGHT_CM = 4.35
MATURITY_GRAPH_WIDTH_PT = MATURITY_GRAPH_WIDTH_CM * POINTS_PER_CM
MATURITY_GRAPH_HEIGHT_PT = MATURITY_GRAPH_HEIGHT_CM * POINTS_PER_CM

SOURCE_FUND_OBJECT = "FundName"
SOURCE_GRAPH_OBJECT = "MaturityBucketGraph"
SOURCE_GRAPH_GROUP_OBJECT = "MaturityBucketAll"

TARGET_GRAPH_OBJECT = "MaturityBucketGraph"
TARGET_GRAPH_BOX_OBJECT = "MaturityBucketGraphBox"
TARGET_TEXT_BG_OBJECT = "MaturityTextBG"
TARGET_ICON_OBJECT = "MaturityIcon"
TARGET_TEXT_OBJECT = "MaturityText"

MATURITY_FUND_ALIASES: dict[str, str] = {
    "Axis Focused 25 Fund": "Axis Focused Fund",
    "Axis Childrens Fund": "Axis Children's Fund",
}


@dataclass(frozen=True)
class MaturityGraphRecord:
    source_slide_number: int
    source_fund_name: str
    canonical_fund_name: str


@dataclass(frozen=True)
class Bounds:
    left: float
    top: float
    width: float
    height: float

    @property
    def right(self) -> float:
        return self.left + self.width

    @property
    def bottom(self) -> float:
        return self.top + self.height

    @property
    def center_x(self) -> float:
        return self.left + self.width / 2.0

    @property
    def center_y(self) -> float:
        return self.top + self.height / 2.0


# -----------------------------------------------------------------------------
# Text and fund normalization
# -----------------------------------------------------------------------------


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
        "\r": " ",
        "\n": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    text = _clean_text(value)
    patterns = (
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*"
        r"growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
    )
    for pattern in patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base = _base_fund_name(value)
    aliases = {
        _text_key(source): target
        for source, target in MATURITY_FUND_ALIASES.items()
    }
    return aliases.get(_text_key(base), base)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _is_valid_fund_name(value: object) -> bool:
    text = _clean_text(value)
    key = _text_key(text)
    return (
        bool(text)
        and len(text) < 170
        and "axis" in key
        and "fund" in key
        and "http" not in key
        and "riskometer" not in key
    )


# -----------------------------------------------------------------------------
# PowerPoint shape helpers
# -----------------------------------------------------------------------------


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                text = _shape_text(shape.GroupItems.Item(index))
                if text:
                    parts.append(text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    try:
                        cell = table.Cell(row, column).Shape
                        if cell.HasTextFrame and cell.TextFrame.HasText:
                            parts.append(cell.TextFrame.TextRange.Text)
                    except Exception:
                        continue
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""
    return " ".join(_clean_text(part) for part in parts if _clean_text(part))


def _shape_name(shape) -> str:
    try:
        return str(shape.Name)
    except Exception:
        return ""


def _shape_name_key(shape) -> str:
    return _text_key(_shape_name(shape))


def _bounds(shape) -> Bounds:
    return Bounds(
        left=float(shape.Left),
        top=float(shape.Top),
        width=float(shape.Width),
        height=float(shape.Height),
    )


def _walk_shape(shape, owner):
    yield shape, owner
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                child = shape.GroupItems.Item(index)
                yield from _walk_shape(child, owner)
    except Exception:
        pass


def _iter_shapes_with_owner(slide):
    for index in range(1, slide.Shapes.Count + 1):
        try:
            owner = slide.Shapes.Item(index)
        except Exception:
            continue
        yield from _walk_shape(owner, owner)


def _find_with_owner(slide, object_name: str):
    wanted = _text_key(object_name)
    for candidate, owner in _iter_shapes_with_owner(slide):
        if _shape_name_key(candidate) == wanted:
            return candidate, owner
    return None, None


def _find_shape(slide, object_name: str):
    shape, _ = _find_with_owner(slide, object_name)
    if shape is not None:
        return shape
    return find_shape_recursive(slide.Shapes, object_name)


def _is_numbered_picture_name(shape) -> bool:
    """Match automatic PowerPoint names such as Picture 27 or Picture31."""
    name = _clean_text(_shape_name(shape))
    return bool(
        re.fullmatch(
            r"picture\s*\d+",
            name,
            flags=re.IGNORECASE,
        )
    )


def _shape_type(shape) -> int | None:
    try:
        return int(shape.Type)
    except Exception:
        return None


def _has_chart(shape) -> bool:
    try:
        if bool(shape.HasChart):
            return True
    except Exception:
        pass
    return _shape_type(shape) == MSO_CHART


def _is_picture(shape) -> bool:
    shape_type = _shape_type(shape)
    return shape_type in {
        MSO_PICTURE,
        MSO_LINKED_PICTURE,
        MSO_GRAPHIC,
        MSO_LINKED_GRAPHIC,
    }


def _has_visual_name(shape) -> bool:
    """Recognize automatic Office names such as Picture 27 or Graphic 4."""
    key = _shape_name_key(shape)
    return (
        key.startswith("picture")
        or key.startswith("image")
        or key.startswith("graphic")
        or key.startswith("chart")
        or "maturitybucketgraph" in key
    )


def _is_graph_visual(shape) -> bool:
    """
    Return True for a copyable chart/picture/graphic visual.

    Some Office versions expose SVGs, enhanced metafiles, or converted chart
    artwork as msoGraphic, msoLinkedGraphic, or even a generic shape carrying
    an automatic Picture/Graphic name. Name-based support is therefore needed
    in addition to the traditional msoPicture and HasChart checks.
    """
    if _has_chart(shape) or _is_picture(shape):
        return True
    shape_type = _shape_type(shape)
    if shape_type == MSO_EMBEDDED_OLE_OBJECT and _has_visual_name(shape):
        return True
    return _has_visual_name(shape)


def _copyable_visual_score(
    shape,
    section_bounds: Bounds | None = None,
) -> float:
    """Score the graph artwork while rejecting icons and heading elements."""
    if not _is_graph_visual(shape):
        return -1.0

    try:
        item = _bounds(shape)
    except Exception:
        return -1.0

    name_key = _shape_name_key(shape)

    # The actual graph is landscape. Thresholds are deliberately lower than
    # before because group-child dimensions can be reported in local units by
    # PowerPoint. Icons remain excluded by size and aspect ratio.
    if item.width < 80.0 or item.height < 40.0:
        return -1.0
    if item.width / max(item.height, 1.0) < 1.15:
        return -1.0

    # Never select the complete section wrapper, heading, icon, or box.
    if name_key in {
        _text_key(SOURCE_GRAPH_GROUP_OBJECT),
        _text_key(TARGET_GRAPH_BOX_OBJECT),
        _text_key(TARGET_TEXT_BG_OBJECT),
        _text_key(TARGET_ICON_OBJECT),
        _text_key(TARGET_TEXT_OBJECT),
    }:
        return -1.0
    if "icon" in name_key or "textbg" in name_key:
        return -1.0

    score = item.width * item.height
    if _has_chart(shape):
        score *= 1.35
    if _is_picture(shape):
        score *= 1.20
    if name_key.startswith("picture"):
        score += 3_000_000_000.0
    elif name_key.startswith("graphic") or name_key.startswith("image"):
        score += 2_500_000_000.0
    elif "maturitybucketgraph" in name_key:
        score += 4_000_000_000.0

    if section_bounds is not None:
        overlap_width = max(
            0.0,
            min(item.right, section_bounds.right)
            - max(item.left, section_bounds.left),
        )
        overlap_height = max(
            0.0,
            min(item.bottom, section_bounds.bottom)
            - max(item.top, section_bounds.top),
        )
        overlap_ratio = (
            overlap_width * overlap_height
            / max(item.width * item.height, 1.0)
        )
        score *= 1.0 + overlap_ratio

    return score


def _log_visual_inventory(slide, logger, source: bool) -> None:
    """Log relevant visual candidates when no graph can be identified."""
    entries: list[str] = []
    for candidate, owner in _iter_shapes_with_owner(slide):
        try:
            shape_type = _shape_type(candidate)
            item = _bounds(candidate)
            name = _shape_name(candidate) or "<unnamed>"
            owner_name = _shape_name(owner) or "<group>"
        except Exception:
            continue
        if (
            _has_visual_name(candidate)
            or _is_picture(candidate)
            or _has_chart(candidate)
            or shape_type in {MSO_GRAPHIC, MSO_LINKED_GRAPHIC}
        ):
            entries.append(
                f"{name}[type={shape_type},w={item.width:.1f},"
                f"h={item.height:.1f},owner={owner_name}]"
            )
        if len(entries) >= 12:
            break
    logger.info(
        "MATURITY_VISUAL_INVENTORY | slide=%s | source=%s | visuals=%s",
        slide.SlideIndex,
        source,
        " | ".join(entries) or "<none>",
    )

def _find_actual_graph_visual(
    slide,
    logger=None,
    source: bool = True,
):
    """
    Find the actual Maturity Bucket graph visual.

    Source rule:
        Select only objects named Picture <number>, for example Picture 27.
        Search recursively inside MaturityBucketAll and across the slide.
        Choose the largest landscape candidate. The number is not fixed.

    Target rule:
        Prefer an existing MaturityBucketGraph object, then a large landscape
        picture/chart. This is used only for positioning or replacement.
    """
    section_wrapper = _find_shape(slide, SOURCE_GRAPH_GROUP_OBJECT)
    section_bounds = None
    if section_wrapper is not None:
        try:
            section_bounds = _bounds(section_wrapper)
        except Exception:
            pass

    candidates: list[tuple[float, object, object, str]] = []
    seen_ids: set[int] = set()

    def consider(candidate, owner, inside_section: bool) -> None:
        try:
            candidate_id = int(candidate.Id)
        except Exception:
            candidate_id = id(candidate)
        if candidate_id in seen_ids:
            return
        seen_ids.add(candidate_id)

        try:
            item = _bounds(candidate)
        except Exception:
            return

        if source:
            # The user-confirmed source graph naming convention is Picture N.
            if not _is_numbered_picture_name(candidate):
                return
            # Reject small Picture N objects such as icons and logos.
            if item.width < 80.0 or item.height < 40.0:
                return
            if item.width / max(item.height, 1.0) < 1.15:
                return

            score = item.width * item.height
            if inside_section:
                score += 5_000_000_000.0
            if section_bounds is not None:
                overlap_width = max(
                    0.0,
                    min(item.right, section_bounds.right)
                    - max(item.left, section_bounds.left),
                )
                overlap_height = max(
                    0.0,
                    min(item.bottom, section_bounds.bottom)
                    - max(item.top, section_bounds.top),
                )
                overlap_ratio = (
                    overlap_width * overlap_height
                    / max(item.width * item.height, 1.0)
                )
                score += overlap_ratio * 1_000_000_000.0
            candidates.append(
                (score, candidate, owner, "numbered_picture")
            )
            return

        # Target lookup is intentionally broader because the pasted output is
        # renamed MaturityBucketGraph after the first successful update.
        score = _copyable_visual_score(candidate, section_bounds)
        if score <= 0:
            return
        if _shape_name_key(candidate) == _text_key(TARGET_GRAPH_OBJECT):
            score += 8_000_000_000.0
        candidates.append((score, candidate, owner, "target_visual"))

    if section_wrapper is not None:
        for candidate, owner in _walk_shape(
            section_wrapper,
            section_wrapper,
        ):
            if candidate is section_wrapper:
                continue
            consider(candidate, owner, inside_section=True)

    for candidate, owner in _iter_shapes_with_owner(slide):
        consider(candidate, owner, inside_section=False)

    if not candidates:
        if logger is not None:
            logger.info(
                "MATURITY_ACTUAL_GRAPH_NOT_FOUND | slide=%s | source=%s | "
                "required_name=%s",
                slide.SlideIndex,
                source,
                "Picture <number>" if source else "landscape visual",
            )
            _log_visual_inventory(slide, logger, source)
        return None

    candidates.sort(key=lambda item: item[0], reverse=True)
    score, graph, owner, reason = candidates[0]

    if logger is not None:
        logger.info(
            "MATURITY_ACTUAL_GRAPH_FOUND | slide=%s | object=%s | "
            "owner=%s | reason=%s | type=%s | width=%.2f | height=%.2f | "
            "source=%s",
            slide.SlideIndex,
            _shape_name(graph) or "<unnamed>",
            _shape_name(owner) or "<group>",
            reason,
            _shape_type(graph),
            float(graph.Width),
            float(graph.Height),
            source,
        )
    return graph


def _find_target_graph_anchor(slide, graph_object: str, box_object: str):
    """Return existing graph or a box-derived placeholder center."""
    exact = _find_shape(slide, graph_object)
    if exact is not None and _is_graph_visual(exact):
        return exact, _bounds(exact)

    actual = _find_actual_graph_visual(slide, source=False)
    if actual is not None:
        return actual, _bounds(actual)

    box = _find_shape(slide, box_object)
    if box is None:
        return None, None

    b = _bounds(box)
    # Use the center of the box's body as the insertion anchor. The fixed graph
    # dimensions are applied afterward.
    return None, Bounds(
        left=b.center_x - MATURITY_GRAPH_WIDTH_PT / 2.0,
        top=b.center_y - MATURITY_GRAPH_HEIGHT_PT / 2.0,
        width=MATURITY_GRAPH_WIDTH_PT,
        height=MATURITY_GRAPH_HEIGHT_PT,
    )


# -----------------------------------------------------------------------------
# Source index
# -----------------------------------------------------------------------------


def _build_source_index(
    source_presentation,
    source_fund_object: str,
    logger,
) -> dict[str, MaturityGraphRecord]:
    records: dict[str, MaturityGraphRecord] = {}
    pending_fund = ""
    pending_slide = 0

    for slide_number in range(1, source_presentation.Slides.Count + 1):
        pythoncom.PumpWaitingMessages()
        slide = source_presentation.Slides.Item(slide_number)

        fund_shape = _find_shape(slide, source_fund_object)
        current_fund = _shape_text(fund_shape) if fund_shape else ""
        if not _is_valid_fund_name(current_fund):
            current_fund = ""

        graph = _find_actual_graph_visual(slide, logger, source=True)

        if graph is None:
            if current_fund:
                pending_fund = current_fund
                pending_slide = slide_number
                logger.info(
                    "MATURITY_SOURCE_FUND_PENDING | slide=%s | fund=%s",
                    slide_number,
                    current_fund,
                )
            continue

        fund_name = current_fund or pending_fund
        fund_slide = slide_number if current_fund else pending_slide
        if not fund_name:
            logger.warning(
                "MATURITY_SOURCE_GRAPH_UNASSIGNED | slide=%s | graph=%s",
                slide_number,
                _shape_name(graph),
            )
            continue

        key = _fund_key(fund_name)
        if key not in records:
            records[key] = MaturityGraphRecord(
                source_slide_number=slide_number,
                source_fund_name=fund_name,
                canonical_fund_name=_canonical_fund_name(fund_name),
            )
            logger.info(
                "MATURITY_SOURCE_FOUND | fund_slide=%s | graph_slide=%s | "
                "fund=%s | actual_graph=%s",
                fund_slide,
                slide_number,
                records[key].canonical_fund_name,
                _shape_name(graph),
            )

        pending_fund = ""
        pending_slide = 0

    if not records:
        raise ValueError(
            "No usable source Maturity Bucket graph pictures or charts were "
            "found. The target presentation was not modified."
        )

    logger.info("MATURITY_SOURCE_INDEX_COMPLETE | funds=%s", len(records))
    return records


# -----------------------------------------------------------------------------
# Copy and deletion
# -----------------------------------------------------------------------------


def _retry_com(name, operation, logger, attempts: int = 6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(
                error,
                "hresult",
                error.args[0]
                if error.args and isinstance(error.args[0], int)
                else None,
            )
            if code not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "MATURITY_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def _copy_actual_graph(
    source_graph,
    target_slide,
    old_target_graph,
    target_bounds: Bounds,
    target_object_name: str,
    logger,
):
    """Copy only the actual source picture/chart and replace the old graph."""
    _retry_com("copy maturity graph", source_graph.Copy, logger)
    pasted_range = _retry_com(
        "paste maturity graph",
        target_slide.Shapes.Paste,
        logger,
    )
    if pasted_range is None or pasted_range.Count < 1:
        raise RuntimeError("PowerPoint did not paste the Maturity Bucket graph.")

    pasted = pasted_range.Item(1)
    try:
        pasted.Name = target_object_name + "_Pending"
    except Exception:
        pass

    try:
        pasted.LockAspectRatio = 0
    except Exception:
        pass

    pasted.Width = MATURITY_GRAPH_WIDTH_PT
    pasted.Height = MATURITY_GRAPH_HEIGHT_PT
    pasted.Left = target_bounds.center_x - MATURITY_GRAPH_WIDTH_PT / 2.0
    pasted.Top = target_bounds.center_y - MATURITY_GRAPH_HEIGHT_PT / 2.0

    pythoncom.PumpWaitingMessages()

    if old_target_graph is not None:
        old_target_graph.Delete()
    try:
        pasted.Name = target_object_name
    except Exception:
        pass

    logger.info(
        "MATURITY_GRAPH_COPY_VERIFIED | slide=%s | source_object=%s | "
        "target_object=%s | width_cm=%.2f | height_cm=%.2f",
        target_slide.SlideIndex,
        _shape_name(source_graph),
        _shape_name(pasted),
        MATURITY_GRAPH_WIDTH_CM,
        MATURITY_GRAPH_HEIGHT_CM,
    )
    return pasted


def _delete_maturity_section(
    slide,
    object_names: tuple[str, ...],
    logger,
) -> int:
    """Delete only explicitly configured Maturity Bucket section objects."""
    owners: dict[str, tuple[object, set[str]]] = {}
    for name in object_names:
        matched, owner = _find_with_owner(slide, name)
        if matched is None or owner is None:
            logger.info(
                "MATURITY_OBJECT_ALREADY_ABSENT | slide=%s | object=%s",
                slide.SlideIndex,
                name,
            )
            continue
        try:
            key = str(owner.Id)
        except Exception:
            key = f"{_shape_name_key(owner)}:{id(owner)}"
        if key not in owners:
            owners[key] = (owner, set())
        owners[key][1].add(name)

    deleted = 0
    for owner, names in list(owners.values()):
        owner_name = _shape_name(owner) or "<group>"
        try:
            owner.Delete()
            deleted += 1
            logger.info(
                "MATURITY_OWNER_DELETED | slide=%s | owner=%s | objects=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(names)),
            )
        except Exception as error:
            logger.warning(
                "MATURITY_OWNER_DELETE_FAILED | slide=%s | owner=%s | "
                "reason=%s",
                slide.SlideIndex,
                owner_name,
                error,
            )
    return deleted


# -----------------------------------------------------------------------------
# Public operation
# -----------------------------------------------------------------------------


def apply_maturity_bucket_graph(
    current_ppt_bytes: bytes,
    maturity_source_ppt_bytes: bytes,
    fund_object: str,
    graph_object: str = TARGET_GRAPH_OBJECT,
    graph_box_object: str = TARGET_GRAPH_BOX_OBJECT,
    text_bg_object: str = TARGET_TEXT_BG_OBJECT,
    icon_object: str = TARGET_ICON_OBJECT,
    logger=None,
    strict: bool = False,
    source_file: str = "",
    source_fund_object: str = SOURCE_FUND_OBJECT,
    source_graph_object: str = SOURCE_GRAPH_OBJECT,
    maturity_text_object: str = TARGET_TEXT_OBJECT,
) -> bytes:
    """
    Copy the actual Maturity Bucket graph picture/chart into target slides.

    MaturityBucketAll is used only as a discovery region. The source graph
    must be named Picture <number>. The group, heading, box, and icon are
    never copied as the graph.
    """
    del source_graph_object  # Actual graph is discovered by visual type/size.

    if logger is None:
        raise ValueError("A logger is required for Maturity Bucket processing.")
    if not current_ppt_bytes or not maturity_source_ppt_bytes:
        raise ValueError("Both target and source PowerPoint files are required.")

    logger.info(
        "MATURITY_START | source_file=%s | target_bytes=%s | source_bytes=%s",
        source_file or "uploaded_maturity.pptx",
        len(current_ppt_bytes),
        len(maturity_source_ppt_bytes),
    )

    pythoncom.CoInitialize()
    powerpoint = source = target = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "maturity_source.pptx"
            target_path = temp / "maturity_target.pptx"
            output_path = temp / "maturity_output.pptx"
            source_path.write_bytes(maturity_source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)

            powerpoint = _retry_com(
                "start PowerPoint",
                lambda: win32com.client.DispatchEx("PowerPoint.Application"),
                logger,
            )
            powerpoint.DisplayAlerts = False
            source = _retry_com(
                "open maturity source",
                lambda: powerpoint.Presentations.Open(
                    str(source_path.resolve()), True, False, False
                ),
                logger,
            )
            target = _retry_com(
                "open maturity target",
                lambda: powerpoint.Presentations.Open(
                    str(target_path.resolve()), False, False, False
                ),
                logger,
            )

            records = _build_source_index(
                source,
                source_fund_object,
                logger,
            )

            updated = unmatched = deleted = skipped = 0
            deletion_names = (
                graph_object,
                graph_box_object,
                text_bg_object,
                icon_object,
                maturity_text_object,
            )

            for slide_number in range(1, target.Slides.Count + 1):
                pythoncom.PumpWaitingMessages()
                slide = target.Slides.Item(slide_number)

                # A maturity target is recognized by any section object, not
                # only an exact MaturityBucketGraph name.
                section_present = any(
                    _find_shape(slide, name) is not None
                    for name in deletion_names
                )
                if not section_present:
                    continue

                fund_shape = _find_shape(slide, fund_object)
                if fund_shape is None:
                    if strict:
                        raise ValueError(
                            f"'{fund_object}' is missing on target slide "
                            f"{slide_number}."
                        )
                    skipped += 1
                    continue

                fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(fund_name))
                if record is None:
                    unmatched += 1
                    deleted += _delete_maturity_section(
                        slide,
                        deletion_names,
                        logger,
                    )
                    logger.info(
                        "MATURITY_DATA_ABSENT | slide=%s | fund=%s",
                        slide_number,
                        fund_name,
                    )
                    continue

                old_graph, target_bounds = _find_target_graph_anchor(
                    slide,
                    graph_object,
                    graph_box_object,
                )
                if target_bounds is None:
                    if strict:
                        raise ValueError(
                            f"No target graph or '{graph_box_object}' anchor "
                            f"was found on slide {slide_number}."
                        )
                    skipped += 1
                    logger.warning(
                        "MATURITY_TARGET_ANCHOR_MISSING | slide=%s | fund=%s",
                        slide_number,
                        fund_name,
                    )
                    continue

                source_slide = source.Slides.Item(record.source_slide_number)
                source_graph = _find_actual_graph_visual(
                    source_slide,
                    logger,
                    source=True,
                )
                if source_graph is None:
                    if strict:
                        raise ValueError(
                            f"The source graph disappeared from slide "
                            f"{record.source_slide_number}."
                        )
                    skipped += 1
                    continue

                _copy_actual_graph(
                    source_graph=source_graph,
                    target_slide=slide,
                    old_target_graph=old_graph,
                    target_bounds=target_bounds,
                    target_object_name=graph_object,
                    logger=logger,
                )
                updated += 1
                logger.info(
                    "MATURITY_GRAPH_UPDATED | target_slide=%s | "
                    "source_slide=%s | fund=%s | width_cm=%.2f | "
                    "height_cm=%.2f",
                    slide_number,
                    record.source_slide_number,
                    record.canonical_fund_name,
                    MATURITY_GRAPH_WIDTH_CM,
                    MATURITY_GRAPH_HEIGHT_CM,
                )

            _retry_com(
                "save maturity target",
                lambda: target.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            target.Close()
            target = None
            source.Close()
            source = None

            output = output_path.read_bytes()
            logger.info(
                "MATURITY_COMPLETE | source_funds=%s | updated=%s | "
                "unmatched=%s | deleted=%s | skipped=%s | bytes=%s",
                len(records),
                updated,
                unmatched,
                deleted,
                skipped,
                len(output),
            )
            return output

    except Exception:
        logger.exception("MATURITY_FAILED")
        raise

    finally:
        for presentation in (target, source):
            if presentation is not None:
                try:
                    presentation.Close()
                except Exception:
                    pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
