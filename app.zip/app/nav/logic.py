from __future__ import annotations

import io
import re
import tempfile
import time
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from config import NAV_FUND_NAME_ALIASES
from utils.powerpoint import find_shape_recursive, normalize, shape_texts


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
PP_ALIGN_LEFT = 1
PP_ALIGN_RIGHT = 3
MSO_FALSE = 0
MSO_TRUE = -1

PP_BORDER_TOP = 1
PP_BORDER_LEFT = 2
PP_BORDER_BOTTOM = 3
PP_BORDER_RIGHT = 4
PP_BORDER_DIAGONAL_DOWN = 5
PP_BORDER_DIAGONAL_UP = 6
ALL_BORDER_TYPES = (
    PP_BORDER_TOP,
    PP_BORDER_LEFT,
    PP_BORDER_BOTTOM,
    PP_BORDER_RIGHT,
    PP_BORDER_DIAGONAL_DOWN,
    PP_BORDER_DIAGONAL_UP,
)

RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846

REQUIRED_HEADERS = {
    "scheme": {"scheme", "scheme name", "fund", "fund name"},
    "plan": {"plan", "plan name", "option", "plan option"},
    "nav": {"nav", "net asset value"},
    "date": {"date", "nav date", "as on date"},
}

# Excel/factsheet name on the left, PowerPoint FundDetails name on the right.
NORMALIZED_NAV_ALIASES = {
    normalize(source): normalize(target)
    for source, target in NAV_FUND_NAME_ALIASES.items()
}

FREQUENCY_ORDER = {
    "generic": 1,
    "daily": 2,
    "weekly": 3,
    "monthly": 4,
    "quarterly": 5,
    "half_yearly": 6,
    "yearly": 7,
}


@dataclass(frozen=True)
class NavRow:
    source_plan: str
    display_plan: str
    nav: str
    plan_group: str
    option_type: str
    frequency: str
    source_row: int


@dataclass(frozen=True)
class FundNavData:
    fund_name: str
    canonical_fund_name: str
    nav_heading: str
    rows: tuple[NavRow, ...]
    sheet_name: str
    nav_date: date


@dataclass(frozen=True)
class BorderStyle:
    visible: int | None = None
    color: int | None = None
    weight: float | None = None
    dash_style: int | None = None
    transparency: float | None = None


@dataclass(frozen=True)
class TextStyle:
    font_name: str | None = None
    font_size: float | None = None
    bold: int | None = None
    italic: int | None = None
    underline: int | None = None
    color: int | None = None
    alignment: int | None = None


def _clean_text(value: object) -> str:
    return " ".join(str(value or "").replace("\xa0", " ").split())


def _display_value(value: object) -> str:
    """Render NAV with exactly four decimals, truncating extra digits."""
    value_text = _clean_text(value)
    if not value_text:
        raise ValueError("Blank NAV value found in the NAV workbook.")
    try:
        number = Decimal(value_text)
    except InvalidOperation as error:
        raise ValueError(f"Invalid NAV value: {value!r}") from error
    number = number.quantize(Decimal("0.0001"), rounding=ROUND_DOWN)
    return format(number, ".4f")


def _canonical_name(excel_name: str) -> str:
    direct = NAV_FUND_NAME_ALIASES.get(excel_name)
    if direct:
        return direct
    excel_key = normalize(excel_name)
    for source, target in NAV_FUND_NAME_ALIASES.items():
        if normalize(source) == excel_key:
            return target
    return excel_name


def _parse_date(value: object) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = _clean_text(value)
    for pattern in (
        "%d-%m-%Y",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%Y-%m-%d",
        "%d-%b-%Y",
    ):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    raise ValueError(f"Invalid NAV date: {value!r}")


def _ordinal_day(day: int) -> str:
    if 10 <= day % 100 <= 20:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
    return f"{day}{suffix}"


def _nav_heading(nav_date: date) -> str:
    return f"NAV as on {_ordinal_day(nav_date.day)} {nav_date.strftime('%B %Y')}"


def _header_type(value: object) -> str | None:
    key = normalize(value)
    for header_type, aliases in REQUIRED_HEADERS.items():
        if key in {normalize(alias) for alias in aliases}:
            return header_type
    return None


def _find_header_row(worksheet) -> tuple[int, dict[str, int]]:
    for row in range(1, min(worksheet.max_row, 25) + 1):
        columns: dict[str, int] = {}
        for column in range(1, worksheet.max_column + 1):
            kind = _header_type(worksheet.cell(row, column).value)
            if kind and kind not in columns:
                columns[kind] = column
        if set(REQUIRED_HEADERS).issubset(columns):
            return row, columns
    raise ValueError(
        f"Required NAV headers were not found in sheet '{worksheet.title}'. "
        "Expected Scheme, Plan, NAV, and Date."
    )


def _plan_group(plan: str) -> str:
    key = normalize(plan)
    # Detect Direct first because source labels such as "Direct Regular IDCW"
    # contain both the words Direct and Regular.
    if re.search(r"\b(?:direct|dir)\b", key):
        return "direct"
    if re.search(r"\bregular\b", key):
        return "regular"
    if re.search(r"\bretail\b", key):
        return "retail"
    return "other"


def _option_type(plan: str) -> str:
    key = normalize(plan)
    if "growth" in key:
        return "growth"
    if "idcw" in key or "dividend" in key:
        return "idcw"
    return "other"


def _frequency(plan: str) -> str:
    key = normalize(plan)
    if re.search(r"\bdaily\b", key):
        return "daily"
    if re.search(r"\bweekly\b", key):
        return "weekly"
    if re.search(r"\bmonthly\b", key):
        return "monthly"
    if re.search(r"\bquarterly\b", key):
        return "quarterly"
    if re.search(r"\bhalf\s*yearly\b|\bsemi\s*annual", key):
        return "half_yearly"
    if re.search(r"\byearly\b|\bannual\b", key):
        return "yearly"
    return "generic"


def _standard_plan_label(plan: str) -> tuple[str, str, str, str]:
    group = _plan_group(plan)
    option = _option_type(plan)
    frequency = _frequency(plan)

    group_label = {
        "regular": "Regular",
        "direct": "Direct",
        "retail": "Retail",
        "other": "",
    }[group]

    if option == "growth":
        label = f"{group_label} Growth".strip()
    elif option == "idcw":
        frequency_label = {
            "generic": "",
            "daily": "Daily ",
            "weekly": "Weekly ",
            "monthly": "Monthly ",
            "quarterly": "Quarterly ",
            "half_yearly": "Half Yearly ",
            "yearly": "Yearly ",
        }[frequency]
        label = f"{group_label} {frequency_label}IDCW".strip()
    else:
        # ETFs and other single-option schemes sometimes have a blank Plan.
        label = _clean_text(plan) or "Growth"

    return label, group, option, frequency


def _nav_sort_key(row: NavRow) -> tuple[int, int, int, str, int]:
    group_rank = {
        "regular": 0,
        "direct": 1,
        "retail": 2,
        "other": 3,
    }.get(row.plan_group, 9)
    option_rank = {
        "growth": 0,
        "idcw": FREQUENCY_ORDER.get(row.frequency, 8),
        "other": 9,
    }.get(row.option_type, 9)
    frequency_rank = FREQUENCY_ORDER.get(row.frequency, 9)
    return (
        group_rank,
        option_rank,
        frequency_rank,
        normalize(row.display_plan),
        row.source_row,
    )


def read_nav_workbook(file_bytes: bytes, logger) -> dict[str, FundNavData]:
    """Read the uploaded XLSX NAV master, group by scheme, and order plans."""
    if not isinstance(file_bytes, bytes) or not file_bytes:
        raise ValueError("A non-empty NAV Excel file is required.")

    logger.info("NAV_EXCEL_START | bytes=%s", len(file_bytes))
    workbook = load_workbook(
        io.BytesIO(file_bytes),
        data_only=True,
        read_only=False,
    )
    records: dict[str, FundNavData] = {}

    try:
        for worksheet in workbook.worksheets:
            try:
                header_row, columns = _find_header_row(worksheet)
            except ValueError as error:
                logger.info(
                    "NAV_SHEET_SKIPPED | sheet=%s | reason=%s",
                    worksheet.title,
                    error,
                )
                continue

            grouped: dict[str, dict[str, object]] = {}
            for row in range(header_row + 1, worksheet.max_row + 1):
                scheme = _clean_text(
                    worksheet.cell(row, columns["scheme"]).value
                )
                plan = _clean_text(
                    worksheet.cell(row, columns["plan"]).value
                )
                nav_value = worksheet.cell(row, columns["nav"]).value
                date_value = worksheet.cell(row, columns["date"]).value

                if not scheme or nav_value in (None, "") or date_value in (None, ""):
                    continue

                nav_date = _parse_date(date_value)
                display_plan, group, option, frequency = _standard_plan_label(plan)
                scheme_key = normalize(scheme)
                item = grouped.setdefault(
                    scheme_key,
                    {
                        "fund_name": scheme,
                        "dates": set(),
                        "rows": [],
                    },
                )
                item["dates"].add(nav_date)
                item["rows"].append(
                    NavRow(
                        source_plan=plan,
                        display_plan=display_plan,
                        nav=_display_value(nav_value),
                        plan_group=group,
                        option_type=option,
                        frequency=frequency,
                        source_row=row,
                    )
                )

            for item in grouped.values():
                fund_name = str(item["fund_name"])
                dates = set(item["dates"])
                if len(dates) != 1:
                    raise ValueError(
                        f"Multiple NAV dates were found for '{fund_name}': "
                        + ", ".join(sorted(value.isoformat() for value in dates))
                    )
                nav_date = next(iter(dates))
                ordered_rows = tuple(sorted(item["rows"], key=_nav_sort_key))
                canonical_name = _canonical_name(fund_name)
                canonical_key = NORMALIZED_NAV_ALIASES.get(
                    normalize(fund_name),
                    normalize(canonical_name),
                )
                if canonical_key in records:
                    raise ValueError(
                        f"Duplicate/colliding NAV fund after aliases: '{fund_name}'."
                    )
                records[canonical_key] = FundNavData(
                    fund_name=fund_name,
                    canonical_fund_name=canonical_name,
                    nav_heading=_nav_heading(nav_date),
                    rows=ordered_rows,
                    sheet_name=worksheet.title,
                    nav_date=nav_date,
                )
                logger.info(
                    "NAV_FUND_READ | sheet=%s | fund=%s | canonical=%s | "
                    "rows=%s | date=%s | order=%s",
                    worksheet.title,
                    fund_name,
                    canonical_name,
                    len(ordered_rows),
                    nav_date.isoformat(),
                    " | ".join(row.display_plan for row in ordered_rows),
                )

        if not records:
            raise ValueError("No valid NAV scheme records were found in the workbook.")
        logger.info("NAV_EXCEL_COMPLETE | funds=%s", len(records))
        return records
    finally:
        workbook.close()


def _match_fund(fund_shape, records: dict[str, FundNavData]) -> FundNavData | None:
    for text in shape_texts(fund_shape):
        key = normalize(text)
        record = records.get(key)
        if record:
            return record
        alias_key = NORMALIZED_NAV_ALIASES.get(key)
        if alias_key and alias_key in records:
            return records[alias_key]
    return None


def _find_text_row(table, predicate, start_row: int = 1):
    for row in range(start_row, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                shape = table.Cell(row, column).Shape
            except Exception:
                continue
            if shape.HasTextFrame and shape.TextFrame.HasText:
                if predicate(normalize(shape.TextFrame.TextRange.Text)):
                    return row, column
    return None, None


def _metric_label_matches(value: object, metric: str) -> bool:
    text = normalize(str(value or ""))
    target = re.escape(normalize(metric))
    return re.match(rf"^{target}(?:\s|:|\(|$)", text, flags=re.IGNORECASE) is not None


def _find_metric_row(table, metric: str, start_row: int = 1):
    for row in range(start_row, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                shape = table.Cell(row, column).Shape
            except Exception:
                continue
            if shape.HasTextFrame and _metric_label_matches(
                shape.TextFrame.TextRange.Text,
                metric,
            ):
                return row, column
    return None, None


def _get_cell(table, row: int, column: int):
    try:
        return table.Cell(row, column)
    except Exception:
        return None


def _capture_text_style(shape) -> TextStyle:
    try:
        text_range = shape.TextFrame.TextRange
        font = text_range.Font
    except Exception:
        return TextStyle()

    def safe(getter):
        try:
            return getter()
        except Exception:
            return None

    return TextStyle(
        font_name=safe(lambda: font.Name),
        font_size=safe(lambda: float(font.Size)),
        bold=safe(lambda: int(font.Bold)),
        italic=safe(lambda: int(font.Italic)),
        underline=safe(lambda: int(font.Underline)),
        color=safe(lambda: int(font.Color.RGB)),
        alignment=safe(lambda: int(text_range.ParagraphFormat.Alignment)),
    )


def _apply_text_style(shape, style: TextStyle, alignment: int) -> None:
    if not shape.HasTextFrame:
        return
    text_range = shape.TextFrame.TextRange
    font = text_range.Font
    for property_name, value in (
        ("Name", style.font_name),
        ("Size", style.font_size),
        ("Bold", style.bold),
        ("Italic", style.italic),
        ("Underline", style.underline),
    ):
        if value is not None:
            try:
                setattr(font, property_name, value)
            except Exception:
                pass
    if style.color is not None:
        try:
            font.Color.RGB = style.color
        except Exception:
            pass
    try:
        text_range.ParagraphFormat.Alignment = alignment
    except Exception:
        pass


def _capture_border(border) -> BorderStyle:
    def safe(getter):
        try:
            return getter()
        except Exception:
            return None
    return BorderStyle(
        visible=safe(lambda: int(border.Visible)),
        color=safe(lambda: int(border.ForeColor.RGB)),
        weight=safe(lambda: float(border.Weight)),
        dash_style=safe(lambda: int(border.DashStyle)),
        transparency=safe(lambda: float(border.Transparency)),
    )


def _apply_border(border, style: BorderStyle) -> None:
    for property_name, value in (
        ("Visible", style.visible),
        ("Weight", style.weight),
        ("DashStyle", style.dash_style),
        ("Transparency", style.transparency),
    ):
        if value is not None:
            try:
                setattr(border, property_name, value)
            except Exception:
                pass
    if style.color is not None:
        try:
            border.ForeColor.RGB = style.color
        except Exception:
            pass


def _capture_row_borders(table, row: int) -> dict[tuple[int, int], BorderStyle]:
    result: dict[tuple[int, int], BorderStyle] = {}
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        for border_type in ALL_BORDER_TYPES:
            try:
                result[(column, border_type)] = _capture_border(
                    cell.Borders(border_type)
                )
            except Exception:
                pass
    return result


def _apply_row_borders(table, row: int, styles: dict[tuple[int, int], BorderStyle]) -> None:
    for (column, border_type), style in styles.items():
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        try:
            _apply_border(cell.Borders(border_type), style)
        except Exception:
            pass


def _set_text(shape, value: str) -> tuple[str, str]:
    text_range = shape.TextFrame.TextRange
    old = str(text_range.Text or "")
    text_range.Text = value
    return old, str(text_range.Text or "")


def _set_nav(shape, value: str) -> tuple[str, str]:
    """Write the NAV as a plain four-decimal value without a currency symbol."""
    return _set_text(shape, value)


def _set_border_invisible(border) -> None:
    """Hide a PowerPoint table border completely."""
    try:
        border.Visible = MSO_FALSE
    except Exception:
        return
    try:
        border.Transparency = 1.0
    except Exception:
        pass


def _remove_all_row_borders(table, row: int) -> None:
    """Remove every border from every accessible cell in one physical row."""
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        for border_type in ALL_BORDER_TYPES:
            try:
                _set_border_invisible(cell.Borders(border_type))
            except Exception:
                pass


def _capture_row_border_type(
    table,
    row: int,
    border_type: int,
) -> dict[int, BorderStyle]:
    """Capture one border type across all accessible cells in a table row."""
    result: dict[int, BorderStyle] = {}
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        try:
            result[column] = _capture_border(cell.Borders(border_type))
        except Exception:
            pass
    return result


def _first_visible_border_style(
    *style_maps: dict[int, BorderStyle],
) -> BorderStyle:
    """Return the first usable visible template border style."""
    for style_map in style_maps:
        for style in style_map.values():
            if style.visible == MSO_TRUE:
                return BorderStyle(
                    visible=MSO_TRUE,
                    color=style.color,
                    weight=style.weight,
                    dash_style=style.dash_style,
                    transparency=0.0,
                )
    return BorderStyle(visible=MSO_TRUE, transparency=0.0)


def _apply_single_row_border(
    table,
    row: int,
    border_type: int,
    style: BorderStyle,
) -> None:
    """Apply one border type across the complete physical table row."""
    visible_style = BorderStyle(
        visible=MSO_TRUE,
        color=style.color,
        weight=style.weight,
        dash_style=style.dash_style,
        transparency=0.0,
    )
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        try:
            _apply_border(cell.Borders(border_type), visible_style)
        except Exception:
            pass


def _finalize_nav_section_borders(
    table,
    heading_row: int,
    first_nav_row: int,
    aum_row: int,
    heading_top_style: BorderStyle,
    heading_bottom_style: BorderStyle,
    aum_top_style: BorderStyle,
) -> None:
    """
    Apply the required NAV border layout.

    - NAV heading: top and bottom borders only.
    - NAV data rows: no internal borders.
    - AUM row: top border only.

    PowerPoint table borders are shared between adjacent rows. Therefore all
    borders are removed first, and the three required separators are applied
    only after cleanup is complete.
    """
    for row in range(heading_row, aum_row + 1):
        _remove_all_row_borders(table, row)

    _apply_single_row_border(
        table,
        heading_row,
        PP_BORDER_TOP,
        heading_top_style,
    )
    _apply_single_row_border(
        table,
        heading_row,
        PP_BORDER_BOTTOM,
        heading_bottom_style,
    )

    # Do not clear the NAV rows again after applying the heading bottom
    # border. PowerPoint stores the heading-bottom and first-NAV-row-top as
    # one shared edge, so clearing the first NAV row here would remove the
    # heading separator that was just applied.

    _apply_single_row_border(
        table,
        aum_row,
        PP_BORDER_TOP,
        aum_top_style,
    )


def _merge_scheme_area(table, row: int) -> None:
    if table.Columns.Count <= 2:
        return
    try:
        table.Cell(row, 1).Merge(table.Cell(row, table.Columns.Count - 1))
    except Exception:
        pass


def _copy_row_template(table, source_row: int, target_row: int) -> None:
    try:
        table.Rows.Item(target_row).Height = table.Rows.Item(source_row).Height
    except Exception:
        pass
    _merge_scheme_area(table, target_row)

    for source_column, target_column in (
        (1, 1),
        (table.Columns.Count, table.Columns.Count),
    ):
        source_cell = _get_cell(table, source_row, source_column)
        target_cell = _get_cell(table, target_row, target_column)
        if source_cell is None or target_cell is None:
            continue
        source = source_cell.Shape
        target = target_cell.Shape
        try:
            source.PickUp()
            target.Apply()
        except Exception:
            pass
        try:
            source.TextFrame.TextRange.Copy()
            target.TextFrame.TextRange.Paste()
        except Exception:
            pass


def _resize_nav_rows(table, first_row: int, aum_row: int, required: int, logger, fund: str, slide: int) -> int:
    if required < 1:
        raise ValueError(f"No NAV rows are available for '{fund}'.")
    existing = aum_row - first_row
    template_row = first_row if existing else max(1, aum_row - 1)

    while existing < required:
        table.Rows.Add(aum_row)
        _copy_row_template(table, template_row, aum_row)
        template_row = aum_row
        aum_row += 1
        existing += 1
        logger.info(
            "NAV_ROW_INSERTED | fund=%s | slide=%s | row=%s | capacity=%s",
            fund,
            slide,
            aum_row - 1,
            existing,
        )

    while existing > required:
        delete_row = aum_row - 1
        table.Rows.Item(delete_row).Delete()
        aum_row -= 1
        existing -= 1
        logger.info(
            "NAV_ROW_DELETED | fund=%s | slide=%s | row=%s | capacity=%s",
            fund,
            slide,
            delete_row,
            existing,
        )

    return aum_row


def _com_code(error: Exception) -> int | None:
    return getattr(
        error,
        "hresult",
        error.args[0] if error.args and isinstance(error.args[0], int) else None,
    )


def _retry_com(name: str, operation, logger, attempts: int = 8):
    delay = 0.75
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            if _com_code(error) not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "NAV_COM_RETRY | operation=%s | attempt=%s/%s | wait=%.2f",
                name,
                attempt,
                attempts,
                delay,
            )
            time.sleep(delay)
            delay = min(4.0, delay * 1.7)


def apply_nav(
    current_ppt_bytes: bytes,
    nav_excel_bytes: bytes,
    fund_object: str,
    scheme_details_object: str,
    logger,
    fail_on_overflow: bool = True,
) -> bytes:
    """
    Match Excel Scheme to PowerPoint FundDetails and populate SchemeDetails.

    fail_on_overflow is retained for app compatibility. The new implementation
    always resizes the NAV section to the exact number of rows required.
    """
    records = read_nav_workbook(nav_excel_bytes, logger)
    logger.info(
        "NAV_STEP_START | ppt_bytes=%s | records=%s | exact_resize=true | "
        "currency_symbol=false | border_mode=heading_top_bottom_aum_top",
        len(current_ppt_bytes),
        len(records),
    )

    pythoncom.CoInitialize()
    powerpoint = presentation = None
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "working.pptx"
            output_path = Path(temp_dir) / "nav_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = _retry_com(
                "start PowerPoint",
                lambda: win32com.client.DispatchEx("PowerPoint.Application"),
                logger,
            )
            _retry_com(
                "set DisplayAlerts",
                lambda: setattr(powerpoint, "DisplayAlerts", False),
                logger,
            )
            presentation = _retry_com(
                "open presentation",
                lambda: powerpoint.Presentations.Open(
                    str(input_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            matched = unmatched = changed = inserted = deleted = 0

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                details = find_shape_recursive(slide.Shapes, scheme_details_object)
                if details is None:
                    continue
                fund_shape = find_shape_recursive(slide.Shapes, fund_object)
                if fund_shape is None:
                    continue

                record = _match_fund(fund_shape, records)
                if record is None:
                    unmatched += 1
                    logger.warning(
                        "NAV_FUND_NOT_MATCHED | slide=%s | ppt_fund=%r",
                        slide_number,
                        " | ".join(shape_texts(fund_shape)),
                    )
                    continue
                if not details.HasTable:
                    raise ValueError(
                        f"'{scheme_details_object}' on slide {slide_number} "
                        "is not a table."
                    )

                table = details.Table
                heading_row, heading_column = _find_text_row(
                    table,
                    lambda text: text.startswith("nav as on"),
                )
                if heading_row is None:
                    raise ValueError(f"NAV heading missing on slide {slide_number}.")
                aum_row, _ = _find_metric_row(
                    table,
                    "AUM",
                    start_row=heading_row + 1,
                )
                if aum_row is None:
                    raise ValueError(
                        f"AUM row missing after NAV on slide {slide_number}."
                    )

                first_row = heading_row + 1
                old_capacity = aum_row - first_row
                scheme_template_style = _capture_text_style(
                    table.Cell(first_row, 1).Shape
                )
                nav_template_style = _capture_text_style(
                    table.Cell(first_row, table.Columns.Count).Shape
                )
                heading_top_map = _capture_row_border_type(
                    table,
                    heading_row,
                    PP_BORDER_TOP,
                )
                heading_bottom_map = _capture_row_border_type(
                    table,
                    heading_row,
                    PP_BORDER_BOTTOM,
                )
                aum_top_map = _capture_row_border_type(
                    table,
                    aum_row,
                    PP_BORDER_TOP,
                )

                # If one requested template border is absent, use another
                # visible separator from the same NAV/AUM section so color,
                # weight, and dash styling remain consistent with the input.
                heading_top_style = _first_visible_border_style(
                    heading_top_map,
                    heading_bottom_map,
                    aum_top_map,
                )
                heading_bottom_style = _first_visible_border_style(
                    heading_bottom_map,
                    heading_top_map,
                    aum_top_map,
                )
                aum_top_style = _first_visible_border_style(
                    aum_top_map,
                    heading_bottom_map,
                    heading_top_map,
                )

                aum_row = _resize_nav_rows(
                    table,
                    first_row,
                    aum_row,
                    len(record.rows),
                    logger,
                    record.canonical_fund_name,
                    slide_number,
                )
                if len(record.rows) > old_capacity:
                    inserted += len(record.rows) - old_capacity
                elif len(record.rows) < old_capacity:
                    deleted += old_capacity - len(record.rows)

                _set_text(
                    table.Cell(heading_row, heading_column).Shape,
                    record.nav_heading,
                )

                for offset, nav_row in enumerate(record.rows):
                    ppt_row = first_row + offset
                    scheme_shape = table.Cell(ppt_row, 1).Shape
                    nav_shape = table.Cell(
                        ppt_row,
                        table.Columns.Count,
                    ).Shape
                    old_scheme, new_scheme = _set_text(
                        scheme_shape,
                        nav_row.display_plan,
                    )
                    old_nav, new_nav = _set_nav(nav_shape, nav_row.nav)
                    _apply_text_style(
                        scheme_shape,
                        scheme_template_style,
                        PP_ALIGN_LEFT,
                    )
                    _apply_text_style(
                        nav_shape,
                        nav_template_style,
                        PP_ALIGN_RIGHT,
                    )
                    # NAV data rows must remain completely borderless.
                    _remove_all_row_borders(table, ppt_row)
                    changed += 1
                    logger.info(
                        "NAV_ROW_CHANGED | fund=%s | slide=%s | row=%s | "
                        "source_plan=%s | display_plan=%s | nav=%s",
                        record.canonical_fund_name,
                        slide_number,
                        ppt_row,
                        nav_row.source_plan,
                        new_scheme,
                        new_nav,
                    )

                # This is the final formatting operation for the NAV
                # section. It removes every internal NAV border and leaves only
                # heading top/bottom plus the top separator above AUM.
                _finalize_nav_section_borders(
                    table=table,
                    heading_row=heading_row,
                    first_nav_row=first_row,
                    aum_row=aum_row,
                    heading_top_style=heading_top_style,
                    heading_bottom_style=heading_bottom_style,
                    aum_top_style=aum_top_style,
                )

                matched += 1
                logger.info(
                    "NAV_FUND_UPDATED | fund=%s | slide=%s | heading=%s | "
                    "rows=%s | order=%s",
                    record.canonical_fund_name,
                    slide_number,
                    record.nav_heading,
                    len(record.rows),
                    " | ".join(row.display_plan for row in record.rows),
                )

            _retry_com(
                "save presentation",
                lambda: presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            _retry_com("close presentation", presentation.Close, logger, attempts=4)
            presentation = None
            output = output_path.read_bytes()
            logger.info(
                "NAV_STEP_COMPLETE | matched=%s | unmatched=%s | "
                "rows_changed=%s | rows_inserted=%s | rows_deleted=%s | "
                "bytes=%s",
                matched,
                unmatched,
                changed,
                inserted,
                deleted,
                len(output),
            )
            return output
    except Exception:
        logger.exception("NAV_STEP_FAILED")
        raise
    finally:
        if presentation is not None:
            try:
                _retry_com(
                    "cleanup close presentation",
                    presentation.Close,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass
        if powerpoint is not None:
            try:
                _retry_com(
                    "quit PowerPoint",
                    powerpoint.Quit,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass
        pythoncom.CoUninitialize()
