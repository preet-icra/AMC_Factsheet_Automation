from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive, normalize


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_GROUP = 6

MARKET_CAP_METRICS = (
    "Large Cap",
    "Mid Cap",
    "Small Cap",
    "Cash & Others",
)

# Source PowerPoint fund name -> target FundDetails name.
MARKET_CAP_FUND_NAME_ALIASES: dict[str, str] = {
    "Axis Focused 25 Fund": "Axis Focused Fund",
}


@dataclass(frozen=True)
class SourceMarketCapRecord:
    source_slide_number: int
    source_fund_name: str
    canonical_fund_name: str
    values: dict[str, str]


# -----------------------------------------------------------------------------
# Text, fund-name, and metric normalization
# -----------------------------------------------------------------------------


def _canonical_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _canonical_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    """Remove plan/option suffixes before matching source and target funds."""
    text = _canonical_text(value)

    text = re.sub(
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*"
        r"growth(?:\s+option)?\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    text = re.sub(
        r"\s*-\s*growth(?:\s+option)?\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    text = re.sub(
        r"\s*-\s*(?:compulsory\s+lock-in|no\s+lock-in)(?=\s*-|$)",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    text = re.sub(
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base = _base_fund_name(value)
    key = _text_key(base)
    for source_name, target_name in MARKET_CAP_FUND_NAME_ALIASES.items():
        if _text_key(source_name) == key:
            return target_name
    return base


def _fund_key(value: object) -> str:
    return normalize(_canonical_text(_canonical_fund_name(value)))


def _metric_name(value: object) -> str | None:
    """Return a metric only when the complete cell is a Market Cap label."""
    text = _canonical_text(value).casefold().replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text).strip()
    aliases = {
        "large cap": "Large Cap",
        "mid cap": "Mid Cap",
        "small cap": "Small Cap",
        "cash and others": "Cash & Others",
        "cash others": "Cash & Others",
    }
    return aliases.get(text)


def _looks_like_market_cap_value(value: object) -> bool:
    text = _canonical_text(value)
    if not text:
        return False
    return bool(
        re.fullmatch(
            r"[-+]?\s*(?:\d+(?:\.\d+)?|\.\d+)\s*%?",
            text.replace(",", ""),
        )
    )


def _format_market_cap_value(value: object) -> str:
    """Preserve source display text and ensure percentage notation."""
    text = _canonical_text(value)
    if not text:
        return ""
    if text.endswith("%"):
        return text

    number = float(text.replace(",", ""))
    # PowerPoint sources normally contain display percentages such as 95.67.
    # Decimal fractions such as 0.9567 are converted to 95.67%.
    if abs(number) <= 1:
        number *= 100
    return f"{number:.2f}%"


# -----------------------------------------------------------------------------
# Safe PowerPoint shape and table access
# -----------------------------------------------------------------------------


def _shape_text(shape) -> str:
    """Return visible text from a normal shape, group, or table."""
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                child_text = _shape_text(shape.GroupItems.Item(index))
                if child_text:
                    parts.append(child_text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    try:
                        cell_shape = table.Cell(row, column).Shape
                    except Exception:
                        continue
                    if cell_shape.HasTextFrame and cell_shape.TextFrame.HasText:
                        parts.append(str(cell_shape.TextFrame.TextRange.Text or ""))
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(str(shape.TextFrame.TextRange.Text or ""))
    except Exception:
        return ""
    return " ".join(
        _canonical_text(part) for part in parts if part
    ).strip()


def _cell_text(table, row: int, column: int) -> str:
    try:
        shape = table.Cell(row, column).Shape
        if shape.HasTextFrame and shape.TextFrame.HasText:
            return _canonical_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def _set_cell_text_preserve_format(cell_shape, text: str) -> None:
    """
    Replace cell text while retaining target fonts, fills, borders, and layout.
    """
    if not cell_shape.HasTextFrame:
        raise ValueError("The Market Cap value cell does not support text.")

    text_range = cell_shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")
    if old_text:
        text_range.Characters(1, len(old_text)).Text = str(text)
    else:
        text_range.Text = str(text)


def _iter_shapes(shape_or_shapes):
    """Yield shapes recursively, including tables inside grouped MarketCap."""
    try:
        count = shape_or_shapes.Count
    except Exception:
        count = None

    if count is not None:
        for index in range(1, count + 1):
            try:
                shape = shape_or_shapes.Item(index)
            except Exception:
                continue
            yield shape
            try:
                if int(shape.Type) == MSO_GROUP:
                    yield from _iter_shapes(shape.GroupItems)
            except Exception:
                pass
        return

    shape = shape_or_shapes
    yield shape
    try:
        if int(shape.Type) == MSO_GROUP:
            yield from _iter_shapes(shape.GroupItems)
    except Exception:
        pass


def _find_tables_in_shape(shape) -> list:
    tables = []
    for candidate in _iter_shapes(shape):
        try:
            if candidate.HasTable:
                tables.append(candidate.Table)
        except Exception:
            continue
    return tables


# -----------------------------------------------------------------------------
# Source MarketCap extraction
# -----------------------------------------------------------------------------


def _read_market_cap_table(table) -> dict[str, str]:
    """
    Read exact label/value pairs from a source MarketCap table.

    The expected visual layout is:
      Large Cap | value | Mid Cap | value | Small Cap | value |
      Cash & Others | value

    A label may appear in any row or column. The value is read from the cell
    immediately to the right of the exact label cell.
    """
    values: dict[str, str] = {}

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            metric = _metric_name(_cell_text(table, row, column))
            if metric is None or column >= table.Columns.Count:
                continue

            raw_value = _cell_text(table, row, column + 1)
            if not _looks_like_market_cap_value(raw_value):
                continue

            values[metric] = _format_market_cap_value(raw_value)

    return values


def _extract_market_cap_values(market_cap_shape) -> dict[str, str]:
    """Extract values from MarketCap whether it is a table or a group."""
    best_values: dict[str, str] = {}
    for table in _find_tables_in_shape(market_cap_shape):
        values = _read_market_cap_table(table)
        if len(values) > len(best_values):
            best_values = values
        if len(best_values) == len(MARKET_CAP_METRICS):
            break
    return best_values


def _build_source_index(
    source_presentation,
    source_fund_object: str,
    source_market_cap_object: str,
    logger,
) -> dict[str, SourceMarketCapRecord]:
    """
    Index source slides containing FundName and usable MarketCap percentages.
    """
    records: dict[str, SourceMarketCapRecord] = {}

    for slide_number in range(1, source_presentation.Slides.Count + 1):
        pythoncom.PumpWaitingMessages()
        slide = source_presentation.Slides.Item(slide_number)
        fund_shape = find_shape_recursive(
            slide.Shapes,
            source_fund_object,
        )
        market_cap_shape = find_shape_recursive(
            slide.Shapes,
            source_market_cap_object,
        )

        if fund_shape is None or market_cap_shape is None:
            logger.info(
                "MARKET_CAP_SOURCE_SLIDE_SKIPPED | slide=%s | "
                "fund_found=%s | market_cap_found=%s",
                slide_number,
                fund_shape is not None,
                market_cap_shape is not None,
            )
            continue

        source_fund_name = _shape_text(fund_shape)
        key = _fund_key(source_fund_name)
        if not key:
            logger.warning(
                "MARKET_CAP_SOURCE_SLIDE_SKIPPED | slide=%s | "
                "reason=blank FundName",
                slide_number,
            )
            continue

        values = _extract_market_cap_values(market_cap_shape)
        required = {"Large Cap", "Mid Cap", "Small Cap"}
        missing = required - values.keys()
        if missing:
            logger.warning(
                "MARKET_CAP_SOURCE_SLIDE_SKIPPED | slide=%s | fund=%s | "
                "reason=missing metrics | missing=%s",
                slide_number,
                source_fund_name,
                ",".join(sorted(missing)),
            )
            continue

        record = SourceMarketCapRecord(
            source_slide_number=slide_number,
            source_fund_name=source_fund_name,
            canonical_fund_name=_canonical_fund_name(source_fund_name),
            values={
                metric: values.get(metric, "")
                for metric in MARKET_CAP_METRICS
            },
        )

        if key in records:
            logger.warning(
                "MARKET_CAP_SOURCE_DUPLICATE | fund=%s | "
                "retained_slide=%s | ignored_slide=%s",
                record.canonical_fund_name,
                records[key].source_slide_number,
                slide_number,
            )
            continue

        records[key] = record
        logger.info(
            "MARKET_CAP_SOURCE_FOUND | slide=%s | fund=%s | "
            "canonical=%s | values=%s",
            slide_number,
            source_fund_name,
            record.canonical_fund_name,
            record.values,
        )

    if not records:
        raise ValueError(
            f"No usable source Market Cap data was found. Each source slide "
            f"must contain '{source_fund_object}' and "
            f"'{source_market_cap_object}', and the MarketCap table must "
            "contain exact labels for Large Cap, Mid Cap, and Small Cap."
        )

    logger.info(
        "MARKET_CAP_SOURCE_INDEX_COMPLETE | funds=%s",
        len(records),
    )
    return records


# -----------------------------------------------------------------------------
# Target MarketCapTable update
# -----------------------------------------------------------------------------


def _update_target_market_cap_table(
    target_shape,
    values: dict[str, str],
) -> int:
    """
    Write source percentages into the existing target MarketCapTable.

    Only value-cell text is changed. The target title, labels, disclosure row,
    fills, borders, fonts, position, width, height, and object name remain.
    """
    if not target_shape.HasTable:
        raise ValueError(
            "MarketCapTable exists but is not a PowerPoint table."
        )

    table = target_shape.Table
    updated: set[str] = set()

    # Preferred layout shown in the target image:
    # row 2 -> label/value pairs in columns 1/2, 3/4, 5/6, and 7/8.
    expected_positions = {
        "Large Cap": (2, 1, 2),
        "Mid Cap": (2, 3, 4),
        "Small Cap": (2, 5, 6),
        "Cash & Others": (2, 7, 8),
    }

    if table.Rows.Count >= 2 and table.Columns.Count >= 8:
        for metric, (row, label_column, value_column) in (
            expected_positions.items()
        ):
            if _metric_name(_cell_text(table, row, label_column)) != metric:
                continue
            value_shape = table.Cell(row, value_column).Shape
            _set_cell_text_preserve_format(
                value_shape,
                values.get(metric, ""),
            )
            updated.add(metric)

    # Safe exact-label fallback if the label/value columns have moved.
    for metric in MARKET_CAP_METRICS:
        if metric in updated:
            continue

        for row in range(1, table.Rows.Count + 1):
            found = False
            for column in range(1, table.Columns.Count + 1):
                if _metric_name(_cell_text(table, row, column)) != metric:
                    continue
                if column >= table.Columns.Count:
                    raise ValueError(
                        f"The '{metric}' label in MarketCapTable has no value "
                        "cell immediately to its right."
                    )

                value_shape = table.Cell(row, column + 1).Shape
                _set_cell_text_preserve_format(
                    value_shape,
                    values.get(metric, ""),
                )
                updated.add(metric)
                found = True
                break
            if found:
                break

    required = {"Large Cap", "Mid Cap", "Small Cap"}
    missing = required - updated
    if missing:
        raise ValueError(
            "MarketCapTable is missing exact target label cell(s): "
            + ", ".join(sorted(missing))
            + "."
        )

    # Cash & Others is optional in the source. Its target value is cleared when
    # absent, preventing stale template data from remaining visible.
    return len(updated)


def _delete_target_market_cap(
    slide,
    target_object_name: str,
    logger,
    reason: str,
) -> bool:
    shape = find_shape_recursive(slide.Shapes, target_object_name)
    if shape is None:
        logger.info(
            "MARKET_CAP_TARGET_ALREADY_ABSENT | slide=%s | reason=%s",
            slide.SlideIndex,
            reason,
        )
        return False

    shape.Delete()
    logger.info(
        "MARKET_CAP_TARGET_DELETED | slide=%s | object=%s | reason=%s",
        slide.SlideIndex,
        target_object_name,
        reason,
    )
    return True


# -----------------------------------------------------------------------------
# COM helpers and public operation
# -----------------------------------------------------------------------------


def _retry_com(name: str, operation, logger, attempts: int = 6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(
                error,
                "hresult",
                error.args[0]
                if error.args and isinstance(error.args[0], int)
                else None,
            )
            if code not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "MARKET_CAP_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def apply_market_cap(
    current_ppt_bytes: bytes,
    market_cap_source_ppt_bytes: bytes | None = None,
    fund_object: str = "FundDetails",
    market_cap_table_object: str = "MarketCapTable",
    logger=None,
    strict: bool = False,
    source_file: str = "",
    source_fund_object: str = "FundName",
    source_market_cap_object: str = "MarketCap",
    # Legacy keyword retained for a clear migration message.
    market_cap_excel_bytes: bytes | None = None,
) -> bytes:
    """
    Copy Market Cap percentages from a source PPT into target MarketCapTable.

    Source:
      FundName  -> fund used for matching
      MarketCap -> table/group containing the four label/value pairs

    Target:
      FundDetails    -> fund used for matching
      MarketCapTable -> existing table whose value cells are updated
    """
    if logger is None:
        raise ValueError("A logger is required for Market Cap processing.")

    if market_cap_source_ppt_bytes is None:
        if market_cap_excel_bytes is not None:
            raise ValueError(
                "Market Cap now requires a source PowerPoint instead of Excel. "
                "Pass market_cap_source_ppt_bytes to apply_market_cap()."
            )
        raise ValueError("Upload a source Market Cap PowerPoint file.")

    if not current_ppt_bytes:
        raise ValueError("The target PowerPoint is empty.")
    if not market_cap_source_ppt_bytes:
        raise ValueError("The source Market Cap PowerPoint is empty.")

    logger.info(
        "MARKET_CAP_START | source_file=%s | target_bytes=%s | "
        "source_bytes=%s | strict=%s",
        source_file or "uploaded_market_cap.pptx",
        len(current_ppt_bytes),
        len(market_cap_source_ppt_bytes),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = source_presentation = target_presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "market_cap_source.pptx"
            target_path = temp / "market_cap_target.pptx"
            output_path = temp / "market_cap_output.pptx"
            source_path.write_bytes(market_cap_source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.DisplayAlerts = False

            source_presentation = _retry_com(
                "open Market Cap source presentation",
                lambda: powerpoint.Presentations.Open(
                    str(source_path.resolve()),
                    True,
                    False,
                    False,
                ),
                logger,
            )
            target_presentation = _retry_com(
                "open Market Cap target presentation",
                lambda: powerpoint.Presentations.Open(
                    str(target_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            source_index = _build_source_index(
                source_presentation,
                source_fund_object,
                source_market_cap_object,
                logger,
            )

            matched = unmatched = updated = deleted = skipped = 0
            total_changes = 0

            for slide_number in range(1, target_presentation.Slides.Count + 1):
                pythoncom.PumpWaitingMessages()
                target_slide = target_presentation.Slides.Item(slide_number)
                target_table = find_shape_recursive(
                    target_slide.Shapes,
                    market_cap_table_object,
                )

                # Slides without MarketCapTable are not Market Cap targets.
                if target_table is None:
                    continue

                target_fund_shape = find_shape_recursive(
                    target_slide.Shapes,
                    fund_object,
                )
                if target_fund_shape is None:
                    message = (
                        f"Object '{fund_object}' is missing on target Market "
                        f"Cap slide {slide_number}."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "MARKET_CAP_TARGET_SKIPPED | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped += 1
                    continue

                target_fund_name = _shape_text(target_fund_shape)
                record = source_index.get(_fund_key(target_fund_name))

                # No usable MarketCap record for this fund: remove the complete
                # target MarketCapTable so stale template values cannot remain.
                if record is None:
                    unmatched += 1
                    deleted += int(
                        _delete_target_market_cap(
                            target_slide,
                            market_cap_table_object,
                            logger,
                            "fund has no usable source MarketCap data",
                        )
                    )
                    continue

                try:
                    changes = _update_target_market_cap_table(
                        target_table,
                        record.values,
                    )
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "MARKET_CAP_TARGET_INVALID | slide=%s | fund=%s | "
                        "reason=%s | action=table_deleted",
                        slide_number,
                        target_fund_name,
                        error,
                    )
                    deleted += int(
                        _delete_target_market_cap(
                            target_slide,
                            market_cap_table_object,
                            logger,
                            f"target table cannot be updated: {error}",
                        )
                    )
                    skipped += 1
                    continue

                matched += 1
                updated += 1
                total_changes += changes
                logger.info(
                    "MARKET_CAP_UPDATED | target_slide=%s | source_slide=%s | "
                    "fund=%s | values=%s | changes=%s",
                    slide_number,
                    record.source_slide_number,
                    record.canonical_fund_name,
                    record.values,
                    changes,
                )

            _retry_com(
                "save Market Cap target presentation",
                lambda: target_presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            target_presentation.Close()
            target_presentation = None
            source_presentation.Close()
            source_presentation = None

            output = output_path.read_bytes()
            if not output:
                raise RuntimeError("The generated Market Cap PowerPoint is empty.")

            logger.info(
                "MARKET_CAP_COMPLETE | source_funds=%s | matched=%s | "
                "unmatched=%s | updated=%s | deleted=%s | skipped=%s | "
                "changes=%s | bytes=%s",
                len(source_index),
                matched,
                unmatched,
                updated,
                deleted,
                skipped,
                total_changes,
                len(output),
            )
            return output

    except Exception:
        logger.exception("MARKET_CAP_FAILED")
        raise

    finally:
        for presentation in (target_presentation, source_presentation):
            if presentation is not None:
                try:
                    presentation.Close()
                except Exception:
                    pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
