from __future__ import annotations

import io
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
MARKET_CAP_METRICS = (
    "Large Cap",
    "Mid Cap",
    "Small Cap",
    "Cash & Others",
)


@dataclass(frozen=True)
class MarketCapRecord:
    fund_name: str
    canonical_fund_name: str
    values: dict[str, float | None]
    sheet_name: str
    header_row: int
    source_file: str = ""


def _canonical_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _fund_key(value: object) -> str:
    return normalize(_canonical_text(value))


def _metric_name(value: object) -> str | None:
    """Return a metric only when the complete cell is a market-cap label."""
    text = _canonical_text(value).casefold()
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text).strip()

    aliases = {
        "large cap": "Large Cap",
        "mid cap": "Mid Cap",
        "small cap": "Small Cap",
        "cash and others": "Cash & Others",
        "cash others": "Cash & Others",
    }
    return aliases.get(text)


def _to_number(value: object) -> float | None:
    if value is None or value == "":
        return None
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        if not text:
            return None
        if text.endswith("%"):
            return float(text[:-1]) / 100.0
        return float(text)
    return float(value)


def _looks_like_fund_name(value: object) -> bool:
    text = _canonical_text(value)
    key = _fund_key(text)
    excluded = {
        "",
        _fund_key("Row Labels"),
        _fund_key("Grand Total"),
        *(_fund_key(metric) for metric in MARKET_CAP_METRICS),
    }
    return bool(text) and key not in excluded and (
        "fund" in text.casefold() or "etf" in text.casefold()
    )


def read_market_cap_excel(
    excel_bytes: bytes,
    logger,
    source_file: str = "",
) -> dict[str, MarketCapRecord]:
    """Read horizontal market-cap blocks from the supplied XLSX workbook."""
    logger.info(
        "MARKET_CAP_FILE_START | file=%s | bytes=%s",
        source_file or "uploaded.xlsx",
        len(excel_bytes),
    )
    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=True,
    )
    records: dict[str, MarketCapRecord] = {}

    for worksheet in workbook.worksheets:
        for header_row in range(1, worksheet.max_row + 1):
            metric_rows: dict[str, int] = {}
            for row in range(header_row + 1, min(header_row + 7, worksheet.max_row) + 1):
                metric = _metric_name(worksheet.cell(row, 1).value)
                if metric:
                    metric_rows[metric] = row

            if not {"Large Cap", "Mid Cap", "Small Cap"}.issubset(metric_rows):
                continue

            for column in range(2, worksheet.max_column + 1):
                fund_name = _canonical_text(worksheet.cell(header_row, column).value)
                if not _looks_like_fund_name(fund_name):
                    continue

                values = {
                    metric: _to_number(worksheet.cell(row, column).value)
                    for metric, row in metric_rows.items()
                }
                key = _fund_key(fund_name)
                if key in records:
                    raise ValueError(
                        f"Duplicate Market Cap fund name found: {fund_name}."
                    )

                records[key] = MarketCapRecord(
                    fund_name=fund_name,
                    canonical_fund_name=fund_name,
                    values={metric: values.get(metric) for metric in MARKET_CAP_METRICS},
                    sheet_name=worksheet.title,
                    header_row=header_row,
                    source_file=source_file,
                )

    if not records:
        raise ValueError(
            "No Market Cap records were found. Expected fund names across a "
            "header row and Large Cap, Mid Cap, Small Cap, and optional "
            "Cash & Others labels in column A."
        )

    logger.info("MARKET_CAP_FILE_COMPLETE | records=%s", len(records))
    for record in records.values():
        logger.info(
            "MARKET_CAP_FUND_FOUND | fund=%s | sheet=%s | header_row=%s",
            record.fund_name,
            record.sheet_name,
            record.header_row,
        )
    return records


def format_market_cap(value: float | None) -> str:
    """Format an Excel decimal as a PowerPoint percentage with 2 decimals."""
    if value is None:
        return ""
    return f"{value:.2%}"


def _shape_text(shape) -> str:
    """Return text from a normal shape, group, or table."""
    parts: list[str] = []
    try:
        if shape.Type == 6:  # msoGroup
            for index in range(1, shape.GroupItems.Count + 1):
                text = _shape_text(shape.GroupItems.Item(index))
                if text:
                    parts.append(text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    cell = table.Cell(row, column).Shape
                    if cell.HasTextFrame and cell.TextFrame.HasText:
                        parts.append(str(cell.TextFrame.TextRange.Text or ""))
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(str(shape.TextFrame.TextRange.Text or ""))
    except Exception:
        return ""
    return " ".join(_canonical_text(part) for part in parts if part).strip()


def _set_cell_text_preserve_format(cell_shape, text: str) -> None:
    """Replace cell text without changing fill, border, size, or positioning."""
    text_range = cell_shape.TextFrame.TextRange
    text_range.Text = text


def _update_market_cap_table(
    shape,
    values: dict[str, float | None],
) -> int:
    """
    Update MarketCapTable values in row 2.

    Preferred layout:
        Large Cap label     = row 2, column 1
        Large Cap value     = row 2, column 2
        Mid Cap label       = row 2, column 3
        Mid Cap value       = row 2, column 4
        Small Cap label     = row 2, column 5
        Small Cap value     = row 2, column 6
        Cash & Others label = row 2, column 7
        Cash & Others value = row 2, column 8

    If the value columns move, an exact-label fallback searches table cells and
    updates only the cell immediately to the right. The exact match prevents
    the disclosure paragraph in row 3 from being treated as a metric label.
    """
    if not shape.HasTable:
        raise ValueError(
            "MarketCapTable exists but is not a PowerPoint table."
        )

    table = shape.Table
    expected_positions = {
        "Large Cap": (2, 1, 2),
        "Mid Cap": (2, 3, 4),
        "Small Cap": (2, 5, 6),
        "Cash & Others": (2, 7, 8),
    }

    changed = 0
    updated_metrics: set[str] = set()

    # Primary method: use the known row-2 layout. Validate each label before
    # writing so a changed table structure cannot receive data in a wrong cell.
    if table.Rows.Count >= 2 and table.Columns.Count >= 8:
        for metric, (row, label_column, value_column) in (
            expected_positions.items()
        ):
            label_shape = table.Cell(row, label_column).Shape
            label_text = ""
            if (
                label_shape.HasTextFrame
                and label_shape.TextFrame.HasText
            ):
                label_text = label_shape.TextFrame.TextRange.Text

            if _metric_name(label_text) != metric:
                continue

            value = values.get(metric)
            formatted_value = format_market_cap(value)
            value_shape = table.Cell(row, value_column).Shape
            _set_cell_text_preserve_format(
                value_shape,
                formatted_value,
            )
            updated_metrics.add(metric)
            changed += 1

    # Safe fallback: look for exact label-only cells. Never use substring
    # matching because the disclosure row contains market-cap terminology.
    for metric in expected_positions:
        if metric in updated_metrics:
            continue

        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell_shape = table.Cell(row, column).Shape
                if not (
                    cell_shape.HasTextFrame
                    and cell_shape.TextFrame.HasText
                ):
                    continue

                label_text = cell_shape.TextFrame.TextRange.Text
                if _metric_name(label_text) != metric:
                    continue

                if column >= table.Columns.Count:
                    raise ValueError(
                        f"The '{metric}' label has no value cell "
                        "immediately to its right."
                    )

                value_shape = table.Cell(row, column + 1).Shape
                _set_cell_text_preserve_format(
                    value_shape,
                    format_market_cap(values.get(metric)),
                )
                updated_metrics.add(metric)
                changed += 1
                break

            if metric in updated_metrics:
                break

    required_metrics = {
        "Large Cap",
        "Mid Cap",
        "Small Cap",
    }
    missing = required_metrics - updated_metrics
    if missing:
        raise ValueError(
            "MarketCapTable is missing exact label cell(s): "
            + ", ".join(sorted(missing))
            + ". Expected labels in row 2 at columns 1, 3, and 5, "
            "with value cells at columns 2, 4, and 6."
        )

    # Cash & Others is optional in some Excel sections, but its PowerPoint
    # value cell is cleared when no Excel value exists, avoiding stale data.
    return changed


def apply_market_cap(
    current_ppt_bytes: bytes,
    market_cap_excel_bytes: bytes,
    fund_object: str,
    market_cap_table_object: str,
    logger,
    strict: bool = False,
    source_file: str = "",
) -> bytes:
    """Match FundDetails to Excel and update MarketCapTable on each slide."""
    records = read_market_cap_excel(
        market_cap_excel_bytes,
        logger,
        source_file=source_file,
    )

    logger.info(
        "MARKET_CAP_START | ppt_bytes=%s | excel_records=%s | strict=%s",
        len(current_ppt_bytes),
        len(records),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "market_cap_input.pptx"
            output_path = Path(temp_dir) / "market_cap_output.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False
            presentation = powerpoint.Presentations.Open(
                str(input_path.resolve()), False, False, False
            )

            updated_slides = 0
            deleted_tables = 0
            skipped_slides = 0
            total_changes = 0

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                fund_shape = find_shape_recursive(slide.Shapes, fund_object)

                if fund_shape is None:
                    message = f"Object '{fund_object}' missing on slide {slide_number}."
                    if strict:
                        raise ValueError(message)
                    logger.warning("MARKET_CAP_SKIP | slide=%s | reason=%s", slide_number, message)
                    skipped_slides += 1
                    continue

                ppt_fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(ppt_fund_name))

                table_shape = find_shape_recursive(
                    slide.Shapes,
                    market_cap_table_object,
                )

                # No Excel record, or a record with no usable Market Cap data:
                # delete MarketCapTable from this slide instead of leaving the
                # template's sample/stale values visible.
                has_market_cap_data = (
                    record is not None
                    and any(
                        record.values.get(metric) is not None
                        for metric in MARKET_CAP_METRICS
                    )
                )

                if not has_market_cap_data:
                    reason = (
                        "no matching Excel fund record"
                        if record is None
                        else "matching Excel record has no Market Cap values"
                    )

                    if table_shape is not None:
                        table_shape.Delete()
                        deleted_tables += 1
                        logger.info(
                            "MARKET_CAP_TABLE_DELETED | slide=%s | "
                            "fund=%s | reason=%s",
                            slide_number,
                            ppt_fund_name,
                            reason,
                        )
                    else:
                        logger.info(
                            "MARKET_CAP_TABLE_ALREADY_ABSENT | slide=%s | "
                            "fund=%s | reason=%s",
                            slide_number,
                            ppt_fund_name,
                            reason,
                        )

                    table_shape = None
                    fund_shape = None
                    slide = None
                    continue

                if table_shape is None:
                    message = (
                        f"Object '{market_cap_table_object}' missing on slide "
                        f"{slide_number} for fund '{ppt_fund_name}'."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "MARKET_CAP_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped_slides += 1
                    continue

                try:
                    changes = _update_market_cap_table(
                        table_shape,
                        record.values,
                    )
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "MARKET_CAP_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        ppt_fund_name,
                        error,
                    )
                    skipped_slides += 1
                    continue

                if changes == 0:
                    message = (
                        f"No Market Cap values were updated for "
                        f"'{ppt_fund_name}'."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "MARKET_CAP_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped_slides += 1
                    continue

                total_changes += changes
                updated_slides += 1
                logger.info(
                    "MARKET_CAP_UPDATED | slide=%s | fund=%s | values=%s",
                    slide_number,
                    ppt_fund_name,
                    changes,
                )

                table_shape = None
                fund_shape = None
                slide = None

            presentation.SaveAs(
                str(output_path.resolve()),
                PP_SAVE_AS_OPEN_XML_PRESENTATION,
            )
            presentation.Close()
            presentation = None
            output = output_path.read_bytes()

            logger.info(
                "MARKET_CAP_COMPLETE | slides_updated=%s | "
                "tables_deleted=%s | slides_skipped=%s | "
                "changes=%s | bytes=%s",
                updated_slides,
                deleted_tables,
                skipped_slides,
                total_changes,
                len(output),
            )
            return output

    except Exception:
        logger.exception("MARKET_CAP_FAILED")
        raise
    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        presentation = None
        powerpoint = None
        pythoncom.CoUninitialize()
