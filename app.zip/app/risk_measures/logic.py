from __future__ import annotations

import io
import re
import tempfile
import time
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize, shape_texts

try:
    from config import RISK_MEASURES_FUND_ALIASES as CONFIG_RISK_ALIASES
except ImportError:
    CONFIG_RISK_ALIASES: dict[str, str] = {}

PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RISK_VALUE_FONT_NAME = "Arial"
RISK_VALUE_FONT_SIZE = 7
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846

# Excel scheme name -> PowerPoint FundDetails name. Durations are written
# as numeric years only, without unit text.
BUILTIN_RISK_MEASURES_FUND_ALIASES: dict[str, str] = {
    "Axis Children’s Fund": "Axis Children's Fund",
    "Axis CRISIL IBX50:50 Gilt Plus SDL June 2028 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL June 2028 Index Fund"
    ),
    "Axis CRISIL IBX50:50 Gilt Plus SDL Sep 2027 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL September 2027 Index Fund"
    ),
    "Axis CRISIL IBX AAA Bond NBFC Jun 2027 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC - Jun 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond Fin Ser. Sep27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond Financial Services - Sep 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond NBFC-HFC-Jun27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC-HFC - JUN 2027 Index Fund"
    ),
    "Axis CRISIL-IBX Fin. Svcs 3-6 Mon Debt Index Fund": (
        "Axis CRISIL-IBX Financial Services 3-6 Months Debt Index Fund"
    ),
}
RISK_MEASURES_FUND_ALIASES = {
    **BUILTIN_RISK_MEASURES_FUND_ALIASES,
    **CONFIG_RISK_ALIASES,
}
NORMALIZED_RISK_MEASURE_ALIASES = {
    normalize(source): normalize(target)
    for source, target in RISK_MEASURES_FUND_ALIASES.items()
}

SCHEME_HEADERS = {"scheme name", "scheme", "fund name", "fund"}
HEADER_ALIASES = {
    "average_maturity": {"avg mat", "avg mat.", "average maturity"},
    "modified_duration": {"mod d", "modified duration", "mod dur"},
    "macaulay_duration": {"mac d", "macaulay duration", "mac duration"},
    "yield_to_maturity": {
        "ann. ytm", "ann ytm", "annualized ytm", "annualised ytm",
        "yield to maturity", "ytm",
    },
}

@dataclass(frozen=True)
class RiskMeasureRecord:
    excel_fund_name: str
    canonical_fund_name: str
    source_files: tuple[str, ...]
    average_maturity: Decimal | None = None
    modified_duration: Decimal | None = None
    macaulay_duration: Decimal | None = None
    yield_to_maturity: Decimal | None = None
    # Backward-compatible optional attributes used by app.py/older callers.
    pto_ratio: Decimal | None = None
    portfolio_yield: Decimal | None = None
    standard_deviation: Decimal | None = None
    beta: Decimal | None = None
    sharpe_ratio: Decimal | None = None


def _clean(value: object) -> str:
    if value is None:
        return ""
    return " ".join(str(value).replace("\xa0", " ").split())


def _header(value: object) -> str:
    return normalize(_clean(value).replace("\n", " ").replace("\r", " "))


def _canonical_name(name: str) -> str:
    direct = RISK_MEASURES_FUND_ALIASES.get(name)
    if direct:
        return direct
    key = normalize(name)
    for source, target in RISK_MEASURES_FUND_ALIASES.items():
        if normalize(source) == key:
            return target
    return name


def _record_key(name: str) -> str:
    return NORMALIZED_RISK_MEASURE_ALIASES.get(
        normalize(name), normalize(_canonical_name(name))
    )


def _parse_duration_years(
    value: object,
    field: str,
    fund: str,
) -> Decimal | None:
    """
    Convert a source duration to years and return only its numeric value.

    Examples:
        66 days    -> 0.18
        400 days   -> 1.10
        2.68 years -> 2.68

    PowerPoint labels already contain ``(years)``, so no unit text is written.
    A 365-day year is used for conversion.
    """
    text = _clean(value)
    if not text or text.casefold() in {"-", "--", "na", "n/a"}:
        return None

    match = re.fullmatch(
        r"([-+]?\d+(?:\.\d+)?)\s*(days?|years?|yrs?)",
        text,
        flags=re.IGNORECASE,
    )
    if not match:
        raise ValueError(f"Invalid {field} value {value!r} for '{fund}'.")

    number = Decimal(match.group(1))
    unit = match.group(2).casefold()
    if unit.startswith("day"):
        return number / Decimal("365")
    return number


def _parse_yield(value: object, fund: str) -> Decimal | None:
    text = _clean(value)
    if not text or text in {"-", "--", "NA", "N/A"}:
        return None
    is_percent_text = text.endswith("%")
    text = text.rstrip("%").strip().replace(",", "")
    try:
        number = Decimal(text)
    except InvalidOperation as error:
        raise ValueError(f"Invalid Ann. YTM value {value!r} for '{fund}'.") from error
    # The supplied workbook stores 6.47% as 0.0647. Values already shown as
    # percent numbers, such as 6.47 or 6.47%, are not multiplied again.
    if not is_percent_text and abs(number) <= 1:
        number *= Decimal("100")
    return number


def format_risk_measure(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP):.2f}"


def format_pto_ratio(value: Decimal) -> str:
    return format_risk_measure(value)


def _format_optional(value: object | None) -> str:
    if value is None:
        return "<not provided>"
    if isinstance(value, Decimal):
        return format_risk_measure(value)
    return str(value)


def _read_xlsx(file_bytes: bytes) -> list[tuple[str, list[list[object]]]]:
    wb = load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=False)
    try:
        return [(ws.title, [list(r) for r in ws.iter_rows(values_only=True)]) for ws in wb.worksheets]
    finally:
        wb.close()


def _read_xls(file_bytes: bytes) -> list[tuple[str, list[list[object]]]]:
    try:
        import xlrd
    except ImportError as error:
        raise ValueError("Reading .xls requires the xlrd package.") from error
    wb = xlrd.open_workbook(file_contents=file_bytes)
    return [(ws.name, [[ws.cell_value(r, c) for c in range(ws.ncols)] for r in range(ws.nrows)]) for ws in wb.sheets()]


def _read_xlsb(file_bytes: bytes) -> list[tuple[str, list[list[object]]]]:
    try:
        from pyxlsb import open_workbook as open_xlsb_workbook
    except ImportError as error:
        raise ValueError("Reading .xlsb requires the pyxlsb package.") from error
    path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".xlsb", delete=False) as f:
            f.write(file_bytes); path = Path(f.name)
        result = []
        with open_xlsb_workbook(str(path)) as wb:
            for name in wb.sheets:
                with wb.get_sheet(name) as ws:
                    result.append((name, [[cell.v for cell in row] for row in ws.rows()]))
        return result
    finally:
        if path and path.exists():
            try: path.unlink()
            except Exception: pass


def _read_sheets(file_bytes: bytes, file_name: str) -> list[tuple[str, list[list[object]]]]:
    lower = file_name.casefold()
    if lower.endswith((".xlsx", ".xlsm")): return _read_xlsx(file_bytes)
    if lower.endswith(".xlsb"): return _read_xlsb(file_bytes)
    if lower.endswith(".xls"): return _read_xls(file_bytes)
    for reader in (_read_xlsx, _read_xls, _read_xlsb):
        try: return reader(file_bytes)
        except Exception: pass
    raise ValueError(f"Unable to read Risk Measures workbook '{file_name}'.")


def _find_layout(rows: list[list[object]]) -> tuple[int, int, dict[str, int]]:
    for row_index, row in enumerate(rows):
        scheme_col = None
        metric_cols: dict[str, int] = {}
        for col, value in enumerate(row):
            text = _header(value)
            if text in SCHEME_HEADERS:
                scheme_col = col
            for attr, aliases in HEADER_ALIASES.items():
                if text in {normalize(a) for a in aliases}:
                    metric_cols[attr] = col
        if scheme_col is not None and set(HEADER_ALIASES).issubset(metric_cols):
            return row_index + 1, scheme_col, metric_cols
    raise ValueError("Scheme Name, Avg Mat, Mod D, Mac D, and Ann. YTM headers were not found.")


def _is_section_or_note(name: str) -> bool:
    key = normalize(name)
    return (
        not key
        or key in {"fixed income funds", "index funds/etfs", "hybrid funds"}
        or key.startswith("the yield to maturity")
        or key.startswith("the calculation is based")
        or key.startswith("for instruments with")
        or key.startswith("for hybrid portfolios")
    )


def _read_sheet(rows: list[list[object]], source: str, sheet: str, logger) -> dict[str, RiskMeasureRecord]:
    start, scheme_col, cols = _find_layout(rows)
    records: dict[str, RiskMeasureRecord] = {}
    for i in range(start, len(rows)):
        row = rows[i]
        if scheme_col >= len(row): continue
        name = _clean(row[scheme_col])
        if _is_section_or_note(name): continue
        def val(attr: str):
            col = cols[attr]
            return row[col] if col < len(row) else None
        avg = _parse_duration_years(
            val("average_maturity"),
            "Avg Mat",
            name,
        )
        mod = _parse_duration_years(
            val("modified_duration"),
            "Mod D",
            name,
        )
        mac = _parse_duration_years(
            val("macaulay_duration"),
            "Mac D",
            name,
        )
        ytm = _parse_yield(val("yield_to_maturity"), name)
        if all(v is None for v in (avg, mod, mac, ytm)): continue
        canonical = _canonical_name(name)
        key = _record_key(name)
        if key in records:
            raise ValueError(f"Duplicate fund '{name}' in '{source}', sheet '{sheet}'.")
        records[key] = RiskMeasureRecord(
            excel_fund_name=name,
            canonical_fund_name=canonical,
            source_files=(source,),
            average_maturity=avg,
            modified_duration=mod,
            macaulay_duration=mac,
            yield_to_maturity=ytm,
        )
        logger.info(
            "RISK_FUND_READ | file=%s | sheet=%s | row=%s | fund=%s | canonical=%s | avg=%s | mod=%s | mac=%s | ytm=%s",
            source, sheet, i + 1, name, canonical, avg, mod, mac, _format_optional(ytm)
        )
    return records


def read_risk_measures_excel(file_bytes: bytes, logger, file_name: str = "") -> dict[str, RiskMeasureRecord]:
    source = file_name or "risk_measures.xlsx"
    combined: dict[str, RiskMeasureRecord] = {}
    for sheet, rows in _read_sheets(file_bytes, source):
        try:
            found = _read_sheet(rows, source, sheet, logger)
        except ValueError as error:
            logger.debug("RISK_SHEET_SKIPPED | file=%s | sheet=%s | reason=%s", source, sheet, error)
            continue
        for key, record in found.items():
            if key in combined: raise ValueError(f"Duplicate fund '{record.canonical_fund_name}' in '{source}'.")
            combined[key] = record
    if not combined: raise ValueError(f"No valid debt quant records found in '{source}'.")
    return combined


def read_multiple_risk_measures_files(excel_files: list[tuple[str, bytes]], logger) -> dict[str, RiskMeasureRecord]:
    if not excel_files: raise ValueError("At least one Risk Measures file is required.")
    combined: dict[str, RiskMeasureRecord] = {}
    for name, data in excel_files:
        for key, record in read_risk_measures_excel(data, logger, name).items():
            if key in combined: raise ValueError(f"Duplicate fund across Risk Measures files: '{record.canonical_fund_name}'.")
            combined[key] = record
    return combined


def _match_fund(shape, records):
    for text in shape_texts(shape):
        record = records.get(normalize(text))
        if record: return record
    return None


def _get_cell(table, row, col):
    try: return table.Cell(row, col)
    except Exception: return None


def _cell_text(table, row, col) -> str:
    cell = _get_cell(table, row, col)
    if cell is None or not cell.Shape.HasTextFrame: return ""
    return _clean(cell.Shape.TextFrame.TextRange.Text)


def _label_key(value: object) -> str:
    text = normalize(value)
    text = re.sub(r"^\d+\s*[\)\.\-:]?\s*", "", text)
    return text.rstrip(":").strip()


PPT_LABELS = {
    "average_maturity": (
        r"^average\s+maturity(?:\s*\(years?\))?$",
        r"^avg\.?\s+maturity(?:\s*\(years?\))?$",
    ),
    "macaulay_duration": (r"^macaulay\s+duration(?:\s*\(years?\))?$",),
    "modified_duration": (
        r"^modified\s+duration(?:\s*\(%\)|\s*\(years?\))?$",
        r"^mod\.?\s+dur(?:ation)?(?:\s*\(years?\))?$",
    ),
    "yield_to_maturity": (
        r"^yield\s+to\s+maturity(?:\s*\(%\))?$",
        r"^ytm(?:\s*\(%\))?$",
    ),
}


def _find_metric(table, patterns):
    found=[]
    for row in range(1, table.Rows.Count+1):
        for col in range(1, table.Columns.Count+1):
            text=_cell_text(table,row,col)
            key=_label_key(text)
            if any(re.fullmatch(p,key,re.I) for p in patterns):
                found.append((row,col,text)); break
    return found


def _value_shape(table,row,label_col):
    for col in range(table.Columns.Count,label_col,-1):
        cell=_get_cell(table,row,col)
        if cell is not None and cell.Shape.HasTextFrame:
            return cell.Shape,col
    raise ValueError(f"No value cell found on row {row}.")


def _replace_preserve_format(
    shape,
    new_text: str,
) -> tuple[str, str]:
    """
    Replace only the value text and enforce Arial 7 pt for the written value.

    All other formatting remains inherited from the PowerPoint template,
    including font color, bold, italic, underline, alignment, margins, fills,
    borders, row height, column width, and table/shape geometry.
    """
    text_range = shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")

    if old_text:
        text_range.Characters(1, len(old_text)).Text = new_text
    else:
        text_range.Text = new_text

    written_range = text_range.Characters(1, max(len(new_text), 1))
    written_range.Font.Name = RISK_VALUE_FONT_NAME
    written_range.Font.Size = RISK_VALUE_FONT_SIZE

    return old_text, str(text_range.Text or "")


def _retry_com(name, operation, logger, attempts=8):
    delay=.75
    for attempt in range(1,attempts+1):
        try:
            pythoncom.PumpWaitingMessages(); return operation()
        except pywintypes.com_error as error:
            code=getattr(error,"hresult",error.args[0] if error.args and isinstance(error.args[0],int) else None)
            if code not in {RPC_E_CALL_REJECTED,RPC_E_SERVERCALL_RETRYLATER} or attempt==attempts: raise
            logger.warning("RISK_COM_RETRY | operation=%s | attempt=%s/%s",name,attempt,attempts)
            time.sleep(delay); delay=min(4,delay*1.7)


def apply_risk_measures(
    current_ppt_bytes: bytes,
    risk_excel_files: list[tuple[str, bytes]],
    fund_object: str,
    measures_table_object: str,
    scheme_details_object: str,
    logger,
    strict: bool = False,
) -> bytes:
    records=read_multiple_risk_measures_files(risk_excel_files,logger)
    logger.info(
        "RISK_MEASURES_START | ppt_bytes=%s | funds=%s | "
        "value_font=%s | value_font_size=%s",
        len(current_ppt_bytes),
        len(records),
        RISK_VALUE_FONT_NAME,
        RISK_VALUE_FONT_SIZE,
    )
    pythoncom.CoInitialize(); powerpoint=presentation=None
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path=Path(temp_dir)/"working.pptx"; output_path=Path(temp_dir)/"risk_measures_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)
            powerpoint=_retry_com("start PowerPoint",lambda:win32com.client.DispatchEx("PowerPoint.Application"),logger)
            _retry_com("set alerts",lambda:setattr(powerpoint,"DisplayAlerts",False),logger)
            presentation=_retry_com("open",lambda:powerpoint.Presentations.Open(str(input_path.resolve()),False,False,False),logger)
            matched=unmatched=changed=skipped=0
            for slide_number in range(1,presentation.Slides.Count+1):
                slide=presentation.Slides.Item(slide_number)
                measures=find_shape_recursive(slide.Shapes,measures_table_object)
                if measures is None: continue
                fund=find_shape_recursive(slide.Shapes,fund_object)
                if fund is None:
                    if strict: raise ValueError(f"'{fund_object}' missing on slide {slide_number}.")
                    skipped+=1; continue
                record=_match_fund(fund,records)
                if record is None:
                    unmatched+=1
                    if strict: raise ValueError(f"Risk record not found for {' | '.join(shape_texts(fund))!r}.")
                    continue
                if not measures.HasTable: raise ValueError(f"'{measures_table_object}' on slide {slide_number} is not a table.")
                table=measures.Table; slide_changes=0
                for attr in ("average_maturity","macaulay_duration","modified_duration","yield_to_maturity"):
                    value=getattr(record,attr)
                    if value is None: continue
                    matches=_find_metric(table,PPT_LABELS[attr])
                    if len(matches)!=1:
                        message=f"Expected one {attr} row on slide {slide_number}; found {matches!r}."
                        if strict: raise ValueError(message)
                        logger.warning("RISK_ROW_SKIPPED | %s",message); skipped+=1; continue
                    row,col,label=matches[0]; shape,value_col=_value_shape(table,row,col)
                    output=format_risk_measure(value) if isinstance(value,Decimal) else value
                    old,new=_replace_preserve_format(shape,output)
                    slide_changes+=1; changed+=1
                    logger.info("RISK_VALUE_CHANGED | slide=%s | fund=%s | metric=%s | label=%r | cell=%s,%s | %s -> %s",slide_number,record.canonical_fund_name,attr,label,row,value_col,old,new)
                if slide_changes: matched+=1
            _retry_com("save",lambda:presentation.SaveAs(str(output_path.resolve()),PP_SAVE_AS_OPEN_XML_PRESENTATION),logger)
            _retry_com("close",presentation.Close,logger,4); presentation=None
            output=output_path.read_bytes()
            logger.info("RISK_COMPLETE | matched=%s | unmatched=%s | changed=%s | skipped=%s | bytes=%s",matched,unmatched,changed,skipped,len(output))
            return output
    except Exception:
        logger.exception("RISK_MEASURES_FAILED"); raise
    finally:
        if presentation is not None:
            try:_retry_com("cleanup close",presentation.Close,logger,3)
            except Exception:pass
        if powerpoint is not None:
            try:_retry_com("quit",powerpoint.Quit,logger,3)
            except Exception:pass
        pythoncom.CoUninitialize()
