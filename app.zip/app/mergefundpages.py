from pathlib import Path
import os
import re
import shutil
import time

import pythoncom
import pywintypes
import win32com.client


# ============================================================
# CONFIGURATION
# ============================================================

SCRIPT_FOLDER = Path(__file__).resolve().parent

# The presentations are assumed to be in the same folder
# as this Python script.
INPUT_FOLDER = SCRIPT_FOLDER

OUTPUT_FILE = (
    INPUT_FOLDER / "Axis_Debt_Funds_Merged.pptx"
).resolve()


FUND_ORDER = [
    "Axis Large Cap Fund",
    "Axis Focused Fund",
    "Axis ELSS Tax Saver Fund",
    "Axis Large & Mid Cap Fund",
    "Axis Flexi Cap Fund",
    "Axis Multicap Fund",
    "Axis Midcap Fund",
    "Axis Innovation Fund",
    "Axis Small Cap Fund",
    "Axis ESG Integration Strategy Fund",
    "Axis Quant Fund",
    "Axis Value Fund",
    "Axis Business Cycles Fund",
    "Axis India Manufacturing Fund",
    "Axis Consumption Fund",
    "Axis Momentum Fund",
    "Axis Services Opportunities Fund",
    "Axis NIFTY 50 ETF",
    "Axis NIFTY Bank ETF",
    "Axis NIFTY IT ETF",
    "Axis NIFTY Healthcare ETF",
    "Axis NIFTY India Consumption ETF",
    "Axis BSE Sensex ETF",
    "Axis Nifty500 Value 50 ETF",
    "Axis Nifty 100 Index Fund",
    "Axis Nifty 50 Index Fund",
    "Axis BSE Sensex Index Fund",
    "Axis Nifty Next 50 Index Fund",
    "Axis Nifty Smallcap 50 Index Fund",
    "Axis Nifty Midcap 50 Index Fund",
    "Axis Nifty IT Index Fund",
    "Axis Nifty Bank Index Fund",
    "Axis Nifty 500 Index Fund",
    "Axis Nifty500 Value 50 Index Fund",
    "Axis Nifty500 Momentum 50 Index Fund",
    "Axis Nifty500 Quality 50 Index Fund",
    "Axis Nifty50 Equal Weight Index Fund",
    "Axis BSE India Sector Leaders Index Fund",
    "Axis Nifty India Defence Index Fund",
    "Axis Multi Factor Passive FoF",
    "Axis Global Equity Alpha Fund of Fund",
    "Axis Greater China Equity Fund of Fund",
    "Axis Global Innovation Fund of Fund",
    "Axis NASDAQ 100 US Specific Equity Passive FOF",
]


# PowerPoint constants
MSO_TRUE = -1
MSO_FALSE = 0


# ============================================================
# FILE FUNCTIONS
# ============================================================

def normalize_name(name):
    """
    Normalize a presentation filename for matching.
    """

    name = Path(name).stem
    name = name.replace("&", "and")

    # Normalize hyphens, long dashes and underscores
    name = re.sub(r"[_\-–—]+", " ", name)

    # Remove unsupported characters
    name = re.sub(r"[^a-zA-Z0-9' ]+", " ", name)

    # Remove duplicate spaces
    name = re.sub(r"\s+", " ", name)

    return name.strip().lower()


def same_path(path1, path2):
    """
    Safely determine whether two paths refer to the same file.
    This also handles Windows path capitalization.
    """

    normalized_path1 = os.path.normcase(
        os.path.abspath(str(path1))
    )

    normalized_path2 = os.path.normcase(
        os.path.abspath(str(path2))
    )

    return normalized_path1 == normalized_path2


def get_presentation_files(folder):
    """
    Return valid PowerPoint files from the input folder.

    Excludes:
    - The merged output file
    - PowerPoint temporary files beginning with ~$
    - Directories
    """

    files = []

    for file_path in folder.iterdir():
        if not file_path.is_file():
            continue

        if file_path.name.startswith("~$"):
            continue

        if file_path.suffix.lower() not in {".ppt", ".pptx"}:
            continue

        resolved_file = file_path.resolve()

        if same_path(resolved_file, OUTPUT_FILE):
            continue

        files.append(resolved_file)

    return files


def find_presentation(available_files, fund_name):
    """
    Find the presentation corresponding to the fund name.
    """

    target_name = normalize_name(fund_name)

    # First try exact matching
    exact_matches = [
        file_path
        for file_path in available_files
        if normalize_name(file_path.name) == target_name
    ]

    if len(exact_matches) == 1:
        return exact_matches[0]

    if len(exact_matches) > 1:
        raise RuntimeError(
            f"Multiple exact matches found for '{fund_name}':\n"
            + "\n".join(
                f"  - {file_path}"
                for file_path in exact_matches
            )
        )

    # Then try partial matching
    partial_matches = []

    for file_path in available_files:
        normalized_file_name = normalize_name(file_path.name)

        if (
            target_name in normalized_file_name
            or normalized_file_name in target_name
        ):
            partial_matches.append(file_path)

    if len(partial_matches) == 1:
        return partial_matches[0]

    if len(partial_matches) > 1:
        raise RuntimeError(
            f"Multiple partial matches found for '{fund_name}':\n"
            + "\n".join(
                f"  - {file_path}"
                for file_path in partial_matches
            )
        )

    return None


def validate_source_file(file_path, fund_name):
    """
    Validate a source presentation immediately before using it.
    """

    file_path = Path(file_path).resolve()

    if same_path(file_path, OUTPUT_FILE):
        raise RuntimeError(
            f"The source file for '{fund_name}' is the same as "
            f"the output file:\n{file_path}"
        )

    if not file_path.exists():
        raise FileNotFoundError(
            f"The source presentation does not exist:\n"
            f"{file_path}\n\n"
            f"Fund: {fund_name}"
        )

    if not file_path.is_file():
        raise FileNotFoundError(
            f"The source path is not a file:\n"
            f"{file_path}\n\n"
            f"Fund: {fund_name}"
        )

    if file_path.stat().st_size == 0:
        raise RuntimeError(
            f"The source presentation is empty:\n"
            f"{file_path}"
        )

    return file_path


# ============================================================
# POWERPOINT FUNCTIONS
# ============================================================

def open_presentation(
    powerpoint,
    file_path,
    read_only,
    with_window=False,
    attempts=3
):
    """
    Open a presentation with retry handling.
    """

    file_path = Path(file_path).resolve()
    last_error = None

    for attempt in range(1, attempts + 1):
        try:
            presentation = powerpoint.Presentations.Open(
                FileName=str(file_path),
                ReadOnly=MSO_TRUE if read_only else MSO_FALSE,
                Untitled=MSO_FALSE,
                WithWindow=MSO_TRUE if with_window else MSO_FALSE
            )

            time.sleep(0.5)
            return presentation

        except pywintypes.com_error as error:
            last_error = error

            print(
                f"    Open attempt {attempt}/{attempts} failed."
            )

            time.sleep(2)

    raise RuntimeError(
        f"PowerPoint could not open:\n{file_path}\n\n"
        f"PowerPoint error:\n{last_error}"
    )


def get_slide_size(presentation):
    """
    Return slide width and height in PowerPoint points.
    """

    return (
        round(float(presentation.PageSetup.SlideWidth), 2),
        round(float(presentation.PageSetup.SlideHeight), 2)
    )


def validate_slide_size(source, destination, fund_name):
    """
    Ensure both presentations have the same physical slide size.
    """

    source_size = get_slide_size(source)
    destination_size = get_slide_size(destination)

    if source_size != destination_size:
        raise RuntimeError(
            f"Slide size mismatch for '{fund_name}'.\n\n"
            f"Source size: "
            f"{source_size[0]} x {source_size[1]} points\n"
            f"Destination size: "
            f"{destination_size[0]} x "
            f"{destination_size[1]} points\n\n"
            f"PowerPoint cannot preserve different physical slide "
            f"sizes in one presentation."
        )


def copy_one_slide(
    source_slide,
    destination,
    source_file,
    slide_number,
    attempts=3
):
    """
    Copy an entire slide with PowerPoint's native slide-copy method.

    The complete slide is copied, not the individual shapes.
    """

    last_error = None

    for attempt in range(1, attempts + 1):
        try:
            count_before = destination.Slides.Count

            source_slide.Copy()
            time.sleep(1)

            # Paste at the end of the merged presentation
            destination.Slides.Paste(count_before + 1)
            time.sleep(0.5)

            count_after = destination.Slides.Count

            if count_after != count_before + 1:
                raise RuntimeError(
                    "PowerPoint did not paste exactly one slide."
                )

            return

        except Exception as error:
            last_error = error

            print(
                f"      Slide {slide_number}: "
                f"attempt {attempt}/{attempts} failed."
            )

            time.sleep(2)

    raise RuntimeError(
        f"Failed to copy slide {slide_number} from:\n"
        f"{source_file}\n\n"
        f"Error:\n{last_error}"
    )


def append_presentation(
    source,
    destination,
    fund_name,
    source_file
):
    """
    Append all complete slides from the source presentation.
    """

    validate_slide_size(
        source,
        destination,
        fund_name
    )

    slide_count = source.Slides.Count

    if slide_count == 0:
        print("    No slides found. Skipped.")
        return 0

    for slide_number in range(1, slide_count + 1):
        source_slide = source.Slides(slide_number)

        copy_one_slide(
            source_slide=source_slide,
            destination=destination,
            source_file=source_file,
            slide_number=slide_number
        )

        print(
            f"      Copied slide "
            f"{slide_number}/{slide_count}"
        )

    return slide_count


# ============================================================
# MAIN MERGE
# ============================================================

def merge_presentations():
    pythoncom.CoInitialize()

    powerpoint = None
    destination = None
    source = None

    try:
        print("=" * 72)
        print("PowerPoint merge configuration")
        print("=" * 72)

        print(f"Script folder : {SCRIPT_FOLDER}")
        print(f"Input folder  : {INPUT_FOLDER}")
        print(f"Output file   : {OUTPUT_FILE}")

        if not INPUT_FOLDER.exists():
            raise FileNotFoundError(
                f"Input folder does not exist:\n{INPUT_FOLDER}"
            )

        if not INPUT_FOLDER.is_dir():
            raise NotADirectoryError(
                f"Input path is not a folder:\n{INPUT_FOLDER}"
            )

        # Take one fixed snapshot of available files.
        available_files = get_presentation_files(INPUT_FOLDER)

        print(f"\nPowerPoint files available: {len(available_files)}")

        if not available_files:
            raise FileNotFoundError(
                f"No PPT or PPTX files were found in:\n"
                f"{INPUT_FOLDER}"
            )

        matched_files = []
        missing_funds = []

        print("\n" + "=" * 72)
        print("Checking fund presentations")
        print("=" * 72)

        for fund_name in FUND_ORDER:
            file_path = find_presentation(
                available_files,
                fund_name
            )

            if file_path is None:
                missing_funds.append(fund_name)
                print(f"\nMissing: {fund_name}")
                continue

            file_path = validate_source_file(
                file_path,
                fund_name
            )

            matched_files.append(
                (fund_name, file_path)
            )

            print(f"\nFound: {fund_name}")
            print(f"       {file_path}")

        if missing_funds:
            raise FileNotFoundError(
                "\nThe following presentations are missing:\n"
                + "\n".join(
                    f"  - {fund_name}"
                    for fund_name in missing_funds
                )
            )

        if not matched_files:
            raise RuntimeError(
                "No presentations were matched."
            )

        # The first fund presentation will become the base file.
        first_fund_name, first_file = matched_files[0]

        first_file = validate_source_file(
            first_file,
            first_fund_name
        )

        print("\n" + "=" * 72)
        print("Creating output from first presentation")
        print("=" * 72)

        print(f"Source: {first_file}")
        print(f"Exists: {first_file.exists()}")
        print(f"Output: {OUTPUT_FILE}")
        print(f"Output parent exists: {OUTPUT_FILE.parent.exists()}")

        if same_path(first_file, OUTPUT_FILE):
            raise RuntimeError(
                "The first source and output paths are identical."
            )

        # Remove an old output file only after confirming it is not
        # one of the source files.
        if OUTPUT_FILE.exists():
            try:
                OUTPUT_FILE.unlink()
                print("Removed previous merged output.")

            except PermissionError as error:
                raise PermissionError(
                    f"Cannot remove the previous output:\n"
                    f"{OUTPUT_FILE}\n\n"
                    f"Close it in PowerPoint and run the script again."
                ) from error

        # Revalidate the source after deleting the old output.
        first_file = validate_source_file(
            first_file,
            first_fund_name
        )

        # Copy only the file contents. Metadata copying is unnecessary
        # and copyfile is simpler than copy2 on Windows.
        try:
            shutil.copyfile(
                str(first_file),
                str(OUTPUT_FILE)
            )

        except FileNotFoundError as error:
            raise FileNotFoundError(
                f"Windows could not copy the base presentation.\n\n"
                f"Source:\n{first_file}\n"
                f"Source exists: {first_file.exists()}\n\n"
                f"Destination:\n{OUTPUT_FILE}\n"
                f"Destination folder exists: "
                f"{OUTPUT_FILE.parent.exists()}\n\n"
                f"Original error:\n{error}"
            ) from error

        if not OUTPUT_FILE.exists():
            raise RuntimeError(
                f"The output file was not created:\n"
                f"{OUTPUT_FILE}"
            )

        if OUTPUT_FILE.stat().st_size != first_file.stat().st_size:
            raise RuntimeError(
                f"The initial output copy has a different file size.\n\n"
                f"Source size: {first_file.stat().st_size} bytes\n"
                f"Output size: {OUTPUT_FILE.stat().st_size} bytes"
            )

        print(
            f"Base file copied successfully: "
            f"{OUTPUT_FILE.stat().st_size:,} bytes"
        )

        # Start a separate PowerPoint instance.
        powerpoint = win32com.client.DispatchEx(
            "PowerPoint.Application"
        )

        powerpoint.Visible = True

        try:
            powerpoint.DisplayAlerts = False
        except Exception:
            pass

        # Open the copied first presentation as the editable output.
        destination = open_presentation(
            powerpoint=powerpoint,
            file_path=OUTPUT_FILE,
            read_only=False,
            with_window=False
        )

        expected_slide_count = destination.Slides.Count

        print(
            f"Initial slides retained: {expected_slide_count}"
        )

        print("\n" + "=" * 72)
        print("Appending remaining presentations")
        print("=" * 72)

        for position, (fund_name, source_file) in enumerate(
            matched_files[1:],
            start=2
        ):
            source = None

            source_file = validate_source_file(
                source_file,
                fund_name
            )

            print(
                f"\n[{position:02d}/{len(matched_files):02d}] "
                f"{fund_name}"
            )

            print(f"    File: {source_file.name}")

            try:
                source = open_presentation(
                    powerpoint=powerpoint,
                    file_path=source_file,
                    read_only=True,
                    with_window=False
                )

                copied_count = append_presentation(
                    source=source,
                    destination=destination,
                    fund_name=fund_name,
                    source_file=source_file
                )

                expected_slide_count += copied_count

                print(
                    f"    Added {copied_count} slide(s)."
                )

            finally:
                if source is not None:
                    try:
                        source.Close()
                    except Exception:
                        pass

                    source = None

                time.sleep(0.5)

        actual_slide_count = destination.Slides.Count

        if actual_slide_count != expected_slide_count:
            raise RuntimeError(
                f"Final slide count validation failed.\n\n"
                f"Expected: {expected_slide_count}\n"
                f"Actual: {actual_slide_count}"
            )

        print("\nSaving merged presentation...")

        destination.Save()
        time.sleep(1)

        if not OUTPUT_FILE.exists():
            raise RuntimeError(
                "The merged presentation was not found after saving."
            )

        output_size = OUTPUT_FILE.stat().st_size

        if output_size == 0:
            raise RuntimeError(
                "The merged presentation is empty."
            )

        print("\n" + "=" * 72)
        print("MERGE COMPLETED SUCCESSFULLY")
        print("=" * 72)

        print(f"Presentations: {len(matched_files)}")
        print(f"Slides: {actual_slide_count}")
        print(f"Output: {OUTPUT_FILE}")
        print(f"Size: {output_size / 1024 / 1024:.2f} MB")

    except Exception:
        print("\n" + "=" * 72)
        print("MERGE FAILED")
        print("=" * 72)

        raise

    finally:
        if source is not None:
            try:
                source.Close()
            except Exception:
                pass

        if destination is not None:
            try:
                destination.Close()
            except Exception:
                pass

        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass

        pythoncom.CoUninitialize()


if __name__ == "__main__":
    merge_presentations()