"""Central application constants.

Scheme-creation AMC and Axis-category formatting is intentionally owned by
scheme_creation.logic. This module contains only shared object names, workbook
headers, output naming, and aliases used by the data-update modules.
"""

FUND_NAME_SHEET = "Sheet1"
FUND_NAME_COLUMN = "scheme details"

FUND_DETAILS_OBJECT = "FundDetails"
SCHEME_DETAILS_OBJECT = "scheme_details"
MEASURES_TABLE_OBJECT = "RiskMeasures"
MARKET_CAP_TABLE_OBJECT = "MarketCapTable"
SIP_TABLE_OBJECT = "SIP Table"
SIP_FUND_NAME_OBJECT = "SIPFundName"
SIP_PERFORMANCE_DATE_OBJECT = "SIPPerformanceDate"
DETAILS_OF_EXPOSURE_TABLE_OBJECT = "DetailsofExposureTable"
DETAILS_OF_EXPOSURE_BOX_OBJECT = "DetailsofExposureBox"
DETAILS_EXPOSURE_TEXT_BG_OBJECT = "DetailsExposureTextandBG"
DETAILS_EXPOSURE_ICON_OBJECT = "DetailsExposureIcon"
PTC_TABLE_OBJECT = "PTCTable"
PTC_TEXT_BG_OBJECT = "PTCTextandBG"
PTC_ICON_OBJECT = "PTCIcon"
PTC_TABLE_BOX_OBJECT = "PTCTableBox"
PORTFOLIO_TABLE_OBJECT = "PortfolioTable"
RISKOMETER_TABLE_OBJECT = "RiskoMeterTable"
RISKOMETER_CHANGE_TABLE_OBJECT = "RiskoMeterTable2"
IDCW_TABLE_OBJECT = "IDCWTable"
IDCW_BOX_OBJECT = "IDCWBox"
IDCW_NOTE_OBJECT = "IDCWNote"
IDCW_ICON_TEXT_BG_OBJECT = "IDCWIconTextBG"
PERFORMANCE_TABLE_OBJECT = "PerformanceTable"
PERFORMANCE_TABLE_BOX_OBJECT = "PerformanceTableBox"
PERFORMANCE_NOTE_OBJECT = "PerformanceTableNote"
PERFORMANCE_AS_ON_DATE_OBJECT = "AsonDate"
PERFORMANCE_ICON_TEXT_OBJECT = "PerformaceIconText"
MATURITY_BUCKET_GRAPH_OBJECT = "MaturityBucketGraph"
MATURITY_BUCKET_GRAPH_BOX_OBJECT = "MaturityBucketGraphBox"
MATURITY_TEXT_BG_OBJECT = "MaturityTextBG"
MATURITY_ICON_OBJECT = "MaturityIcon"
MATURITY_TEXT_OBJECT = "MaturityText"

FINAL_OUTPUT_NAME = "AMC_Final_Fund_Presentation.pptx"

NAV_FUND_NAME_ALIASES = {
    "Navi Ttl Stk Mkt US Specific Eq Pass FoF":
        "Navi US Total Stock Market Fund of Fund",
}

EXPENSE_RATIO_SCHEME_HEADER = "Scheme Name"
EXPENSE_RATIO_REGULAR_PLAN_HEADER = "Regular Plan"
EXPENSE_RATIO_DIRECT_PLAN_HEADER = "Direct Plan"
EXPENSE_RATIO_BER_HEADER = "Base Expense Ratio (BER) (%)"
EXPENSE_RATIO_SECTION_PATTERN = r"expense\s+ratio\s*:?\s*$"
EXPENSE_RATIO_REGULAR_PATTERN = r"^regular(?:\b|\s|/|-).*"
EXPENSE_RATIO_DIRECT_PATTERN = r"^direct(?:\b|\s|/|-).*"
EXPENSE_RATIO_FUND_ALIASES = {
    "Navi Nifty 500 Multicap 50:25:25 Index Fund":
        "Navi Nifty 500 Multicap 50:25:25 Index",
}

RISK_MEASURES_FUND_ALIASES = {
    "Navi Nifty India Manufacturing Indx Fund":
        "Navi Nifty India Manufacturing Index Fund",
}
