"""Configuration settings for Axis Factsheet Automation."""

# -----------------------------------------------------------------------------
# Fund-list Excel settings
# -----------------------------------------------------------------------------

FUND_NAME_SHEET = "Sheet1"
FUND_NAME_COLUMN = "scheme details"


# -----------------------------------------------------------------------------
# PowerPoint object names
# -----------------------------------------------------------------------------

FUND_DETAILS_OBJECT = "FundDetails"
SCHEME_DETAILS_OBJECT = "scheme_details"
MEASURES_TABLE_OBJECT = "MeasuresTable"
MARKET_CAP_TABLE_OBJECT = "MarketCapTable"
SIP_TABLE_OBJECT = "SIP Table"
SIP_FUND_NAME_OBJECT = "SIPFundName"
SIP_PERFORMANCE_DATE_OBJECT = "SIPPerformanceDate"
DETAILS_OF_EXPOSURE_TABLE_OBJECT = "DetailsofExposureTable"
DETAILS_OF_EXPOSURE_BOX_OBJECT = "DetailsofExposureBox"
DETAILS_EXPOSURE_TEXT_BG_OBJECT = "DetailsExposureTextandBG"
DETAILS_EXPOSURE_ICON_OBJECT = "DetailsExposureIcon"

# -----------------------------------------------------------------------------
# Template settings
# -----------------------------------------------------------------------------

# Representative fund contained in each category template.
TEMPLATE_FUND_NAME = {
    "Equity": "Axis Large Cap Fund",
    "Debt": "Axis Liquid Fund",
    "Hybrid": "Axis Multi Asset Allocation Fund",
}

# Number of slides to generate for each fund in the selected category.
SLIDES_PER_FUND = {
    "Equity": 3,
    "Debt": 4,
    "Hybrid": 4,
}

FINAL_OUTPUT_NAME = "Axis_Final_Fund_Presentation.pptx"

# Case-insensitive lookup dictionaries.
TEMPLATE_FUND_NAME_BY_CATEGORY = {
    category.casefold(): fund_name
    for category, fund_name in TEMPLATE_FUND_NAME.items()
}

SLIDES_PER_FUND_BY_CATEGORY = {
    category.casefold(): slide_count
    for category, slide_count in SLIDES_PER_FUND.items()
}


def normalize_fund_category(fund_category: str) -> str:
    """Normalize and validate Equity, Debt, or Hybrid category input."""
    normalized_category = str(fund_category).strip().casefold()

    if normalized_category not in TEMPLATE_FUND_NAME_BY_CATEGORY:
        supported_categories = ", ".join(TEMPLATE_FUND_NAME)
        raise ValueError(
            f"Unsupported fund category: {fund_category!r}. "
            f"Expected one of: {supported_categories}."
        )

    return normalized_category


def get_template_fund_name(fund_category: str) -> str:
    """Return the representative template fund name for a category."""
    normalized_category = normalize_fund_category(fund_category)
    return TEMPLATE_FUND_NAME_BY_CATEGORY[normalized_category]


def get_slides_per_fund(fund_category: str) -> int:
    """Return the number of slides required per fund for a category."""
    normalized_category = normalize_fund_category(fund_category)
    return SLIDES_PER_FUND_BY_CATEGORY[normalized_category]


# -----------------------------------------------------------------------------
# NAV aliases
# -----------------------------------------------------------------------------

NAV_FUND_NAME_ALIASES = {
    "Navi Ttl Stk Mkt US Specific Eq Pass FoF":
        "Navi US Total Stock Market Fund of Fund",

    "Navi Nasdaq100 US Specific Eq Pass FOF":
        "Navi NASDAQ 100 Fund of Fund",

    "Navi Nifty India Manufacturing Indx Fund":
        "Navi Nifty India Manufacturing Index Fund",
}


# -----------------------------------------------------------------------------
# Expense-ratio settings
# -----------------------------------------------------------------------------

# Excel heading names.
EXPENSE_RATIO_SCHEME_HEADER = "Scheme Name"
EXPENSE_RATIO_REGULAR_PLAN_HEADER = "Regular Plan"
EXPENSE_RATIO_DIRECT_PLAN_HEADER = "Direct Plan"
EXPENSE_RATIO_BER_HEADER = "Base Expense Ratio (BER) (%)"

# PowerPoint section and row patterns.
EXPENSE_RATIO_SECTION_PATTERN = r"expense\s+ratio\s*:?\s*$"
EXPENSE_RATIO_REGULAR_PATTERN = r"^regular(?:\b|/|\s|-).*"
EXPENSE_RATIO_DIRECT_PATTERN = r"^direct(?:\b|/|\s|-).*"

# Left side  = Excel Scheme Name
# Right side = PowerPoint FundDetails name
EXPENSE_RATIO_FUND_ALIASES = {
    "Navi Nifty 500 Multicap 50:25:25 Index Fund":
        "Navi Nifty 500 Multicap 50:25:25 Index",

    "Navi Nifty Smallcap250 Momentum Quality 100 Index Fund":
        "Navi Nifty SmallCap250 Momentum Qlty 100",

    "Navi Nifty Midsmallcap 400 Index Fund":
        "Navi Nifty MidSmallcap 400 Index Fund",
}


# -----------------------------------------------------------------------------
# Risk-measures settings
# -----------------------------------------------------------------------------

# Left side  = Excel Scheme Name
# Right side = PowerPoint FundDetails name
RISK_MEASURES_FUND_ALIASES = {
    "Navi Nifty India Manufacturing Indx Fund":
        "Navi Nifty India Manufacturing Index Fund",

    "Navi S&P BSE Sensex Index Fund":
        "Navi BSE Sensex Index Fund",

    "NAVI NIFTY 500 MULTICAP 50:25:25 INDEX FUND":
        "Navi Nifty 500 Multicap 50:25:25 Index",

    "Nifty MidSmallcap 400 Index Fund":
        "Navi Nifty MidSmallcap 400 Index Fund",
}
