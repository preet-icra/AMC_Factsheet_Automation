from __future__ import annotations

import io
import re
import tempfile
import time
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize, shape_texts

try:
    from config import EXPENSE_RATIO_FUND_NAME_ALIASES as CONFIG_EXPENSE_ALIASES
except ImportError:
    CONFIG_EXPENSE_ALIASES: dict[str, str] = {}


# Built-in aliases use this direction:
# TER Excel "Name of Scheme" -> PowerPoint FundDetails name.
#
# Most names match after normalization, but the explicit catalog below also
# documents the approved Equity, Debt, and Hybrid PowerPoint names and handles
# abbreviations, punctuation, apostrophes, month abbreviations, and spacing.
BUILTIN_EXPENSE_RATIO_FUND_NAME_ALIASES: dict[str, str] = {
    # Equity funds
    "Axis Large Cap Fund": "Axis Large Cap Fund",
    "Axis Focused Fund": "Axis Focused Fund",
    "Axis ELSS Tax Saver Fund": "Axis ELSS Tax Saver Fund",
    "Axis Large & Mid Cap Fund": "Axis Large & Mid Cap Fund",
    "Axis Flexi Cap Fund": "Axis Flexi Cap Fund",
    "Axis Multicap Fund": "Axis Multicap Fund",
    "Axis Midcap Fund": "Axis Midcap Fund",
    "Axis Innovation Fund": "Axis Innovation Fund",
    "Axis Small Cap Fund": "Axis Small Cap Fund",
    "Axis ESG Integration Strategy Fund": "Axis ESG Integration Strategy Fund",
    "Axis Quant Fund": "Axis Quant Fund",
    "Axis Value Fund": "Axis Value Fund",
    "Axis Business Cycles Fund": "Axis Business Cycles Fund",
    "Axis India Manufacturing Fund": "Axis India Manufacturing Fund",
    "Axis Consumption Fund": "Axis Consumption Fund",
    "Axis Momentum Fund": "Axis Momentum Fund",
    "Axis Services Opportunities Fund": "Axis Services Opportunities Fund",
    "Axis NIFTY 50 ETF": "Axis NIFTY 50 ETF",
    "Axis NIFTY Bank ETF": "Axis NIFTY Bank ETF",
    "Axis NIFTY IT ETF": "Axis NIFTY IT ETF",
    "Axis NIFTY Healthcare ETF": "Axis NIFTY Healthcare ETF",
    "Axis NIFTY India Consumption ETF": "Axis NIFTY India Consumption ETF",
    "Axis BSE Sensex ETF": "Axis BSE Sensex ETF",
    "Axis Nifty500 Value 50 ETF": "Axis Nifty500 Value 50 ETF",
    "Axis Nifty 100 Index Fund": "Axis Nifty 100 Index Fund",
    "Axis Nifty 50 Index Fund": "Axis Nifty 50 Index Fund",
    "Axis BSE Sensex Index Fund": "Axis BSE Sensex Index Fund",
    "Axis Nifty Next 50 Index Fund": "Axis Nifty Next 50 Index Fund",
    "Axis Nifty Smallcap 50 Index Fund": "Axis Nifty Smallcap 50 Index Fund",
    "AXIS NIFTY SMALLCAP 50 INDEX FUND": "Axis Nifty Smallcap 50 Index Fund",
    "Axis Nifty Midcap 50 Index Fund": "Axis Nifty Midcap 50 Index Fund",
    "AXIS NIFTY MIDCAP 50 INDEX FUND": "Axis Nifty Midcap 50 Index Fund",
    "Axis Nifty IT Index Fund": "Axis Nifty IT Index Fund",
    "Axis Nifty Bank Index Fund": "Axis Nifty Bank Index Fund",
    "Axis Nifty 500 Index Fund": "Axis Nifty 500 Index Fund",
    "Axis Nifty500 Value 50 Index Fund": "Axis Nifty500 Value 50 Index Fund",
    "Axis Nifty500 Momentum 50 Index Fund": "Axis Nifty500 Momentum 50 Index Fund",
    "Axis Nifty500 Quality 50 Index Fund": "Axis Nifty500 Quality 50 Index Fund",
    "Axis BSE India Sector Leaders Index Fund": "Axis BSE India Sector Leaders Index Fund",
    "Axis Nifty India Defence Index Fund": "Axis Nifty India Defence Index Fund",
    "Axis Multi Factor Passive FoF": "Axis Multi Factor Passive FoF",
    "Axis Global Equity Alpha Fund of Fund": "Axis Global Equity Alpha Fund of Fund",
    "Axis Greater China Equity Fund of Fund": "Axis Greater China Equity Fund of Fund",
    "Axis Global Innovation Fund of Fund": "Axis Global Innovation Fund of Fund",
    "Axis NASDAQ 100 US Specific Equity Passive FOF": "Axis NASDAQ 100 US Specific Equity Passive FOF",

    # Debt funds with identical names
    "Axis Overnight Fund": "Axis Overnight Fund",
    "Axis Liquid Fund": "Axis Liquid Fund",
    "Axis Ultra Short Duration Fund": "Axis Ultra Short Duration Fund",
    "Axis Floater Fund": "Axis Floater Fund",
    "Axis Treasury Advantage Fund": "Axis Treasury Advantage Fund",
    "Axis Money Market Fund": "Axis Money Market Fund",
    "Axis Corporate Bond Fund": "Axis Corporate Bond Fund",
    "Axis Banking & PSU Debt Fund": "Axis Banking & PSU Debt Fund",
    "Axis Short Duration Fund": "Axis Short Duration Fund",
    "Axis Credit Risk Fund": "Axis Credit Risk Fund",
    "Axis Dynamic Bond Fund": "Axis Dynamic Bond Fund",
    "Axis Strategic Bond Fund": "Axis Strategic Bond Fund",
    "Axis Long Duration Fund": "Axis Long Duration Fund",
    "Axis Gilt Fund": "Axis Gilt Fund",
    "Axis US Specific Treasury Dynamic Debt Passive FOF": "Axis US Specific Treasury Dynamic Debt Passive FOF",
    "Axis CRISIL IBX SDL May 2027 Index Fund": "Axis CRISIL IBX SDL May 2027 Index Fund",
    "Axis NIFTY SDL September 2026 Debt Index Fund": "Axis NIFTY SDL September 2026 Debt Index Fund",

    # Debt TER variants -> approved PowerPoint names
    "Axis CRISIL IBX50:50 Gilt Plus SDL June 2028 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL June 2028 Index Fund"
    ),
    "Axis CRISIL IBX50:50 Gilt Plus SDL Sep 2027 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL September 2027 Index Fund"
    ),
    "Axis CRISIL IBX AAA Bond NBFC Jun 2027 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC - Jun 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond Fin Ser. Sep27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond Financial Services - Sep 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond NBFC-HFC-Jun27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC-HFC - JUN 2027 Index Fund"
    ),
    "Axis CRISIL-IBX Fin. Svcs 3-6 Mon Debt Index Fund": (
        "Axis CRISIL-IBX Financial Services 3-6 Months Debt Index Fund"
    ),

    # Hybrid funds
    "Axis Conservative Hybrid Fund": "Axis Conservative Hybrid Fund",
    "Axis Equity Savings Fund": "Axis Equity Savings Fund",
    "Axis Multi Asset Allocation Fund": "Axis Multi Asset Allocation Fund",
    "Axis Aggressive Hybrid Fund": "Axis Aggressive Hybrid Fund",
    "Axis Children’s Fund": "Axis Children's Fund",
    "Axis Children's Fund": "Axis Children's Fund",
    "Axis Balanced Advantage Fund": "Axis Balanced Advantage Fund",
    "Axis Arbitrage Fund": "Axis Arbitrage Fund",
    "Axis Retirement Fund - Aggressive Plan": "Axis Retirement Fund - Aggressive Plan",
    "Axis Retirement Fund - Dynamic Plan": "Axis Retirement Fund - Dynamic Plan",
    "Axis Retirement Fund - Conservative Plan": "Axis Retirement Fund - Conservative Plan",
    "Axis Income Plus Arbitrage Active FOF": "Axis Income Plus Arbitrage Active FOF",
    "Axis Income Plus Arbitrage Passive FOF": "Axis Income Plus Arbitrage Passive FOF",
    "Axis Gold Fund": "Axis Gold Fund",
    "Axis Multi-Asset Active FoF": "Axis Multi-Asset Active FoF",
    "Axis Gold and Silver Passive FoF": "Axis Gold and Silver Passive FoF",
    "Axis Silver ETF": "Axis Silver ETF",
    "Axis Gold ETF": "Axis Gold ETF",
    "Axis Silver Fund of Fund": "Axis Silver Fund of Fund",
}

# Project-level config entries override built-in mappings when required.
EXPENSE_RATIO_FUND_NAME_ALIASES: dict[str, str] = {
    **BUILTIN_EXPENSE_RATIO_FUND_NAME_ALIASES,
    **CONFIG_EXPENSE_ALIASES,
}


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846

# Excel scheme name on the left, PowerPoint FundDetails name on the right.
NORMALIZED_EXPENSE_ALIASES = {
    normalize(source): normalize(target)
    for source, target in EXPENSE_RATIO_FUND_NAME_ALIASES.items()
}


@dataclass(frozen=True)
class ExpenseRatioRecord:
    excel_fund_name: str
    canonical_fund_name: str
    regular_ber: Decimal | None
    direct_ber: Decimal | None
    sheet_name: str
    source_file: str
    source_row: int


def _clean_text(value: object) -> str:
    return " ".join(str(value or "").replace("\xa0", " ").split())


def _canonical_fund_name(excel_name: str) -> str:
    direct = EXPENSE_RATIO_FUND_NAME_ALIASES.get(excel_name)
    if direct:
        return direct
    excel_key = normalize(excel_name)
    for source, target in EXPENSE_RATIO_FUND_NAME_ALIASES.items():
        if normalize(source) == excel_key:
            return target
    return excel_name


def _fund_key(excel_name: str) -> str:
    return NORMALIZED_EXPENSE_ALIASES.get(
        normalize(excel_name),
        normalize(_canonical_fund_name(excel_name)),
    )


def _to_decimal(value: object) -> Decimal | None:
    if value in (None, ""):
        return None
    text = _clean_text(value).replace("%", "").replace(",", "")
    if not text:
        return None
    try:
        return Decimal(text)
    except InvalidOperation as error:
        raise ValueError(f"Invalid Base Expense Ratio value: {value!r}") from error


def format_expense_ratio(value: Decimal | None) -> str:
    """Format a BER value as a two-decimal percentage, for example 0.18%."""
    if value is None:
        return ""
    rounded = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return f"{rounded:.2f}%"


def _find_ber_columns(worksheet) -> tuple[int, int, int, int]:
    """Find the scheme row/column and Regular/Direct BER columns."""
    for top_row in range(1, min(worksheet.max_row, 10) + 1):
        scheme_column = None
        regular_group_start = None
        direct_group_start = None

        for column in range(1, worksheet.max_column + 1):
            text = normalize(worksheet.cell(top_row, column).value)
            if text == "name of scheme":
                scheme_column = column
            elif text == "regular plan":
                regular_group_start = column
            elif text == "direct plan":
                direct_group_start = column

        if (
            scheme_column is None
            or regular_group_start is None
            or direct_group_start is None
        ):
            continue

        detail_row = top_row + 1
        regular_ber_column = None
        direct_ber_column = None

        for column in range(
            regular_group_start,
            min(direct_group_start, worksheet.max_column + 1),
        ):
            text = normalize(worksheet.cell(detail_row, column).value)
            if text.startswith("base expense ratio"):
                regular_ber_column = column
                break

        for column in range(
            direct_group_start,
            worksheet.max_column + 1,
        ):
            text = normalize(worksheet.cell(detail_row, column).value)
            if text.startswith("base expense ratio"):
                direct_ber_column = column
                break

        if regular_ber_column is not None and direct_ber_column is not None:
            return (
                detail_row,
                scheme_column,
                regular_ber_column,
                direct_ber_column,
            )

    raise ValueError(
        f"Could not find Name of Scheme, Regular Plan BER, and Direct Plan BER "
        f"headers in worksheet '{worksheet.title}'."
    )


def read_expense_ratio_excel(
    excel_bytes: bytes,
    logger,
    source_file: str = "expense_ratio.xlsx",
) -> dict[str, ExpenseRatioRecord]:
    """Read Regular and Direct Base Expense Ratio values from one workbook."""
    if not isinstance(excel_bytes, bytes) or not excel_bytes:
        raise ValueError("A non-empty Expense Ratio Excel file is required.")

    logger.info(
        "EXPENSE_FILE_START | file=%s | bytes=%s",
        source_file,
        len(excel_bytes),
    )
    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )
    records: dict[str, ExpenseRatioRecord] = {}

    try:
        for worksheet in workbook.worksheets:
            try:
                (
                    detail_row,
                    scheme_column,
                    regular_ber_column,
                    direct_ber_column,
                ) = _find_ber_columns(worksheet)
            except ValueError as error:
                logger.info(
                    "EXPENSE_SHEET_SKIPPED | file=%s | sheet=%s | reason=%s",
                    source_file,
                    worksheet.title,
                    error,
                )
                continue

            for row in range(detail_row + 1, worksheet.max_row + 1):
                scheme = _clean_text(
                    worksheet.cell(row, scheme_column).value
                )
                if not scheme:
                    continue

                regular_ber = _to_decimal(
                    worksheet.cell(row, regular_ber_column).value
                )
                direct_ber = _to_decimal(
                    worksheet.cell(row, direct_ber_column).value
                )

                # Ignore footer/merged note rows that contain no BER values.
                if regular_ber is None and direct_ber is None:
                    continue

                canonical_name = _canonical_fund_name(scheme)
                key = _fund_key(scheme)
                if key in records:
                    raise ValueError(
                        f"Duplicate/colliding Expense Ratio fund in "
                        f"'{source_file}': '{scheme}'."
                    )

                records[key] = ExpenseRatioRecord(
                    excel_fund_name=scheme,
                    canonical_fund_name=canonical_name,
                    regular_ber=regular_ber,
                    direct_ber=direct_ber,
                    sheet_name=worksheet.title,
                    source_file=source_file,
                    source_row=row,
                )
                logger.info(
                    "EXPENSE_FUND_READ | file=%s | sheet=%s | row=%s | "
                    "excel_fund=%s | canonical_fund=%s | regular=%s | "
                    "direct=%s",
                    source_file,
                    worksheet.title,
                    row,
                    scheme,
                    canonical_name,
                    format_expense_ratio(regular_ber),
                    format_expense_ratio(direct_ber),
                )

        if not records:
            raise ValueError(
                f"No valid Regular/Direct Base Expense Ratio records were "
                f"found in '{source_file}'."
            )
        logger.info(
            "EXPENSE_FILE_COMPLETE | file=%s | funds=%s",
            source_file,
            len(records),
        )
        return records
    finally:
        workbook.close()


def read_multiple_expense_ratio_files(
    excel_files: list[tuple[str, bytes]],
    logger,
) -> dict[str, ExpenseRatioRecord]:
    """Read and merge BER records from one or more uploaded Excel files."""
    if not excel_files:
        raise ValueError("Upload at least one Expense Ratio Excel file.")

    combined: dict[str, ExpenseRatioRecord] = {}
    for source_file, excel_bytes in excel_files:
        records = read_expense_ratio_excel(
            excel_bytes=excel_bytes,
            logger=logger,
            source_file=source_file,
        )
        for key, record in records.items():
            if key in combined:
                previous = combined[key]
                raise ValueError(
                    "Duplicate/colliding Expense Ratio fund across files: "
                    f"'{record.canonical_fund_name}' in "
                    f"'{previous.source_file}' and '{source_file}'."
                )
            combined[key] = record

    logger.info(
        "EXPENSE_FILES_COMPLETE | files=%s | funds=%s",
        len(excel_files),
        len(combined),
    )
    return combined


def _match_fund(
    fund_shape,
    records: dict[str, ExpenseRatioRecord],
) -> ExpenseRatioRecord | None:
    for text in shape_texts(fund_shape):
        key = normalize(text)
        record = records.get(key)
        if record:
            return record
        alias_key = NORMALIZED_EXPENSE_ALIASES.get(key)
        if alias_key and alias_key in records:
            return records[alias_key]
    return None


def _metric_label_matches(value: object, metric: str) -> bool:
    text = normalize(value)
    target = normalize(metric)
    return re.match(
        rf"^{re.escape(target)}(?:\s|:|$)",
        text,
        flags=re.IGNORECASE,
    ) is not None


def _get_cell(table, row: int, column: int):
    try:
        return table.Cell(row, column)
    except Exception:
        return None


def _find_metric_label(table, metric: str) -> tuple[int | None, int | None]:
    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            cell = _get_cell(table, row, column)
            if cell is None:
                continue
            shape = cell.Shape
            if not shape.HasTextFrame:
                continue
            if _metric_label_matches(shape.TextFrame.TextRange.Text, metric):
                return row, column
    return None, None


def _find_value_shape(table, row: int, label_column: int):
    """Find the rightmost value cell on the same row, safely handling merges."""
    label_cell = _get_cell(table, row, label_column)
    if label_cell is None:
        return None
    label_shape_name = None
    try:
        label_shape_name = label_cell.Shape.Name
    except Exception:
        pass

    for column in range(table.Columns.Count, label_column, -1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        shape = cell.Shape
        try:
            if label_shape_name and shape.Name == label_shape_name:
                continue
        except Exception:
            pass
        if shape.HasTextFrame:
            return shape
    return None


def _replace_value_preserve_format(shape, new_text: str) -> tuple[str, str]:
    """Replace only text content; do not alter any PowerPoint formatting."""
    text_range = shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")

    # Replacing Characters rather than assigning formatting properties keeps
    # font, color, size, alignment, borders, fills, margins, and dimensions as
    # defined by the input PowerPoint table.
    if old_text:
        text_range.Characters(1, len(old_text)).Text = new_text
    else:
        text_range.Text = new_text
    return old_text, str(text_range.Text or "")


def _cell_text(table, row: int, column: int) -> str:
    cell = _get_cell(table, row, column)
    if cell is None:
        return ""
    shape = cell.Shape
    if not shape.HasTextFrame:
        return ""
    return _clean_text(shape.TextFrame.TextRange.Text)


def _find_exact_table_text(
    table,
    expected_text: str,
) -> tuple[int | None, int | None]:
    """Find an exact normalized label or column header in a table."""
    expected = normalize(expected_text)
    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            if normalize(_cell_text(table, row, column)) == expected:
                return row, column
    return None, None


def _update_current_month_table(
    expense_shape,
    record: ExpenseRatioRecord,
    slide_number: int,
    logger,
) -> int:
    """
    Update Direct then Regular in the Current Month column of ExpenseRatio.

    Previous Month, headings, labels, formatting, borders, fills, row heights,
    column widths, and table geometry are not changed.
    """
    if not expense_shape.HasTable:
        raise ValueError(
            f"'ExpenseRatio' on slide {slide_number} is not a table."
        )

    table = expense_shape.Table
    header_row, current_month_column = _find_exact_table_text(
        table,
        "Current Month",
    )
    direct_row, _ = _find_exact_table_text(table, "Direct")
    regular_row, _ = _find_exact_table_text(table, "Regular")

    if header_row is None or current_month_column is None:
        raise ValueError(
            f"Current Month header is missing from ExpenseRatio on slide "
            f"{slide_number}."
        )
    if direct_row is None or regular_row is None:
        raise ValueError(
            f"Direct or Regular row is missing from ExpenseRatio on slide "
            f"{slide_number}."
        )
    if direct_row <= header_row or regular_row <= header_row:
        raise ValueError(
            f"Direct/Regular rows are not below Current Month on slide "
            f"{slide_number}."
        )

    changes = 0
    if record.direct_ber is not None:
        direct_cell = _get_cell(table, direct_row, current_month_column)
        if direct_cell is None or not direct_cell.Shape.HasTextFrame:
            raise ValueError(
                f"Direct Current Month cell is inaccessible on slide "
                f"{slide_number}."
            )
        old_text, new_text = _replace_value_preserve_format(
            direct_cell.Shape,
            format_expense_ratio(record.direct_ber),
        )
        changes += 1
        logger.info(
            "EXPENSE_CURRENT_MONTH_CHANGED | slide=%s | fund=%s | "
            "plan=Direct | %s -> %s",
            slide_number,
            record.canonical_fund_name,
            old_text,
            new_text,
        )

    if record.regular_ber is not None:
        regular_cell = _get_cell(table, regular_row, current_month_column)
        if regular_cell is None or not regular_cell.Shape.HasTextFrame:
            raise ValueError(
                f"Regular Current Month cell is inaccessible on slide "
                f"{slide_number}."
            )
        old_text, new_text = _replace_value_preserve_format(
            regular_cell.Shape,
            format_expense_ratio(record.regular_ber),
        )
        changes += 1
        logger.info(
            "EXPENSE_CURRENT_MONTH_CHANGED | slide=%s | fund=%s | "
            "plan=Regular | %s -> %s",
            slide_number,
            record.canonical_fund_name,
            old_text,
            new_text,
        )

    return changes


def _update_scheme_details_table(
    details_shape,
    record: ExpenseRatioRecord,
    slide_number: int,
    scheme_details_object: str,
    logger,
) -> int:
    """Update Regular and Direct BER values in SchemeDetails only."""
    if not details_shape.HasTable:
        raise ValueError(
            f"'{scheme_details_object}' on slide {slide_number} is not a table."
        )
    table = details_shape.Table
    regular_row, regular_label_column = _find_metric_label(
        table,
        "Regular Plan",
    )
    direct_row, direct_label_column = _find_metric_label(
        table,
        "Direct Plan",
    )
    if regular_row is None or direct_row is None:
        raise ValueError(
            f"Regular Plan or Direct Plan label is missing from "
            f"'{scheme_details_object}' on slide {slide_number}."
        )

    regular_value_shape = _find_value_shape(
        table,
        regular_row,
        regular_label_column,
    )
    direct_value_shape = _find_value_shape(
        table,
        direct_row,
        direct_label_column,
    )
    if regular_value_shape is None or direct_value_shape is None:
        raise ValueError(
            f"Could not locate BER value cells on slide {slide_number}."
        )

    changes = 0
    if record.regular_ber is not None:
        old_text, new_text = _replace_value_preserve_format(
            regular_value_shape,
            format_expense_ratio(record.regular_ber),
        )
        changes += 1
        logger.info(
            "EXPENSE_VALUE_CHANGED | slide=%s | fund=%s | "
            "table=SchemeDetails | plan=Regular | %s -> %s",
            slide_number,
            record.canonical_fund_name,
            old_text,
            new_text,
        )

    if record.direct_ber is not None:
        old_text, new_text = _replace_value_preserve_format(
            direct_value_shape,
            format_expense_ratio(record.direct_ber),
        )
        changes += 1
        logger.info(
            "EXPENSE_VALUE_CHANGED | slide=%s | fund=%s | "
            "table=SchemeDetails | plan=Direct | %s -> %s",
            slide_number,
            record.canonical_fund_name,
            old_text,
            new_text,
        )
    return changes


def _com_code(error: Exception) -> int | None:
    return getattr(
        error,
        "hresult",
        error.args[0] if error.args and isinstance(error.args[0], int) else None,
    )


def _retry_com(name: str, operation, logger, attempts: int = 8):
    delay = 0.75
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            if _com_code(error) not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "EXPENSE_COM_RETRY | operation=%s | attempt=%s/%s | "
                "wait=%.2f",
                name,
                attempt,
                attempts,
                delay,
            )
            time.sleep(delay)
            delay = min(4.0, delay * 1.7)


def apply_expense_ratio(
    current_ppt_bytes: bytes,
    expense_excel_files: list[tuple[str, bytes]],
    fund_object: str,
    scheme_details_object: str,
    logger,
    strict: bool = False,
    expense_ratio_table_object: str = "ExpenseRatio",
) -> bytes:
    """
    Paste BER into SchemeDetails and ExpenseRatio for every matched fund.

    SchemeDetails receives Regular and Direct values. ExpenseRatio receives
    Direct first and Regular second in the Current Month column only. Previous
    Month and all formatting, borders, fills, dimensions, labels, and geometry
    remain unchanged.
    """
    records = read_multiple_expense_ratio_files(
        excel_files=expense_excel_files,
        logger=logger,
    )
    logger.info(
        "EXPENSE_START | ppt_bytes=%s | records=%s | strict=%s",
        len(current_ppt_bytes),
        len(records),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = presentation = None
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "working.pptx"
            output_path = Path(temp_dir) / "expense_ratio_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = _retry_com(
                "start PowerPoint",
                lambda: win32com.client.DispatchEx("PowerPoint.Application"),
                logger,
            )
            _retry_com(
                "set DisplayAlerts",
                lambda: setattr(powerpoint, "DisplayAlerts", False),
                logger,
            )
            presentation = _retry_com(
                "open presentation",
                lambda: powerpoint.Presentations.Open(
                    str(input_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            slides_updated = slides_skipped = changes = 0
            scheme_details_updates = expense_table_updates = 0

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                details = find_shape_recursive(
                    slide.Shapes,
                    scheme_details_object,
                )
                expense_table = find_shape_recursive(
                    slide.Shapes,
                    expense_ratio_table_object,
                )

                # A slide is relevant when it has either target table.
                if details is None and expense_table is None:
                    continue

                fund_shape = find_shape_recursive(slide.Shapes, fund_object)
                if fund_shape is None:
                    message = (
                        f"Object '{fund_object}' is missing on slide "
                        f"{slide_number}."
                    )
                    if strict:
                        raise ValueError(message)
                    slides_skipped += 1
                    logger.warning(
                        "EXPENSE_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    continue

                record = _match_fund(fund_shape, records)
                if record is None:
                    message = (
                        f"No Expense Ratio record matched PowerPoint fund "
                        f"{' | '.join(shape_texts(fund_shape))!r}."
                    )
                    if strict:
                        raise ValueError(message)
                    slides_skipped += 1
                    logger.warning(
                        "EXPENSE_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    continue

                slide_changes = 0

                if details is not None:
                    detail_changes = _update_scheme_details_table(
                        details_shape=details,
                        record=record,
                        slide_number=slide_number,
                        scheme_details_object=scheme_details_object,
                        logger=logger,
                    )
                    scheme_details_updates += detail_changes
                    slide_changes += detail_changes

                if expense_table is not None:
                    current_month_changes = _update_current_month_table(
                        expense_shape=expense_table,
                        record=record,
                        slide_number=slide_number,
                        logger=logger,
                    )
                    expense_table_updates += current_month_changes
                    slide_changes += current_month_changes

                if slide_changes:
                    slides_updated += 1
                    changes += slide_changes
                    logger.info(
                        "EXPENSE_UPDATED | slide=%s | fund=%s | regular=%s | "
                        "direct=%s | scheme_details=%s | current_month=%s | "
                        "changes=%s",
                        slide_number,
                        record.canonical_fund_name,
                        format_expense_ratio(record.regular_ber),
                        format_expense_ratio(record.direct_ber),
                        details is not None,
                        expense_table is not None,
                        slide_changes,
                    )

            _retry_com(
                "save presentation",
                lambda: presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            _retry_com(
                "close presentation",
                presentation.Close,
                logger,
                attempts=4,
            )
            presentation = None
            output = output_path.read_bytes()
            if not output:
                raise RuntimeError("The generated PowerPoint file is empty.")
            logger.info(
                "EXPENSE_COMPLETE | slides_updated=%s | slides_skipped=%s | "
                "scheme_details_changes=%s | current_month_changes=%s | "
                "changes=%s | bytes=%s",
                slides_updated,
                slides_skipped,
                scheme_details_updates,
                expense_table_updates,
                changes,
                len(output),
            )
            return output
    except Exception:
        logger.exception("EXPENSE_FAILED")
        raise
    finally:
        if presentation is not None:
            try:
                _retry_com(
                    "cleanup close presentation",
                    presentation.Close,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass
        if powerpoint is not None:
            try:
                _retry_com(
                    "quit PowerPoint",
                    powerpoint.Quit,
                    logger,
                    attempts=3,
                )
            except Exception:
                pass
        pythoncom.CoUninitialize()
