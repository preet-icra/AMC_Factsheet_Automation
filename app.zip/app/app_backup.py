from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from inspect import signature

import streamlit as st

from aum_aaum.logic import apply_aum_aaum, read_aum_excel
from config import (
    DETAILS_EXPOSURE_ICON_OBJECT,
    DETAILS_EXPOSURE_TEXT_BG_OBJECT,
    DETAILS_OF_EXPOSURE_BOX_OBJECT,
    DETAILS_OF_EXPOSURE_TABLE_OBJECT,
    FINAL_OUTPUT_NAME,
    FUND_DETAILS_OBJECT,
    FUND_NAME_COLUMN,
    FUND_NAME_SHEET,
    MARKET_CAP_TABLE_OBJECT,
    MEASURES_TABLE_OBJECT,
    PTC_ICON_OBJECT,
    PTC_TABLE_BOX_OBJECT,
    PTC_TABLE_OBJECT,
    PTC_TEXT_BG_OBJECT,
    PORTFOLIO_TABLE_OBJECT,
    SCHEME_DETAILS_OBJECT,
    SIP_FUND_NAME_OBJECT,
    SIP_PERFORMANCE_DATE_OBJECT,
    SIP_TABLE_OBJECT,
)
from detailsPTC.logic import (
    apply_details_of_exposure,
    read_details_of_exposure_excel,
)
from expense_ratio.logic import (
    apply_expense_ratio,
    format_expense_ratio,
    read_multiple_expense_ratio_files,
)
from marketcap.logic import (
    apply_market_cap,
    format_market_cap,
    read_market_cap_excel,
)
from nav.logic import apply_nav, read_nav_workbook
from PTC.logic import apply_ptc, read_ptc_excel
from portfoliotable.logic import (
    apply_portfolio,
    format_nav_percent,
    read_portfolio_excel,
)
from risk_measures.logic import (
    apply_risk_measures,
    format_risk_measure,
    read_multiple_risk_measures_files,
)
from scheme_creation.logic import (
    SCHEME_PROFILES,
    FundDetailsFormatting,
    LengthPositionRule,
    SchemeProfile,
    create_scheme_presentation,
    get_available_scheme_profiles,
    get_axis_categories,
    get_scheme_profile,
    read_fund_names,
    resolve_profile_key,
)
from sip.logic import apply_sip, read_multiple_sip_files
from utils.logger import build_logger, logs_to_bytes


# -----------------------------------------------------------------------------
# Page configuration
# -----------------------------------------------------------------------------

st.set_page_config(
    page_title="Fund Factsheet Automation",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .stApp { background: #0d1117; color: #f3f4f6; }
    [data-testid="stSidebar"] {
        background: #171b24;
        border-right: 1px solid #303642;
    }
    [data-testid="stSidebar"] * { color: #f3f4f6; }
    .block-container {
        max-width: 1500px;
        padding-top: 1.4rem;
        padding-bottom: 3rem;
    }
    h1, h2, h3 { color: #f8fafc; letter-spacing: -0.02em; }
    div[data-testid="stCaptionContainer"] { color: #aab2c0; }
    div[data-testid="stTabs"] button {
        min-height: 3.1rem;
        border-radius: .55rem .55rem 0 0;
        font-weight: 650;
    }
    div[data-testid="stTabs"] button[aria-selected="true"] {
        color: #fff;
        border-bottom-color: #ff4b55;
        background: #232936;
    }
    div.stButton > button,
    div.stDownloadButton > button {
        border-radius: .5rem;
        min-height: 2.8rem;
        font-weight: 650;
    }
    div.stButton > button[kind="primary"],
    div.stDownloadButton > button[kind="primary"] {
        background: #ff4b55;
        border-color: #ff4b55;
        color: white;
    }
    div[data-testid="stFileUploader"] {
        background: #151a23;
        border: 1px solid #303642;
        border-radius: .65rem;
        padding: .4rem .8rem;
    }
    div[data-testid="stDataFrame"] {
        border: 1px solid #303642;
        border-radius: .55rem;
        overflow: hidden;
    }
    div[data-testid="stExpander"] {
        border: 1px solid #303642;
        border-radius: .65rem;
        background: #121720;
    }
    .workspace-kicker {
        color: #ff6870;
        font-size: .78rem;
        font-weight: 750;
        letter-spacing: .12em;
        text-transform: uppercase;
    }
    .workspace-title {
        font-size: 2.2rem;
        font-weight: 780;
        margin: .2rem 0 .25rem;
    }
    .workspace-subtitle { color: #aab2c0; margin-bottom: 1.2rem; }
    .summary-label {
        color: #8f98a8;
        font-size: .72rem;
        font-weight: 750;
        letter-spacing: .08em;
        text-transform: uppercase;
        margin-top: 1.1rem;
    }
    .summary-value {
        color: #f8fafc;
        font-size: .98rem;
        margin-top: .15rem;
        overflow-wrap: anywhere;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="workspace-kicker">Multi-AMC Factsheet Automation</div>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="workspace-title">Fund PowerPoint Workspace</div>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="workspace-subtitle">Select an AMC, create a profile-formatted '
    'presentation, and apply data updates in one sequential workflow.</div>',
    unsafe_allow_html=True,
)


# -----------------------------------------------------------------------------
# Session state
# -----------------------------------------------------------------------------

SESSION_DEFAULTS = {
    "working_ppt": None,
    "working_name": "",
    "workflow_logs": [],
    "applied_modules": [],
    "selected_amc": "axis",
}

for key, value in SESSION_DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = (
            value.copy() if isinstance(value, list) else value
        )


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


def callback_for(box):
    def callback(_message: str) -> None:
        box.code(
            "\n".join(st.session_state.workflow_logs[-40:]),
            language="text",
        )

    return callback


def set_working_ppt(data: bytes, name: str) -> None:
    st.session_state.working_ppt = data
    st.session_state.working_name = name


def add_applied_module(module_name: str) -> None:
    if module_name not in st.session_state.applied_modules:
        st.session_state.applied_modules.append(module_name)


def clear_workflow_state() -> None:
    st.session_state.workflow_logs = []
    st.session_state.applied_modules = []


def require_file(value, label: str, errors: list[str]) -> None:
    if not value:
        errors.append(f"Upload the required {label} file.")


def display_optional_metric(value: Decimal | None) -> str:
    return "" if value is None else format_risk_measure(value)


def progress_percent(completed_count: int, total_count: int) -> int:
    """Return a safe whole-number workflow percentage."""
    if total_count <= 0:
        return 0
    return min(100, max(0, round(completed_count * 100 / total_count)))


def update_operation_progress(
    overall_bar,
    task_bar,
    operation_name: str,
    completed_count: int,
    total_count: int,
    task_percent: int,
    status_box=None,
) -> None:
    """Update accurate overall and current-task progress indicators."""
    safe_task_percent = min(100, max(0, int(task_percent)))
    overall_percent = progress_percent(completed_count, total_count)

    overall_bar.progress(
        overall_percent,
        text=(
            f"Overall progress: {overall_percent}% | "
            f"Completed {completed_count} of {total_count} operation(s)"
        ),
    )
    task_bar.progress(
        safe_task_percent,
        text=(
            f"Current task: {operation_name} | "
            f"{safe_task_percent}%"
        ),
    )

    if status_box is not None:
        status_box.info(
            f"Processing: {operation_name} | "
            f"Task {safe_task_percent}% | "
            f"Overall {overall_percent}%"
        )


def create_scheme_with_optional_progress(
    *,
    template_bytes: bytes,
    selected_funds,
    fund_column: str,
    selected_amc: str,
    logger,
    selected_category: str | None,
    profile_overrides: SchemeProfile,
    progress_callback,
):
    """
    Call scheme creation with progress support when the installed logic module
    accepts it. Older logic.py versions are called without the new keyword so
    they do not fail with an unexpected keyword argument error.
    """
    parameters = signature(create_scheme_presentation).parameters
    supports_progress = "progress_callback" in parameters

    common_arguments = {
        "template_bytes": template_bytes,
        "selected_funds": selected_funds,
        "fund_column": fund_column,
        "selected_amc": selected_amc,
        "logger": logger,
        "selected_category": selected_category,
        "profile_overrides": profile_overrides,
    }

    if supports_progress:
        progress_callback(
            1,
            "Delegating workflow",
            "The installed scheme module supports detailed progress updates.",
        )
        return create_scheme_presentation(
            **common_arguments,
            progress_callback=progress_callback,
        )

    progress_callback(
        20,
        "Compatibility mode",
        (
            "The installed scheme_creation/logic.py does not yet support "
            "progress_callback. Scheme creation is running without internal "
            "per-fund percentage updates."
        ),
    )
    result = create_scheme_presentation(**common_arguments)
    progress_callback(
        98,
        "Verifying output",
        "Scheme creation returned successfully; preparing the download file.",
    )
    return result


def profile_summary(profile: SchemeProfile) -> dict[str, object]:
    return {
        "AMC / category": profile.display_name,
        "Fund object name": profile.fund_object,
        "Template fund text": profile.template_fund_name,
        "Slides per fund": profile.slides_per_fund,
        "Text case": profile.fund_details.text_case,
        "Color": "Preserve template",
        "Font and font size": (
            "Preserve template, except long-name rule font size"
        ),
        "Bold and italic": "Preserve template",
        "Alignment": "Preserve template",
        "Word wrap": "Preserve template",
        "Long-name rules": len(profile.fund_details.length_rules),
    }


def editable_profile(
    base_profile: SchemeProfile,
    widget_prefix: str,
) -> SchemeProfile:
    """Allow safe runtime changes while preserving template formatting."""
    st.caption(
        "The PowerPoint object name, template fund text, slides per fund, "
        "and long-name rules are editable. All visual formatting is preserved "
        "from the uploaded template."
    )

    left, middle, right = st.columns(3)
    with left:
        fund_object = st.text_input(
            "Fund object name",
            value=base_profile.fund_object,
            key=f"{widget_prefix}_fund_object",
            help=(
                "PowerPoint Selection Pane name of the shape containing "
                "the fund name."
            ),
        )
    with middle:
        template_fund_name = st.text_input(
            "Template fund text",
            value=base_profile.template_fund_name,
            key=f"{widget_prefix}_template_name",
            help=(
                "Exact fund name currently written inside the uploaded "
                "template."
            ),
        )
    with right:
        slides_per_fund = st.number_input(
            "Slides per fund",
            min_value=1,
            max_value=25,
            value=int(base_profile.slides_per_fund),
            step=1,
            key=f"{widget_prefix}_slides_per_fund",
            help=(
                "Number of template slides that belong to one fund. The "
                "uploaded template must contain exactly this many slides "
                "when strict slide-count validation is enabled."
            ),
        )

    st.markdown("##### Long-name rules")
    st.caption(
        "A rule applies only when the new fund name is longer than its "
        "character limit. Use 0 for a movement or size value that should "
        "not change."
    )

    base_rules = base_profile.fund_details.length_rules
    rule_count = st.number_input(
        "Number of long-name rules",
        min_value=0,
        max_value=5,
        value=len(base_rules),
        step=1,
        key=f"{widget_prefix}_rule_count",
    )

    rules: list[LengthPositionRule] = []

    for index in range(int(rule_count)):
        original = (
            base_rules[index]
            if index < len(base_rules)
            else LengthPositionRule(character_limit=50)
        )

        with st.expander(
            f"Long-name rule {index + 1}",
            expanded=True,
        ):
            first_row = st.columns(3)
            character_limit = first_row[0].number_input(
                "Apply when name is longer than",
                min_value=1,
                value=int(original.character_limit),
                step=1,
                key=f"{widget_prefix}_rule_{index}_limit",
            )
            top_shift = first_row[1].number_input(
                "Move up/down (cm)",
                value=float(original.top_shift_cm),
                step=0.05,
                key=f"{widget_prefix}_rule_{index}_top",
                help="Negative moves up. Positive moves down.",
            )
            font_size = first_row[2].number_input(
                "Font size",
                min_value=0.0,
                value=float(original.font_size or 0.0),
                step=0.5,
                key=f"{widget_prefix}_rule_{index}_font",
                help="Use 0 to keep the template font size.",
            )

            with st.expander(
                "Advanced position and size adjustments",
                expanded=False,
            ):
                advanced = st.columns(3)
                left_shift = advanced[0].number_input(
                    "Move left/right (cm)",
                    value=float(original.left_shift_cm),
                    step=0.05,
                    key=f"{widget_prefix}_rule_{index}_left",
                )
                width_adjustment = advanced[1].number_input(
                    "Width adjustment (cm)",
                    value=float(original.width_adjustment_cm),
                    step=0.05,
                    key=f"{widget_prefix}_rule_{index}_width",
                )
                height_adjustment = advanced[2].number_input(
                    "Height adjustment (cm)",
                    value=float(original.height_adjustment_cm),
                    step=0.05,
                    key=f"{widget_prefix}_rule_{index}_height",
                )

            rules.append(
                LengthPositionRule(
                    character_limit=int(character_limit),
                    top_shift_cm=float(top_shift),
                    left_shift_cm=float(left_shift),
                    width_adjustment_cm=float(width_adjustment),
                    height_adjustment_cm=float(height_adjustment),
                    font_size=float(font_size) or None,
                )
            )

    if not fund_object.strip():
        raise ValueError("Fund object name cannot be blank.")
    if not template_fund_name.strip():
        raise ValueError("Template fund text cannot be blank.")
    if int(slides_per_fund) < 1:
        raise ValueError("Slides per fund must be at least 1.")

    preserved_formatting = FundDetailsFormatting(
        # Follow the selected AMC profile's capitalization rule. Axis, HSBC,
        # Nippon, and Quantum remain uppercase; Navi remains title case.
        # This changes text case only. All visual formatting still comes from
        # the uploaded PowerPoint template.
        text_case=base_profile.fund_details.text_case,

        # Keep all visual formatting from the uploaded PowerPoint template.
        color_mode="preserve",
        uniform_rgb=None,
        first_word_rgb=None,
        remainder_rgb=None,
        font_name=None,
        font_size=None,
        bold=None,
        italic=None,
        alignment=None,
        word_wrap=None,
        auto_size="none",

        # Only these explicitly configured long-name rules may change the
        # FundDetails position, dimensions, or font size.
        length_rules=tuple(rules),
    )

    return SchemeProfile(
        key=base_profile.key,
        display_name=base_profile.display_name,
        template_fund_name=template_fund_name.strip(),
        fund_object=fund_object.strip(),
        slides_per_fund=int(slides_per_fund),
        fund_details=preserved_formatting,
        static_text_replacements=base_profile.static_text_replacements,
        global_text_replacements=base_profile.global_text_replacements,
        strict_slide_count=base_profile.strict_slide_count,
    )


# -----------------------------------------------------------------------------
# Sidebar
# -----------------------------------------------------------------------------

with st.sidebar:
    st.subheader("Run summary")

    st.markdown(
        '<div class="summary-label">Selected AMC</div>',
        unsafe_allow_html=True,
    )
    try:
        sidebar_profile = get_scheme_profile(
            st.session_state.selected_amc
        )
        sidebar_amc = sidebar_profile.display_name
    except Exception:
        sidebar_amc = "Not selected"

    st.markdown(
        f'<div class="summary-value">{sidebar_amc}</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="summary-label">Presentation</div>',
        unsafe_allow_html=True,
    )
    status = (
        st.session_state.working_name
        if st.session_state.working_ppt
        else "Not loaded"
    )
    st.markdown(
        f'<div class="summary-value">{status}</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="summary-label">Applied modules</div>',
        unsafe_allow_html=True,
    )
    modules = ", ".join(st.session_state.applied_modules) or "None"
    st.markdown(
        f'<div class="summary-value">{modules}</div>',
        unsafe_allow_html=True,
    )

    if st.session_state.working_ppt:
        st.metric(
            "Working file size",
            f"{len(st.session_state.working_ppt) / 1024 / 1024:.2f} MB",
        )

    st.divider()
    st.caption(
        "Create or upload a presentation first. Operations always use "
        "the latest working presentation."
    )


# -----------------------------------------------------------------------------
# Tabs
# -----------------------------------------------------------------------------

setup_tab, operations_tab, download_tab = st.tabs(
    [
        "1. Setup",
        "2. Operations",
        "3. Download & Logs",
    ]
)


# -----------------------------------------------------------------------------
# Setup
# -----------------------------------------------------------------------------

with setup_tab:
    st.subheader("Choose or create the working PowerPoint")

    source_choice = st.radio(
        "PowerPoint source",
        [
            "Create scheme slides from an AMC template",
            "Upload an existing PowerPoint",
        ],
        horizontal=True,
        key="powerpoint_source",
    )

    if source_choice == "Upload an existing PowerPoint":
        existing_ppt = st.file_uploader(
            "Upload existing PPTX",
            type=["pptx"],
            key="existing_ppt",
        )

        if existing_ppt and st.button(
            "Use this PowerPoint",
            type="primary",
            key="use_existing_ppt",
            width="stretch",
        ):
            data = existing_ppt.getvalue()
            clear_workflow_state()
            set_working_ppt(data, existing_ppt.name)
            st.session_state.workflow_logs.append(
                "SOURCE_PPT_LOADED | "
                f"file={existing_ppt.name} | bytes={len(data)}"
            )
            st.success("Working PowerPoint loaded.")

    else:
        options = get_available_scheme_profiles()
        labels = {
            item["value"]: item["label"]
            for item in options
        }

        selected_amc = st.selectbox(
            "Select AMC",
            options=list(labels),
            format_func=lambda value: labels[value],
            key="selected_amc",
        )

        selected_category = None

        if selected_amc == "axis":
            category_options = get_axis_categories()
            category_labels = {
                item["value"]: item["label"]
                for item in category_options
            }
            selected_category = st.selectbox(
                "Select Axis category",
                options=list(category_labels),
                format_func=lambda value: category_labels[value],
                key="selected_axis_category",
            )
            profile_key = resolve_profile_key(
                selected_amc,
                selected_category,
            )
            profile = SCHEME_PROFILES[profile_key]
            st.info(
                f"Axis {category_labels[selected_category]} settings are "
                "active. Equity, Debt, and Hybrid are available only "
                "for Axis."
            )
        else:
            profile = get_scheme_profile(selected_amc)
            st.info(
                f"The {profile.display_name} profile is active. Category "
                "selection is intentionally hidden for this AMC."
            )

        st.info(
            f"The {profile.display_name} profile will be applied to every "
            "generated scheme slide."
        )

        profile_error = None
        runtime_profile = profile

        with st.expander("Edit active AMC settings", expanded=True):
            try:
                runtime_profile = editable_profile(
                    profile,
                    f"profile_{profile.key}",
                )
                st.success("Runtime settings are valid.")
                st.json(profile_summary(runtime_profile))
            except Exception as error:
                profile_error = str(error)
                st.error(f"Profile settings error: {error}")

        left, right = st.columns(2)
        with left:
            template_file = st.file_uploader(
                f"Upload {runtime_profile.display_name} PowerPoint template",
                type=["pptx"],
                key=f"template_{selected_amc}_{selected_category or 'all'}",
                help=(
                    f"The active setting expects "
                    f"{runtime_profile.slides_per_fund} template slide(s) "
                    "for each fund."
                ),
            )
        with right:
            fund_file = st.file_uploader(
                f"Upload {runtime_profile.display_name} fund-name Excel",
                type=["xlsx"],
                key=f"funds_{selected_amc}_{selected_category or 'all'}",
            )

        selected_data = None
        preview_error = None

        if fund_file:
            try:
                preview_logs: list[str] = []
                preview_logger = build_logger(
                    f"fund_preview_{selected_amc}",
                    preview_logs,
                    None,
                )
                funds = read_fund_names(
                    fund_file.getvalue(),
                    FUND_NAME_SHEET,
                    FUND_NAME_COLUMN,
                    preview_logger,
                )
                names = (
                    funds[FUND_NAME_COLUMN]
                    .dropna()
                    .astype(str)
                    .tolist()
                )
                selected_names = st.multiselect(
                    "Funds to create",
                    names,
                    default=names,
                    key=(
                        f"selected_funds_{selected_amc}_"
                        f"{selected_category or 'all'}"
                    ),
                )
                selected_data = funds[
                    funds[FUND_NAME_COLUMN].isin(selected_names)
                ].copy()
                st.dataframe(
                    selected_data[[FUND_NAME_COLUMN]],
                    hide_index=True,
                    width="stretch",
                )
                expected = (
                    len(selected_data)
                    * runtime_profile.slides_per_fund
                )
                st.caption(
                    f"{len(selected_data)} fund(s) selected | "
                    f"{expected} slide(s) expected"
                )
            except Exception as error:
                preview_error = str(error)
                st.error(f"Fund preview failed: {error}")

        scheme_log_box = st.empty()
        create_disabled = (
            not template_file
            or not fund_file
            or selected_data is None
            or selected_data.empty
            or preview_error is not None
            or profile_error is not None
        )

        if st.button(
            f"Create {runtime_profile.display_name} presentation",
            type="primary",
            disabled=create_disabled,
            key="create_amc_presentation",
            width="stretch",
        ):
            clear_workflow_state()
            logger = build_logger(
                "scheme_creation",
                st.session_state.workflow_logs,
                callback_for(scheme_log_box),
            )

            try:
                creation_progress = st.progress(
                    1,
                    text="Scheme creation: 1% | Validating inputs",
                )
                creation_status = st.empty()

                def scheme_progress_callback(
                    percent: int,
                    stage: str,
                    message: str,
                ) -> None:
                    safe_percent = min(100, max(1, int(percent)))
                    creation_progress.progress(
                        safe_percent,
                        text=(
                            f"Scheme creation: {safe_percent}% | {stage}"
                        ),
                    )
                    creation_status.info(message)

                with st.spinner(
                    f"Creating {runtime_profile.display_name} slides..."
                ):
                    output = create_scheme_with_optional_progress(
                        template_bytes=template_file.getvalue(),
                        selected_funds=selected_data,
                        fund_column=FUND_NAME_COLUMN,
                        selected_amc=selected_amc,
                        logger=logger,
                        selected_category=selected_category,
                        profile_overrides=runtime_profile,
                        progress_callback=scheme_progress_callback,
                    )

                output_suffix = (
                    f"_{selected_category}"
                    if selected_category
                    else ""
                )
                output_name = (
                    f"{selected_amc}{output_suffix}_"
                    "scheme_presentation.pptx"
                )
                set_working_ppt(output, output_name)
                add_applied_module(
                    f"Scheme creation: {runtime_profile.display_name}"
                )
                creation_progress.progress(
                    100,
                    text="Scheme creation: 100% | Presentation ready",
                )
                creation_status.success(
                    f"Created {len(selected_data)} fund(s) using "
                    f"{runtime_profile.slides_per_fund} slide(s) per fund."
                )
                st.success(
                    f"Created {len(selected_data)} "
                    f"{runtime_profile.display_name} scheme(s)."
                )
            except Exception as error:
                st.error(
                    f"{runtime_profile.display_name} scheme creation "
                    f"failed: {error}"
                )

    st.divider()
    if st.session_state.working_ppt:
        st.success(
            f"Working PowerPoint ready: "
            f"{st.session_state.working_name} "
            f"({len(st.session_state.working_ppt):,} bytes)"
        )
    else:
        st.warning(
            "Load or create a working PowerPoint before running operations."
        )


# -----------------------------------------------------------------------------
# Operations
# -----------------------------------------------------------------------------

with operations_tab:
    st.subheader("Select operations")
    st.caption(
        "Selected operations run top-to-bottom. Each operation receives "
        "the output of the previous operation."
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        run_nav = st.checkbox("1. NAV", key="select_nav")
        run_ptc = st.checkbox(
            "Weighted Average Maturity of PTC",
            key="select_ptc",
        )
        run_portfolio = st.checkbox(
            "Portfolio Top 10 Holdings",
            key="select_portfolio",
        )
    with c2:
        run_aum = st.checkbox("2. AUM & AAUM", key="select_aum")
        run_risk = st.checkbox(
            "Risk Measures",
            key="select_risk",
        )
        run_exposure = st.checkbox(
            "Details of Exposure",
            key="select_exposure",
        )
    with c3:
        run_expense = st.checkbox(
                    "3. Expense Ratio",
                    key="select_expense",
                )
        run_market_cap = st.checkbox(
            "Market Cap",
            key="select_market_cap",
        )
        
        run_sip = st.checkbox("SIP", key="select_sip")

    operation_flags = [
        ("NAV", run_nav),
        ("AUM & AAUM", run_aum),
        ("Expense Ratio", run_expense),
        ("Risk Measures", run_risk),
        ("Market Cap", run_market_cap),
        ("SIP", run_sip),
        ("Portfolio Top 10 Holdings", run_portfolio),
        ("Details of Exposure", run_exposure),
        ("Weighted Average Maturity of PTC", run_ptc),
    ]
    selected_operations = [
        name
        for name, enabled in operation_flags
        if enabled
    ]

    st.info(
        "Execution order: " + " → ".join(selected_operations)
        if selected_operations
        else "Select at least one operation."
    )
    if selected_operations:
        st.caption(
            "Progress percentages advance at verified operation boundaries. "
            "A PowerPoint operation remains at 10% while its internal COM "
            "work is running, then changes to 100% only after it returns "
            "successfully."
        )

    nav_file = None
    aum_file = None
    market_cap_file = None
    exposure_file = None
    ptc_file = None
    portfolio_file = None
    expense_files = []
    risk_files = []
    sip_files = []

    strict_nav = True
    strict_expense = False
    strict_risk = False
    strict_market = False
    strict_sip = False
    strict_exposure = False
    strict_ptc = False
    strict_portfolio = False

    if run_nav:
        with st.expander("NAV inputs", expanded=True):
            nav_file = st.file_uploader(
                "Upload NAV factsheet",
                type=["xls"],
                key="nav_file",
            )
            strict_nav = st.checkbox(
                "Stop on NAV overflow",
                value=True,
                key="strict_nav",
            )
            if nav_file:
                try:
                    records = read_nav_workbook(
                        nav_file.getvalue(),
                        build_logger("nav_preview", [], None),
                    )
                    st.caption(f"{len(records)} NAV record(s) found.")
                except Exception as error:
                    st.error(f"NAV preview failed: {error}")

    if run_aum:
        with st.expander("AUM & AAUM inputs", expanded=True):
            aum_file = st.file_uploader(
                "Upload AUM and AAUM Excel",
                type=["xlsx"],
                key="aum_file",
            )
            if aum_file:
                try:
                    records = read_aum_excel(
                        aum_file.getvalue(),
                        build_logger("aum_preview", [], None),
                    )
                    st.caption(f"{len(records)} AUM record(s) found.")
                except Exception as error:
                    st.error(f"AUM preview failed: {error}")

    if run_expense:
        with st.expander("Expense Ratio inputs", expanded=True):
            expense_files = st.file_uploader(
                "Upload Expense Ratio files",
                type=["xls", "xlsx"],
                accept_multiple_files=True,
                key="expense_files",
            )
            strict_expense = st.checkbox(
                "Stop on unmatched Expense Ratio data",
                value=False,
                key="strict_expense",
            )
            if expense_files:
                try:
                    inputs = [
                        (file.name, file.getvalue())
                        for file in expense_files
                    ]
                    records = read_multiple_expense_ratio_files(
                        excel_files=inputs,
                        logger=build_logger(
                            "expense_preview",
                            [],
                            None,
                        ),
                    )
                    st.dataframe(
                        [
                            {
                                "Fund": record.canonical_fund_name,
                                "Regular BER": format_expense_ratio(
                                    record.regular_ber
                                ),
                                "Direct BER": format_expense_ratio(
                                    record.direct_ber
                                ),
                            }
                            for record in records.values()
                        ],
                        hide_index=True,
                        width="stretch",
                    )
                except Exception as error:
                    st.error(f"Expense Ratio preview failed: {error}")

    if run_risk:
        with st.expander("Risk Measures inputs", expanded=True):
            risk_files = st.file_uploader(
                "Upload Risk Measures files",
                type=["xls", "xlsx", "xlsb"],
                accept_multiple_files=True,
                key="risk_files",
            )
            strict_risk = st.checkbox(
                "Stop on unmatched Risk Measures data",
                value=False,
                key="strict_risk",
            )
            if risk_files:
                try:
                    inputs = [
                        (file.name, file.getvalue())
                        for file in risk_files
                    ]
                    records = read_multiple_risk_measures_files(
                        excel_files=inputs,
                        logger=build_logger(
                            "risk_preview",
                            [],
                            None,
                        ),
                    )
                    st.caption(
                        f"{len(records)} Risk Measures record(s) found."
                    )
                    st.dataframe(
                        [
                            {
                                "Fund": record.canonical_fund_name,
                                "Excel Fund": record.excel_fund_name,
                                "Equity Turnover": display_optional_metric(
                                    record.pto_ratio
                                ),
                                "Portfolio Yield": display_optional_metric(
                                    record.portfolio_yield
                                ),
                            }
                            for record in records.values()
                        ],
                        hide_index=True,
                        width="stretch",
                    )
                except Exception as error:
                    st.error(f"Risk Measures preview failed: {error}")

    if run_market_cap:
        with st.expander("Market Cap inputs", expanded=True):
            market_cap_file = st.file_uploader(
                "Upload Market Cap Excel",
                type=["xlsx"],
                key="market_file",
            )
            strict_market = st.checkbox(
                "Stop on unmatched Market Cap data",
                value=False,
                key="strict_market",
            )
            if market_cap_file:
                try:
                    records = read_market_cap_excel(
                        excel_bytes=market_cap_file.getvalue(),
                        logger=build_logger(
                            "market_preview",
                            [],
                            None,
                        ),
                        source_file=market_cap_file.name,
                    )
                    st.dataframe(
                        [
                            {
                                "Fund": record.fund_name,
                                "Large Cap": format_market_cap(
                                    record.values.get("Large Cap")
                                ),
                                "Mid Cap": format_market_cap(
                                    record.values.get("Mid Cap")
                                ),
                                "Small Cap": format_market_cap(
                                    record.values.get("Small Cap")
                                ),
                            }
                            for record in records.values()
                        ],
                        hide_index=True,
                        width="stretch",
                    )
                except Exception as error:
                    st.error(f"Market Cap preview failed: {error}")

    if run_sip:
        with st.expander("SIP inputs", expanded=True):
            sip_files = st.file_uploader(
                "Upload SIP Excel files",
                type=["xlsx"],
                accept_multiple_files=True,
                key="sip_files",
            )
            strict_sip = st.checkbox(
                "Stop on unmatched SIP data",
                value=False,
                key="strict_sip",
            )
            if sip_files:
                try:
                    inputs = [
                        (file.name, file.getvalue())
                        for file in sip_files
                    ]
                    records = read_multiple_sip_files(
                        excel_files=inputs,
                        logger=build_logger(
                            "sip_preview",
                            [],
                            None,
                        ),
                    )
                    st.caption(f"{len(records)} SIP record(s) found.")
                except Exception as error:
                    st.error(f"SIP preview failed: {error}")

    if run_portfolio:
        with st.expander(
            "Portfolio Top 10 Holdings inputs",
            expanded=True,
        ):
            portfolio_file = st.file_uploader(
                "Upload Portfolio Excel",
                type=["xlsx", "xlsm"],
                key="portfolio_file",
                help=(
                    "The module scans all fund worksheets, finds Instrument "
                    "Type/Issuer Name and % of NAV, and selects the largest "
                    "10 valid holdings for each fund."
                ),
            )
            strict_portfolio = st.checkbox(
                "Stop when a PortfolioTable or fund cannot be matched",
                value=False,
                key="strict_portfolio",
            )

            if portfolio_file:
                try:
                    portfolio_records = read_portfolio_excel(
                        excel_bytes=portfolio_file.getvalue(),
                        logger=build_logger(
                            "portfolio_preview",
                            [],
                            None,
                        ),
                        source_file=portfolio_file.name,
                    )
                    holding_count = sum(
                        len(record.holdings)
                        for record in portfolio_records.values()
                    )
                    st.caption(
                        f"{len(portfolio_records)} portfolio fund record(s) "
                        f"and {holding_count} selected holding row(s) found."
                    )
                    st.dataframe(
                        [
                            {
                                "PowerPoint Fund": (
                                    record.canonical_fund_name
                                ),
                                "Excel Fund": record.excel_fund_name,
                                "Sheet": record.sheet_name,
                                "Top Holdings": len(record.holdings),
                                "Largest Holding": (
                                    record.holdings[0].instrument
                                    if record.holdings
                                    else ""
                                ),
                                "Largest % of NAV": (
                                    format_nav_percent(
                                        record.holdings[0].nav_percent
                                    )
                                    if record.holdings
                                    else ""
                                ),
                            }
                            for record in portfolio_records.values()
                        ],
                        hide_index=True,
                        width="stretch",
                    )
                except Exception as error:
                    st.error(f"Portfolio preview failed: {error}")

    if run_exposure:
        with st.expander(
            "Details of Exposure inputs",
            expanded=True,
        ):
            exposure_file = st.file_uploader(
                "Upload Details of Exposure Excel",
                type=["xlsx"],
                key="exposure_file",
            )
            strict_exposure = st.checkbox(
                "Stop on unmatched exposure data",
                value=False,
                key="strict_exposure",
            )
            if exposure_file:
                try:
                    records = read_details_of_exposure_excel(
                        excel_bytes=exposure_file.getvalue(),
                        logger=build_logger(
                            "exposure_preview",
                            [],
                            None,
                        ),
                        source_file=exposure_file.name,
                    )
                    row_count = sum(
                        len(record.rows)
                        for record in records.values()
                    )
                    st.caption(
                        f"{len(records)} exposure fund record(s) and "
                        f"{row_count} row(s) found."
                    )
                except Exception as error:
                    st.error(
                        f"Details of Exposure preview failed: {error}"
                    )

    if run_ptc:
        with st.expander(
            "Weighted Average Maturity of PTC inputs",
            expanded=True,
        ):
            ptc_file = st.file_uploader(
                "Upload PTC Excel",
                type=["xlsx"],
                key="ptc_file",
                help="PTC data is read from the second worksheet.",
            )
            strict_ptc = st.checkbox(
                "Stop on unmatched PTC data",
                value=False,
                key="strict_ptc",
            )
            if ptc_file:
                try:
                    records = read_ptc_excel(
                        excel_bytes=ptc_file.getvalue(),
                        logger=build_logger(
                            "ptc_preview",
                            [],
                            None,
                        ),
                        source_file=ptc_file.name,
                    )
                    row_count = sum(
                        len(record.rows)
                        for record in records.values()
                    )
                    st.caption(
                        f"{len(records)} PTC fund record(s) and "
                        f"{row_count} security row(s) found."
                    )
                    st.dataframe(
                        [
                            {
                                "PowerPoint Fund": (
                                    record.canonical_fund_name
                                ),
                                "Excel Scheme Name": (
                                    record.excel_fund_name
                                ),
                                "PTC Rows": len(record.rows),
                                "Sheet": record.sheet_name,
                            }
                            for record in records.values()
                        ],
                        hide_index=True,
                        width="stretch",
                    )
                except Exception as error:
                    st.error(f"PTC preview failed: {error}")

    operation_log_box = st.empty()

    if st.button(
        "Apply selected operations",
        type="primary",
        disabled=(
            not st.session_state.working_ppt
            or not selected_operations
        ),
        key="apply_operations",
        width="stretch",
    ):
        errors: list[str] = []
        required_inputs = [
            (run_nav, nav_file, "NAV"),
            (run_aum, aum_file, "AUM & AAUM"),
            (run_expense, expense_files, "Expense Ratio"),
            (run_risk, risk_files, "Risk Measures"),
            (run_market_cap, market_cap_file, "Market Cap"),
            (run_sip, sip_files, "SIP"),
            (
                run_portfolio,
                portfolio_file,
                "Portfolio Top 10 Holdings",
            ),
            (run_exposure, exposure_file, "Details of Exposure"),
            (
                run_ptc,
                ptc_file,
                "Weighted Average Maturity of PTC",
            ),
        ]

        for enabled, value, label in required_inputs:
            if enabled:
                require_file(value, label, errors)

        if errors:
            for error in errors:
                st.error(error)
        else:
            logger = build_logger(
                "selected_operations",
                st.session_state.workflow_logs,
                callback_for(operation_log_box),
            )
            current = st.session_state.working_ppt
            completed: list[str] = []

            try:
                total = len(selected_operations)
                overall_progress = st.progress(
                    0,
                    text=(
                        f"Overall progress: 0% | Completed 0 of "
                        f"{total} operation(s)"
                    ),
                )
                task_progress = st.progress(
                    0,
                    text="Current task: Waiting | 0%",
                )
                progress_status = st.empty()

                def start_task(label: str) -> None:
                    # 10% means input validation and dispatch have completed.
                    # The task remains here while its PowerPoint logic runs.
                    update_operation_progress(
                        overall_progress,
                        task_progress,
                        label,
                        len(completed),
                        total,
                        10,
                        progress_status,
                    )

                def finish_task(label: str) -> None:
                    # Call only after the operation has returned successfully.
                    update_operation_progress(
                        overall_progress,
                        task_progress,
                        label,
                        len(completed),
                        total,
                        100,
                        progress_status,
                    )

                if run_nav:
                    start_task("NAV")
                    current = apply_nav(
                        current_ppt_bytes=current,
                        nav_excel_bytes=nav_file.getvalue(),
                        fund_object=FUND_DETAILS_OBJECT,
                        scheme_details_object=SCHEME_DETAILS_OBJECT,
                        logger=logger,
                        fail_on_overflow=strict_nav,
                    )
                    completed.append("NAV")
                    finish_task("NAV")

                if run_aum:
                    start_task("AUM & AAUM")
                    current = apply_aum_aaum(
                        current_ppt_bytes=current,
                        excel_bytes=aum_file.getvalue(),
                        fund_object=FUND_DETAILS_OBJECT,
                        scheme_details_object=SCHEME_DETAILS_OBJECT,
                        logger=logger,
                    )
                    completed.append("AUM & AAUM")
                    finish_task("AUM & AAUM")

                if run_expense:
                    start_task("Expense Ratio")
                    current = apply_expense_ratio(
                        current_ppt_bytes=current,
                        expense_excel_files=[
                            (file.name, file.getvalue())
                            for file in expense_files
                        ],
                        fund_object=FUND_DETAILS_OBJECT,
                        scheme_details_object=SCHEME_DETAILS_OBJECT,
                        logger=logger,
                        strict=strict_expense,
                    )
                    completed.append("Expense Ratio")
                    finish_task("Expense Ratio")

                if run_risk:
                    start_task("Risk Measures")
                    current = apply_risk_measures(
                        current_ppt_bytes=current,
                        risk_excel_files=[
                            (file.name, file.getvalue())
                            for file in risk_files
                        ],
                        fund_object=FUND_DETAILS_OBJECT,
                        measures_table_object=MEASURES_TABLE_OBJECT,
                        scheme_details_object=SCHEME_DETAILS_OBJECT,
                        logger=logger,
                        strict=strict_risk,
                    )
                    completed.append("Risk Measures")
                    finish_task("Risk Measures")

                if run_market_cap:
                    start_task("Market Cap")
                    current = apply_market_cap(
                        current_ppt_bytes=current,
                        market_cap_excel_bytes=(
                            market_cap_file.getvalue()
                        ),
                        fund_object=FUND_DETAILS_OBJECT,
                        market_cap_table_object=(
                            MARKET_CAP_TABLE_OBJECT
                        ),
                        logger=logger,
                        strict=strict_market,
                        source_file=market_cap_file.name,
                    )
                    completed.append("Market Cap")
                    finish_task("Market Cap")

                if run_sip:
                    start_task("SIP")
                    current = apply_sip(
                        current_ppt_bytes=current,
                        fund_object=FUND_DETAILS_OBJECT,
                        sip_table_object=SIP_TABLE_OBJECT,
                        sip_fund_name_object=SIP_FUND_NAME_OBJECT,
                        sip_performance_date_object=(
                            SIP_PERFORMANCE_DATE_OBJECT
                        ),
                        logger=logger,
                        sip_excel_files=[
                            (file.name, file.getvalue())
                            for file in sip_files
                        ],
                        strict=strict_sip,
                    )
                    completed.append("SIP")
                    finish_task("SIP")

                if run_portfolio:
                    start_task("Portfolio Top 10 Holdings")
                    current = apply_portfolio(
                        current_ppt_bytes=current,
                        portfolio_excel_bytes=(
                            portfolio_file.getvalue()
                        ),
                        fund_object=FUND_DETAILS_OBJECT,
                        portfolio_table_object=PORTFOLIO_TABLE_OBJECT,
                        logger=logger,
                        strict=strict_portfolio,
                        source_file=portfolio_file.name,
                    )
                    completed.append("Portfolio Top 10 Holdings")
                    finish_task("Portfolio Top 10 Holdings")

                if run_exposure:
                    start_task("Details of Exposure")
                    current = apply_details_of_exposure(
                        current_ppt_bytes=current,
                        exposure_excel_bytes=(
                            exposure_file.getvalue()
                        ),
                        fund_object=FUND_DETAILS_OBJECT,
                        exposure_table_object=(
                            DETAILS_OF_EXPOSURE_TABLE_OBJECT
                        ),
                        exposure_box_object=(
                            DETAILS_OF_EXPOSURE_BOX_OBJECT
                        ),
                        exposure_text_bg_object=(
                            DETAILS_EXPOSURE_TEXT_BG_OBJECT
                        ),
                        exposure_icon_object=(
                            DETAILS_EXPOSURE_ICON_OBJECT
                        ),
                        logger=logger,
                        strict=strict_exposure,
                        source_file=exposure_file.name,
                    )
                    completed.append("Details of Exposure")
                    finish_task("Details of Exposure")

                if run_ptc:
                    start_task("Weighted Average Maturity of PTC")
                    current = apply_ptc(
                        current_ppt_bytes=current,
                        ptc_excel_bytes=ptc_file.getvalue(),
                        fund_object=FUND_DETAILS_OBJECT,
                        ptc_table_object=PTC_TABLE_OBJECT,
                        ptc_text_bg_object=PTC_TEXT_BG_OBJECT,
                        ptc_icon_object=PTC_ICON_OBJECT,
                        ptc_table_box_object=PTC_TABLE_BOX_OBJECT,
                        logger=logger,
                        strict=strict_ptc,
                        source_file=ptc_file.name,
                    )
                    completed.append(
                        "Weighted Average Maturity of PTC"
                    )
                    finish_task(
                        "Weighted Average Maturity of PTC"
                    )

                set_working_ppt(
                    current,
                    f"{st.session_state.selected_amc}_updated.pptx",
                )
                for name in completed:
                    add_applied_module(name)

                overall_progress.progress(
                    100,
                    text=(
                        f"Overall progress: 100% | Completed {total} of "
                        f"{total} operation(s)"
                    ),
                )
                task_progress.progress(
                    100,
                    text="Current task: All selected operations | 100%",
                )
                progress_status.success(
                    "All selected operations completed successfully."
                )
                st.success(
                    "Completed successfully: " + ", ".join(completed)
                )

            except Exception as error:
                failed_operation = next(
                    (
                        name
                        for name in selected_operations
                        if name not in completed
                    ),
                    "Unknown operation",
                )
                failure_overall_percent = progress_percent(
                    len(completed),
                    len(selected_operations),
                )
                overall_progress.progress(
                    failure_overall_percent,
                    text=(
                        f"Overall progress stopped at "
                        f"{failure_overall_percent}% | "
                        f"Completed {len(completed)} of "
                        f"{len(selected_operations)} operation(s)"
                    ),
                )
                task_progress.progress(
                    0,
                    text=f"Current task failed: {failed_operation}",
                )
                progress_status.error(
                    f"Failed while processing: {failed_operation}"
                )

                if completed and current:
                    set_working_ppt(
                        current,
                        (
                            f"{st.session_state.selected_amc}_"
                            "partially_updated.pptx"
                        ),
                    )
                    for name in completed:
                        add_applied_module(name)

                st.error(
                    "Workflow failed after "
                    f"{', '.join(completed) or 'no completed operations'}: "
                    f"{error}"
                )


# -----------------------------------------------------------------------------
# Download and logs
# -----------------------------------------------------------------------------

with download_tab:
    st.subheader("Download final outputs")
    st.write(
        "Applied modules:",
        ", ".join(st.session_state.applied_modules) or "None",
    )

    if st.session_state.working_ppt:
        st.download_button(
            "Download current/final PowerPoint",
            st.session_state.working_ppt,
            file_name=FINAL_OUTPUT_NAME,
            mime=(
                "application/vnd.openxmlformats-officedocument."
                "presentationml.presentation"
            ),
            type="primary",
            key="download_final",
            width="stretch",
        )

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        st.download_button(
            "Download complete log",
            logs_to_bytes(st.session_state.workflow_logs),
            file_name=f"fund_ppt_{timestamp}.log",
            mime="text/plain",
            key="download_log",
            width="stretch",
        )
    else:
        st.warning("No working PowerPoint is currently available.")

    with st.expander("Workflow logs", expanded=False):
        st.code(
            "\n".join(st.session_state.workflow_logs)
            or "No logs yet",
            language="text",
        )

    st.divider()
    if st.button(
        "Reset working file and logs",
        key="reset_workflow",
    ):
        for key, value in SESSION_DEFAULTS.items():
            st.session_state[key] = (
                value.copy()
                if isinstance(value, list)
                else value
            )
        st.rerun()
