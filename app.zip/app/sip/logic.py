from __future__ import annotations

import hashlib
import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_GROUP = 6
MSO_FALSE = 0
MSO_TRUE = -1

# Target SIP table width after unavailable source periods are removed.
POINTS_PER_CM = 72.0 / 2.54
SIP_TABLE_WIDTH_CM = 19.5

# Stable fund-by-fund color themes. A fund-name hash chooses one theme, so
# different funds appear in different colors while repeated runs stay stable.
# Each item is: (dark RGB for SIPFundName/borders, light RGB for table header).
SIP_COLOR_PALETTE = (
    ((17, 82, 73), (174, 220, 214)),       # Teal
    ((74, 44, 122), (211, 198, 232)),      # Purple
    ((18, 77, 121), (188, 218, 238)),      # Blue
    ((128, 54, 25), (239, 202, 183)),      # Terracotta
    ((98, 74, 14), (235, 218, 164)),       # Gold / olive
    ((91, 35, 74), (229, 190, 216)),       # Berry
    ((33, 87, 50), (194, 226, 190)),       # Green
    ((111, 55, 23), (231, 199, 172)),      # Brown / amber
)

# Source PowerPoint fund name -> target FundDetails name.
SIP_FUND_NAME_ALIASES: dict[str, str] = {
    "Axis Focused 25 Fund": "Axis Focused Fund",
}

PERIOD_ALIASES = {
    "1": "1",
    "1year": "1",
    "1yearsip": "1",
    "3": "3",
    "3year": "3",
    "3yearsip": "3",
    "5": "5",
    "5year": "5",
    "5yearsip": "5",
    "10": "10",
    "10year": "10",
    "10yearsip": "10",
    "si": "SI",
    "sinceinception": "SI",
    "sinceinceptionsip": "SI",
}

METRIC_ORDER = (
    "investment",
    "market_value",
    "scheme_returns",
    "benchmark_returns",
    "additional_benchmark_returns",
)


@dataclass(frozen=True)
class TextColorStyle:
    color: int | None = None


@dataclass(frozen=True)
class CellColorStyle:
    font_color: int | None
    fill_color: int | None
    border_colors: tuple[int | None, ...]


@dataclass(frozen=True)
class SourceTableColors:
    corner: CellColorStyle | None
    period_headers: dict[str, CellColorStyle]
    metric_labels: dict[str, CellColorStyle]
    values: dict[str, dict[str, CellColorStyle]]


@dataclass(frozen=True)
class SourceSIPBlock:
    source_slide_number: int
    block_number: int
    excel_fund_name: str
    canonical_fund_name: str
    table_values: dict[str, dict[str, str]]
    table_colors: SourceTableColors
    fund_name_color: TextColorStyle
    note_color: TextColorStyle
    performance_date: str
    performance_date_color: TextColorStyle
    note: str


# -----------------------------------------------------------------------------
# Text and name normalization
# -----------------------------------------------------------------------------


def _clean_text(value: object) -> str:
    if value is None:
        return ""
    text = str(value)
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    """Remove SIP plan/option wording while retaining the actual scheme name."""
    text = _clean_text(value)

    # Remove complete trailing Regular/Direct plan and Growth wording first.
    text = re.sub(
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*growth(?:\s+option)?\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    text = re.sub(
        r"\s*-\s*growth(?:\s+option)?\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()

    # Children's Fund qualifiers are not part of target FundDetails.
    text = re.sub(
        r"\s*-\s*(?:compulsory\s+lock-in|no\s+lock-in)(?=\s*-|$)",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()

    # Remove a trailing plan label that remains after qualifier cleanup.
    text = re.sub(
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base = _base_fund_name(value)
    base_key = _text_key(base)
    for source_name, target_name in SIP_FUND_NAME_ALIASES.items():
        if _text_key(source_name) == base_key:
            return target_name
    return base


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _period_key(value: object) -> str | None:
    return PERIOD_ALIASES.get(_text_key(value))


def _metric_key(value: object) -> str | None:
    key = _text_key(value)
    if key in {"totalamountinvested", "amountinvested", "investment"}:
        return "investment"
    if key.startswith("marketvalue"):
        return "market_value"
    if key.startswith("additionalbenchmarkreturns"):
        return "additional_benchmark_returns"
    if key.startswith("benchmarkreturns"):
        return "benchmark_returns"
    if key.startswith("returns"):
        return "scheme_returns"
    return None


# -----------------------------------------------------------------------------
# Safe PowerPoint shape/table access
# -----------------------------------------------------------------------------


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                child_text = _shape_text(shape.GroupItems.Item(index))
                if child_text:
                    parts.append(child_text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    try:
                        cell_shape = table.Cell(row, column).Shape
                    except Exception:
                        continue
                    if cell_shape.HasTextFrame and cell_shape.TextFrame.HasText:
                        parts.append(cell_shape.TextFrame.TextRange.Text)
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""
    return " ".join(_clean_text(part) for part in parts if part).strip()


def _get_cell_shape(table, row: int, column: int):
    try:
        return table.Cell(row, column).Shape
    except Exception:
        return None


def _cell_text(table, row: int, column: int) -> str:
    shape = _get_cell_shape(table, row, column)
    if shape is None or not shape.HasTextFrame:
        return ""
    return _clean_text(shape.TextFrame.TextRange.Text)


def _safe_property(getter):
    try:
        return getter()
    except Exception:
        return None


def _capture_text_color(shape) -> TextColorStyle:
    if shape is None or not shape.HasTextFrame:
        return TextColorStyle()
    return TextColorStyle(
        color=_safe_property(
            lambda: int(shape.TextFrame.TextRange.Font.Color.RGB)
        )
    )


def _capture_cell_color(table, row: int, column: int) -> CellColorStyle | None:
    try:
        cell = table.Cell(row, column)
        shape = cell.Shape
    except Exception:
        return None

    border_colors: list[int | None] = []
    for border_index in range(1, 7):
        try:
            border = cell.Borders.Item(border_index)
            border_colors.append(int(border.ForeColor.RGB))
        except Exception:
            border_colors.append(None)

    return CellColorStyle(
        font_color=_safe_property(
            lambda: int(shape.TextFrame.TextRange.Font.Color.RGB)
        ),
        fill_color=_safe_property(lambda: int(shape.Fill.ForeColor.RGB)),
        border_colors=tuple(border_colors),
    )


def _apply_text_color(shape, style: TextColorStyle) -> None:
    if shape is None or not shape.HasTextFrame or style.color is None:
        return
    try:
        shape.TextFrame.TextRange.Font.Color.RGB = style.color
    except Exception:
        pass


def _apply_cell_color(
    table,
    row: int,
    column: int,
    style: CellColorStyle | None,
) -> None:
    if style is None:
        return
    try:
        cell = table.Cell(row, column)
        shape = cell.Shape
    except Exception:
        return

    if style.font_color is not None:
        try:
            shape.TextFrame.TextRange.Font.Color.RGB = style.font_color
        except Exception:
            pass

    if style.fill_color is not None:
        try:
            shape.Fill.ForeColor.RGB = style.fill_color
        except Exception:
            pass

    for border_index, color in enumerate(style.border_colors, start=1):
        if color is None:
            continue
        try:
            cell.Borders.Item(border_index).ForeColor.RGB = color
        except Exception:
            pass


def _capture_source_table_colors(
    table,
    period_columns: dict[str, int],
    metric_rows: dict[str, int],
) -> SourceTableColors:
    header_row = min(
        (
            row
            for row in range(1, table.Rows.Count + 1)
            if any(
                _period_key(_cell_text(table, row, column))
                for column in range(1, table.Columns.Count + 1)
            )
        ),
        default=1,
    )
    label_column = min(
        (
            column
            for column in range(1, table.Columns.Count + 1)
            if any(
                _metric_key(_cell_text(table, row, column))
                for row in range(1, table.Rows.Count + 1)
            )
        ),
        default=1,
    )

    return SourceTableColors(
        corner=_capture_cell_color(table, header_row, label_column),
        period_headers={
            period: color
            for period, column in period_columns.items()
            if (
                color := _capture_cell_color(
                    table,
                    header_row,
                    column,
                )
            ) is not None
        },
        metric_labels={
            metric: color
            for metric, row in metric_rows.items()
            if (
                color := _capture_cell_color(
                    table,
                    row,
                    label_column,
                )
            ) is not None
        },
        values={
            period: {
                metric: color
                for metric in METRIC_ORDER
                if (
                    color := _capture_cell_color(
                        table,
                        metric_rows[metric],
                        column,
                    )
                ) is not None
            }
            for period, column in period_columns.items()
        },
    )


def _replace_text_preserve_format(shape, new_text: str) -> None:
    if not shape.HasTextFrame:
        raise ValueError("The target shape does not support text.")
    text_range = shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")
    if old_text:
        text_range.Characters(1, len(old_text)).Text = str(new_text)
    else:
        text_range.Text = str(new_text)


def _find_named_shape(slide, object_name: str):
    return find_shape_recursive(slide.Shapes, object_name)


def _find_numbered_shape(slide, prefix: str, number: int):
    """Find FundName3/FundData3/FundNote3 ignoring punctuation and spaces."""
    wanted = _text_key(f"{prefix}{number}")
    for index in range(1, slide.Shapes.Count + 1):
        try:
            shape = slide.Shapes.Item(index)
            shape_name = str(shape.Name)
        except Exception:
            continue
        if _text_key(shape_name) == wanted:
            return shape
    return None


def _numbered_fund_blocks(slide) -> list[int]:
    numbers: set[int] = set()
    for index in range(1, slide.Shapes.Count + 1):
        try:
            name = str(slide.Shapes.Item(index).Name)
        except Exception:
            continue
        match = re.fullmatch(
            r"fund\s*name\s*(\d+)",
            name.strip(),
            flags=re.IGNORECASE,
        )
        if match:
            numbers.add(int(match.group(1)))
    return sorted(numbers)


# -----------------------------------------------------------------------------
# Source PPT extraction
# -----------------------------------------------------------------------------


def _read_source_table(
    table,
    fund_name: str,
) -> tuple[dict[str, dict[str, str]], SourceTableColors]:
    """Read source values and semantic colors from FundDataN."""
    period_columns: dict[str, int] = {}
    metric_rows: dict[str, int] = {}

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            text = _cell_text(table, row, column)
            period = _period_key(text)
            if period:
                period_columns[period] = column
            metric = _metric_key(text)
            if metric:
                metric_rows[metric] = row

    missing_metrics = set(METRIC_ORDER) - metric_rows.keys()
    if not period_columns or missing_metrics:
        raise ValueError(
            f"Source SIP table for '{fund_name}' could not be mapped. "
            f"Periods={sorted(period_columns)}; "
            f"missing metrics={sorted(missing_metrics)}."
        )

    values: dict[str, dict[str, str]] = {}
    for period, column in period_columns.items():
        values[period] = {
            metric: _cell_text(table, metric_rows[metric], column)
            for metric in METRIC_ORDER
        }
    colors = _capture_source_table_colors(
        table,
        period_columns,
        metric_rows,
    )
    return values, colors


def _source_performance_date(slide) -> tuple[str, TextColorStyle]:
    """Return the complete target heading, not only the parenthesized date."""
    header = _find_named_shape(slide, "SIPHeader")
    if header is None:
        return "", TextColorStyle()

    text = _shape_text(header)
    match = re.search(
        r"\(?\s*as\s+on\s+[^\)]+\)?",
        text,
        flags=re.IGNORECASE,
    )
    if not match:
        return "", _capture_text_color(header)

    date_text = _clean_text(match.group(0)).strip()
    if not date_text.startswith("("):
        date_text = "(" + date_text
    if not date_text.endswith(")"):
        date_text = date_text + ")"

    return (
        f"SIP Performance {date_text}",
        _capture_text_color(header),
    )


def _build_source_index(source_presentation, logger) -> dict[str, SourceSIPBlock]:
    """Index every FundNameN/FundDataN/FundNoteN block in the source PPT."""
    records: dict[str, SourceSIPBlock] = {}

    for slide_number in range(1, source_presentation.Slides.Count + 1):
        pythoncom.PumpWaitingMessages()
        slide = source_presentation.Slides.Item(slide_number)
        performance_date, performance_date_color = (
            _source_performance_date(slide)
        )
        block_numbers = _numbered_fund_blocks(slide)

        for block_number in block_numbers:
            fund_shape = _find_numbered_shape(slide, "FundName", block_number)
            data_shape = _find_numbered_shape(slide, "FundData", block_number)
            note_shape = _find_numbered_shape(slide, "FundNote", block_number)

            if fund_shape is None or data_shape is None:
                logger.warning(
                    "SIP_SOURCE_BLOCK_SKIPPED | slide=%s | block=%s | "
                    "fund_found=%s | data_found=%s",
                    slide_number,
                    block_number,
                    fund_shape is not None,
                    data_shape is not None,
                )
                continue
            if not data_shape.HasTable:
                logger.warning(
                    "SIP_SOURCE_BLOCK_SKIPPED | slide=%s | block=%s | "
                    "reason=FundData is not a table",
                    slide_number,
                    block_number,
                )
                continue

            source_fund_name = _shape_text(fund_shape)
            canonical_name = _canonical_fund_name(source_fund_name)
            key = _fund_key(source_fund_name)
            if not key:
                continue

            table_values, table_colors = _read_source_table(
                data_shape.Table,
                source_fund_name,
            )
            note = _shape_text(note_shape) if note_shape is not None else ""

            record = SourceSIPBlock(
                source_slide_number=slide_number,
                block_number=block_number,
                excel_fund_name=source_fund_name,
                canonical_fund_name=canonical_name,
                table_values=table_values,
                table_colors=table_colors,
                fund_name_color=_capture_text_color(fund_shape),
                note_color=_capture_text_color(note_shape),
                performance_date=performance_date,
                performance_date_color=performance_date_color,
                note=note,
            )

            if key in records:
                logger.warning(
                    "SIP_SOURCE_DUPLICATE | fund=%s | retained_slide=%s | "
                    "ignored_slide=%s",
                    canonical_name,
                    records[key].source_slide_number,
                    slide_number,
                )
                continue

            records[key] = record
            logger.info(
                "SIP_SOURCE_BLOCK_FOUND | slide=%s | block=%s | "
                "source_fund=%s | canonical=%s | periods=%s",
                slide_number,
                block_number,
                source_fund_name,
                canonical_name,
                ",".join(record.table_values),
            )

    if not records:
        raise ValueError(
            "No FundNameN/FundDataN SIP blocks were found in the source "
            "PowerPoint. Expected objects such as FundName1, FundData1, and "
            "optionally FundNote1."
        )

    logger.info("SIP_SOURCE_INDEX_COMPLETE | funds=%s", len(records))
    return records


def _rgb_to_office(rgb: tuple[int, int, int]) -> int:
    """Convert RGB to the integer format used by Office COM."""
    red, green, blue = rgb
    return red + (green << 8) + (blue << 16)


def _darken(
    rgb: tuple[int, int, int],
    factor: float = 0.72,
) -> tuple[int, int, int]:
    return tuple(
        max(0, min(255, round(component * factor)))
        for component in rgb
    )


def _fund_theme(
    fund_name: str,
) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    """Choose a stable pseudo-random color theme from the fund name."""
    digest = hashlib.sha256(_fund_key(fund_name).encode("utf-8")).digest()
    return SIP_COLOR_PALETTE[digest[0] % len(SIP_COLOR_PALETTE)]


def _set_shape_line_color(shape, rgb: tuple[int, int, int]) -> None:
    try:
        shape.Line.ForeColor.RGB = _rgb_to_office(rgb)
    except Exception:
        pass


def _apply_random_sip_fund_name_colors(
    shape,
    dark_rgb: tuple[int, int, int],
) -> None:
    """Recolor SIPFundName without changing its font or geometry."""
    if shape is None:
        return
    try:
        shape.Fill.ForeColor.RGB = _rgb_to_office(dark_rgb)
    except Exception:
        pass
    _set_shape_line_color(shape, _darken(dark_rgb, 0.72))
    try:
        shape.TextFrame.TextRange.Font.Color.RGB = _rgb_to_office(
            (255, 255, 255)
        )
    except Exception:
        pass


def _apply_random_sip_table_colors(
    shape,
    dark_rgb: tuple[int, int, int],
    light_rgb: tuple[int, int, int],
) -> None:
    """
    Apply a dark fund heading, light table header, and white table body.

    SIPFundName is handled separately with dark_rgb. The table header row uses
    light_rgb with matching dark text. Every non-header cell remains white. Font family,
    font size, bold, italic, underline, alignment, dimensions,
    margins, border weight, and border style remain unchanged.
    """
    if shape is None or not shape.HasTable:
        return

    table = shape.Table
    dark_office = _rgb_to_office(dark_rgb)
    light_office = _rgb_to_office(light_rgb)
    border_office = _rgb_to_office(_darken(dark_rgb, 0.78))
    white_office = _rgb_to_office((255, 255, 255))
    body_text_office = _rgb_to_office((28, 28, 28))

    period_columns, metric_rows = _map_target_table(shape)
    header_rows: set[int] = set()
    for row in range(1, table.Rows.Count + 1):
        if any(
            _period_key(_cell_text(table, row, column))
            for column in range(1, table.Columns.Count + 1)
        ):
            header_rows.add(row)

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                cell = table.Cell(row, column)
                cell_shape = cell.Shape
            except Exception:
                continue

            is_header = row in header_rows
            is_metric_label = row in metric_rows.values() and column == 1

            if is_header:
                # The table column-heading row uses the lighter theme fill and
                # the matching dark theme text for clear, readable contrast.
                # SIPFundName remains dark with white text.
                try:
                    cell_shape.Fill.Visible = MSO_TRUE
                    cell_shape.Fill.ForeColor.RGB = light_office
                    cell_shape.TextFrame.TextRange.Font.Color.RGB = dark_office
                except Exception:
                    pass
            else:
                # All data rows and the note/disclosure row remain white.
                # This includes the first label column and all value columns.
                try:
                    cell_shape.Fill.Visible = MSO_TRUE
                    cell_shape.Fill.ForeColor.RGB = white_office
                    cell_shape.TextFrame.TextRange.Font.Color.RGB = (
                        body_text_office
                    )
                except Exception:
                    pass

            for border_index in range(1, 7):
                try:
                    cell.Borders.Item(border_index).ForeColor.RGB = (
                        border_office
                    )
                except Exception:
                    pass

    _set_shape_line_color(shape, _darken(dark_rgb, 0.78))


# -----------------------------------------------------------------------------
# Target SIP table update
# -----------------------------------------------------------------------------


def _map_target_table(shape) -> tuple[dict[str, int], dict[str, int]]:
    if not shape.HasTable:
        raise ValueError("The target SIP Table object is not a table.")

    table = shape.Table
    period_columns: dict[str, int] = {}
    metric_rows: dict[str, int] = {}

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            text = _cell_text(table, row, column)
            period = _period_key(text)
            if period:
                period_columns[period] = column
            metric = _metric_key(text)
            if metric:
                metric_rows[metric] = row

    return period_columns, metric_rows


def _delete_unavailable_period_columns(
    target_table_shape,
    available_periods: set[str],
    logger,
    slide_number: int,
    fund_name: str,
) -> int:
    period_columns, _ = _map_target_table(target_table_shape)
    delete_items = [
        (column, period)
        for period, column in period_columns.items()
        if period not in available_periods
    ]

    deleted = 0
    for column, period in sorted(delete_items, reverse=True):
        target_table_shape.Table.Columns.Item(column).Delete()
        deleted += 1
        logger.info(
            "SIP_TARGET_PERIOD_DELETED | slide=%s | fund=%s | "
            "period=%s | column=%s",
            slide_number,
            fund_name,
            period,
            column,
        )
    return deleted


def _apply_source_table_colors(
    target_table_shape,
    record: SourceSIPBlock,
) -> None:
    period_columns, metric_rows = _map_target_table(target_table_shape)
    table = target_table_shape.Table

    header_row = min(
        (
            row
            for row in range(1, table.Rows.Count + 1)
            if any(_period_key(_cell_text(table, row, column)) for column in range(1, table.Columns.Count + 1))
        ),
        default=1,
    )
    label_column = min(
        (
            column
            for column in range(1, table.Columns.Count + 1)
            if any(_metric_key(_cell_text(table, row, column)) for row in range(1, table.Rows.Count + 1))
        ),
        default=1,
    )

    _apply_cell_color(table, header_row, label_column, record.table_colors.corner)
    for period, column in period_columns.items():
        _apply_cell_color(
            table,
            header_row,
            column,
            record.table_colors.period_headers.get(period),
        )
    for metric, row in metric_rows.items():
        _apply_cell_color(
            table,
            row,
            label_column,
            record.table_colors.metric_labels.get(metric),
        )
    for period, column in period_columns.items():
        for metric, row in metric_rows.items():
            _apply_cell_color(
                table,
                row,
                column,
                record.table_colors.values.get(period, {}).get(metric),
            )


def _update_target_table(
    target_table_shape,
    record: SourceSIPBlock,
    logger,
    slide_number: int,
) -> int:
    available_periods = set(record.table_values)
    changed = _delete_unavailable_period_columns(
        target_table_shape,
        available_periods,
        logger,
        slide_number,
        record.canonical_fund_name,
    )

    try:
        target_table_shape.Width = SIP_TABLE_WIDTH_CM * POINTS_PER_CM
    except Exception:
        pass

    period_columns, metric_rows = _map_target_table(target_table_shape)
    missing_periods = available_periods - period_columns.keys()
    missing_metrics = set(METRIC_ORDER) - metric_rows.keys()
    if missing_periods or missing_metrics:
        raise ValueError(
            f"Target SIP Table on slide {slide_number} cannot accept source "
            f"data for '{record.canonical_fund_name}'. "
            f"Missing periods={sorted(missing_periods)}; "
            f"missing metrics={sorted(missing_metrics)}."
        )

    for period in ("SI", "10", "5", "3", "1"):
        if period not in record.table_values:
            continue
        column = period_columns[period]
        values = record.table_values[period]
        for metric in METRIC_ORDER:
            value_shape = _get_cell_shape(
                target_table_shape.Table,
                metric_rows[metric],
                column,
            )
            if value_shape is None:
                raise ValueError(
                    f"Target SIP cell is inaccessible for period {period}, "
                    f"metric {metric}, slide {slide_number}."
                )
            _replace_text_preserve_format(value_shape, values[metric])
            changed += 1

    _apply_source_table_colors(target_table_shape, record)
    return changed


def _update_target_note(
    target_table_shape,
    note: str,
    note_color: TextColorStyle,
) -> bool:
    if not note or not target_table_shape.HasTable:
        return False
    table = target_table_shape.Table
    last_row = table.Rows.Count
    note_shape = _get_cell_shape(table, last_row, 1)
    if note_shape is None or not note_shape.HasTextFrame:
        return False
    _replace_text_preserve_format(note_shape, note)
    _apply_text_color(note_shape, note_color)
    return True


def _delete_target_sip_objects(
    slide,
    object_names: tuple[str, ...],
    logger,
) -> int:
    deleted = 0
    for object_name in object_names:
        shape = _find_named_shape(slide, object_name)
        if shape is None:
            continue
        shape.Delete()
        deleted += 1
        logger.info(
            "SIP_TARGET_OBJECT_DELETED | slide=%s | object=%s",
            slide.SlideIndex,
            object_name,
        )
    return deleted


# -----------------------------------------------------------------------------
# COM utilities and public operation
# -----------------------------------------------------------------------------


def _retry_com(name: str, operation, logger, attempts: int = 6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(
                error,
                "hresult",
                error.args[0]
                if error.args and isinstance(error.args[0], int)
                else None,
            )
            if code not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "SIP_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def apply_sip(
    current_ppt_bytes: bytes,
    fund_object: str,
    sip_table_object: str,
    sip_fund_name_object: str,
    sip_performance_date_object: str,
    logger,
    source_ppt_bytes: bytes | None = None,
    strict: bool = False,
    delete_when_source_missing: bool = False,
    # Legacy parameters retained only for a clear migration error.
    sip_excel_files=None,
    sip_excel_bytes=None,
    sheet_name=None,
) -> bytes:
    """
    Copy SIP data from a multi-fund source PPT into a target factsheet PPT.

    Source objects are numbered blocks: FundNameN, FundDataN, and FundNoteN.
    Target slides are matched through FundDetails. Values are written into the
    existing target SIP Table, preserving its formatting and coordinates.
    """
    del sheet_name, delete_when_source_missing
    if source_ppt_bytes is None:
        if sip_excel_files is not None or sip_excel_bytes is not None:
            raise ValueError(
                "The SIP workflow now requires a source PowerPoint instead of "
                "Excel. Pass source_ppt_bytes to apply_sip()."
            )
        raise ValueError("Upload a source SIP PowerPoint file.")
    if not current_ppt_bytes:
        raise ValueError("The target PowerPoint is empty.")
    if not source_ppt_bytes:
        raise ValueError("The source SIP PowerPoint is empty.")

    target_object_names = (
        sip_table_object,
        sip_fund_name_object,
        sip_performance_date_object,
    )

    pythoncom.CoInitialize()
    powerpoint = source_presentation = target_presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "sip_source.pptx"
            target_path = temp / "sip_target.pptx"
            output_path = temp / "sip_output.pptx"
            source_path.write_bytes(source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.DisplayAlerts = False

            source_presentation = _retry_com(
                "open SIP source presentation",
                lambda: powerpoint.Presentations.Open(
                    str(source_path.resolve()),
                    True,
                    False,
                    False,
                ),
                logger,
            )
            target_presentation = _retry_com(
                "open SIP target presentation",
                lambda: powerpoint.Presentations.Open(
                    str(target_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            source_index = _build_source_index(source_presentation, logger)

            matched = unmatched = slides_updated = 0
            values_changed = objects_deleted = 0

            for slide_number in range(1, target_presentation.Slides.Count + 1):
                pythoncom.PumpWaitingMessages()
                slide = target_presentation.Slides.Item(slide_number)
                target_table = _find_named_shape(slide, sip_table_object)
                target_sip_name = _find_named_shape(
                    slide,
                    sip_fund_name_object,
                )
                target_sip_date = _find_named_shape(
                    slide,
                    sip_performance_date_object,
                )

                # A partial SIP section is invalid. If SIP Table is absent but
                # either companion object remains, delete all SIP objects.
                if target_table is None:
                    if target_sip_name is not None or target_sip_date is not None:
                        objects_deleted += _delete_target_sip_objects(
                            slide,
                            target_object_names,
                            logger,
                        )
                        logger.info(
                            "SIP_TARGET_TABLE_ABSENT | slide=%s | "
                            "action=sip_objects_deleted",
                            slide_number,
                        )
                    continue

                fund_shape = _find_named_shape(slide, fund_object)
                if fund_shape is None:
                    if strict:
                        raise ValueError(
                            f"'{fund_object}' is missing on target SIP slide "
                            f"{slide_number}."
                        )
                    logger.warning(
                        "SIP_TARGET_SKIPPED | slide=%s | reason=no %s",
                        slide_number,
                        fund_object,
                    )
                    continue

                target_fund = _shape_text(fund_shape)
                record = source_index.get(_fund_key(target_fund))
                if record is None:
                    unmatched += 1
                    deleted_now = _delete_target_sip_objects(
                        slide,
                        target_object_names,
                        logger,
                    )
                    objects_deleted += deleted_now
                    logger.warning(
                        "SIP_SOURCE_NOT_MATCHED | slide=%s | fund=%s | "
                        "action=sip_objects_deleted | deleted=%s",
                        slide_number,
                        target_fund,
                        deleted_now,
                    )
                    continue

                matched += 1
                changes = _update_target_table(
                    target_table,
                    record,
                    logger,
                    slide_number,
                )
                dark_rgb, light_rgb = _fund_theme(
                    record.canonical_fund_name
                )
                _apply_random_sip_table_colors(
                    target_table,
                    dark_rgb,
                    light_rgb,
                )

                target_fund_name = _find_named_shape(
                    slide,
                    sip_fund_name_object,
                )
                if target_fund_name is not None:
                    _replace_text_preserve_format(
                        target_fund_name,
                        record.excel_fund_name,
                    )
                    _apply_text_color(
                        target_fund_name,
                        record.fund_name_color,
                    )
                    _apply_random_sip_fund_name_colors(
                        target_fund_name,
                        dark_rgb,
                    )
                    changes += 1
                elif strict:
                    raise ValueError(
                        f"'{sip_fund_name_object}' is missing on target slide "
                        f"{slide_number}."
                    )

                target_date = _find_named_shape(
                    slide,
                    sip_performance_date_object,
                )
                if target_date is not None and record.performance_date:
                    _replace_text_preserve_format(
                        target_date,
                        record.performance_date,
                    )
                    _apply_text_color(
                        target_date,
                        record.performance_date_color,
                    )
                    changes += 1
                elif strict and target_date is None:
                    raise ValueError(
                        f"'{sip_performance_date_object}' is missing on target "
                        f"slide {slide_number}."
                    )

                if _update_target_note(
                    target_table,
                    record.note,
                    record.note_color,
                ):
                    changes += 1

                slides_updated += 1
                values_changed += changes
                logger.info(
                    "SIP_UPDATED | target_slide=%s | source_slide=%s | "
                    "source_block=%s | fund=%s | changes=%s | "
                    "theme_dark=%s | theme_light=%s",
                    slide_number,
                    record.source_slide_number,
                    record.block_number,
                    record.canonical_fund_name,
                    changes,
                    dark_rgb,
                    light_rgb,
                )

            _retry_com(
                "save SIP target presentation",
                lambda: target_presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            target_presentation.Close()
            target_presentation = None
            source_presentation.Close()
            source_presentation = None

            output = output_path.read_bytes()
            if not output:
                raise RuntimeError("The generated SIP PowerPoint is empty.")

            logger.info(
                "SIP_COMPLETE | source_funds=%s | matched=%s | "
                "unmatched=%s | slides_updated=%s | changes=%s | "
                "objects_deleted=%s | bytes=%s",
                len(source_index),
                matched,
                unmatched,
                slides_updated,
                values_changed,
                objects_deleted,
                len(output),
            )
            return output

    except Exception:
        logger.exception("SIP_FAILED")
        raise

    finally:
        for presentation in (target_presentation, source_presentation):
            if presentation is not None:
                try:
                    presentation.Close()
                except Exception:
                    pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
