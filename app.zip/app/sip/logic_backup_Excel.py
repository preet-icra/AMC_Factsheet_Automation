from __future__ import annotations

import hashlib
import io
import re
import tempfile
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
POINTS_PER_CM = 72.0 / 2.54
SIP_TABLE_WIDTH_CM = 19.5
DEFAULT_SIP_SHEET_INDEX = 1  # Second worksheet, zero-based.

PERIOD_ALIASES = {
    "1": "1",
    "1year": "1",
    "1yearsip": "1",
    "3": "3",
    "3year": "3",
    "3yearsip": "3",
    "5": "5",
    "5year": "5",
    "5yearsip": "5",
    "10": "10",
    "10year": "10",
    "10yearsip": "10",
    "si": "SI",
    "sinceinception": "SI",
    "sinceinceptionsip": "SI",
}

# Excel/PPT naming differences. Left side is Excel, right side is FundDetails.
SIP_FUND_NAME_ALIASES = {
    "Axis Focused 25 Fund": "Axis Focused Fund",
}

# A stable palette used fund-by-fund. Each tuple contains:
# (dark RGB for SIPFundName and borders, medium-light RGB for filled table cells).
SIP_COLOR_PALETTE = (
    ((17, 82, 73), (93, 174, 166)),    # Green / teal
    ((74, 44, 122), (156, 130, 196)),  # Purple
    ((18, 77, 121), (99, 164, 207)),   # Blue
    ((128, 54, 25), (213, 139, 103)),  # Terracotta
    ((98, 74, 14), (204, 174, 83)),    # Gold / olive
    ((91, 35, 74), (190, 112, 163)),   # Berry
)

MsoFalse = 0


PPT_ROW_ALIASES = {
    "totalamountinvested": "investment",
    "investment": "investment",
    "marketvalue": "market_value",
    "marketvalueasonjune302026": "market_value",
    "returns": "scheme_returns",
    "returnsannualised": "scheme_returns",
    "returnsannualized": "scheme_returns",
    "benchmarkreturns": "benchmark_returns",
    "benchmarkreturnsannualised": "benchmark_returns",
    "benchmarkreturnsannualized": "benchmark_returns",
    "additionalbenchmarkreturns": "additional_benchmark_returns",
    "additionalbenchmarkreturnsannualised": "additional_benchmark_returns",
    "additionalbenchmarkreturnsannualized": "additional_benchmark_returns",
}


@dataclass(frozen=True)
class SIPPeriodValues:
    investment: object
    market_value: object
    scheme_returns: object
    benchmark_returns: object
    additional_benchmark_returns: object


@dataclass(frozen=True)
class SIPRecord:
    excel_fund_name: str
    canonical_fund_name: str
    periods: dict[str, SIPPeriodValues]
    sheet_name: str
    fund_row: int
    note: str = ""


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    """Create a numeric-safe comparison key without project normalize()."""
    if value is None:
        return ""

    # Excel year headers may be int, float, or text. Convert 1.0 to 1.
    if isinstance(value, bool):
        text = str(value)
    elif isinstance(value, int):
        text = str(value)
    elif isinstance(value, float) and value.is_integer():
        text = str(int(value))
    else:
        text = _clean_text(value)

    text = text.casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    """Remove Excel plan/option suffixes for matching with FundDetails."""
    text = _clean_text(value)
    patterns = (
        r"\s*-\s*regular\s+plan.*$",
        r"\s*-\s*direct\s+plan.*$",
        r"\s*-\s*growth\s+option.*$",
        r"\s*-\s*growth.*$",
        r"\s*-\s*compulsory\s+lock-in.*$",
        r"\s*-\s*no\s+lock-in.*$",
    )
    for pattern in patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text


def _fund_key(value: object) -> str:
    base_name = _base_fund_name(value)
    alias_lookup = {
        _text_key(excel_name): ppt_name
        for excel_name, ppt_name in SIP_FUND_NAME_ALIASES.items()
    }
    mapped_name = alias_lookup.get(_text_key(base_name), base_name)
    return _text_key(mapped_name)


def _period_key(value: object) -> str | None:
    return PERIOD_ALIASES.get(_text_key(value))


def _is_na(value: object) -> bool:
    return value is None or _clean_text(value).casefold() in {"", "na", "n/a", "-"}


def _excel_value(value: object) -> object:
    return None if _is_na(value) else value


def _find_sip_blocks(worksheet, logger) -> dict[str, SIPRecord]:
    records: dict[str, SIPRecord] = {}

    for header_row in range(1, worksheet.max_row + 1):
        period_columns: dict[str, int] = {}
        for column in range(2, min(worksheet.max_column, 15) + 1):
            period = _period_key(worksheet.cell(header_row, column).value)
            if period:
                period_columns[period] = column

        if not {"1", "3", "5", "10", "SI"}.issubset(period_columns):
            continue

        fund_row = None
        fund_name = ""
        for candidate_row in range(header_row - 1, max(0, header_row - 5), -1):
            candidate = _clean_text(worksheet.cell(candidate_row, 1).value)
            if candidate and "fund" in candidate.casefold():
                fund_row = candidate_row
                fund_name = candidate
                break

        if fund_row is None:
            continue

        row_types: list[tuple[str, int]] = []
        for row in range(header_row + 1, min(header_row + 9, worksheet.max_row) + 1):
            label = _text_key(worksheet.cell(row, 1).value)
            if label == "investment":
                row_types.append(("investment", row))
            elif label == "marketvalue":
                row_types.append(("market_value", row))
            elif label == "returns":
                row_types.append(("returns", row))

        investment_rows = [row for kind, row in row_types if kind == "investment"]
        market_rows = [row for kind, row in row_types if kind == "market_value"]
        return_rows = [row for kind, row in row_types if kind == "returns"]

        if not investment_rows or not market_rows or len(return_rows) < 3:
            logger.warning(
                "SIP_BLOCK_SKIPPED | sheet=%s | fund=%s | header_row=%s | "
                "reason=required rows missing",
                worksheet.title,
                fund_name,
                header_row,
            )
            continue

        periods: dict[str, SIPPeriodValues] = {}
        for period in ("1", "3", "5", "10", "SI"):
            column = period_columns[period]
            periods[period] = SIPPeriodValues(
                investment=_excel_value(
                    worksheet.cell(investment_rows[0], column).value
                ),
                market_value=_excel_value(
                    worksheet.cell(market_rows[0], column).value
                ),
                scheme_returns=_excel_value(
                    worksheet.cell(return_rows[0], column).value
                ),
                benchmark_returns=_excel_value(
                    worksheet.cell(return_rows[1], column).value
                ),
                additional_benchmark_returns=_excel_value(
                    worksheet.cell(return_rows[2], column).value
                ),
            )

        key = _fund_key(fund_name)
        record = SIPRecord(
            excel_fund_name=fund_name,
            canonical_fund_name=_base_fund_name(fund_name),
            periods=periods,
            sheet_name=worksheet.title,
            fund_row=fund_row,
        )

        # Prefer a base/regular record over a direct-plan record when several
        # Excel blocks normalize to the same PowerPoint FundDetails name.
        existing = records.get(key)
        is_direct = "direct plan" in fund_name.casefold()
        existing_is_direct = (
            existing is not None
            and "direct plan" in existing.excel_fund_name.casefold()
        )
        if existing is None or (existing_is_direct and not is_direct):
            records[key] = record

    return records


def read_sip_excel(
    excel_bytes: bytes,
    logger,
    sheet_name: str | None = None,
) -> dict[str, SIPRecord]:
    """Read SIP data from the workbook's second tab, or a named tab."""
    logger.info("SIP_FILE_START | bytes=%s", len(excel_bytes))
    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )

    if sheet_name:
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"SIP sheet '{sheet_name}' was not found.")
        worksheet = workbook[sheet_name]
    else:
        if len(workbook.worksheets) < 2:
            raise ValueError(
                "The SIP workbook must contain at least two worksheets."
            )
        worksheet = workbook.worksheets[DEFAULT_SIP_SHEET_INDEX]

    records = _find_sip_blocks(worksheet, logger)
    if not records:
        sample_headers = []
        for row in range(1, min(worksheet.max_row, 40) + 1):
            values = [
                worksheet.cell(row, column).value
                for column in range(1, min(worksheet.max_column, 7) + 1)
            ]
            if any(value not in (None, "") for value in values):
                sample_headers.append(f"row {row}: {values!r}")
            if len(sample_headers) >= 8:
                break

        raise ValueError(
            f"No SIP records were found in worksheet '{worksheet.title}'. "
            "Expected a period header containing 1, 3, 5, 10 and SI, "
            "followed by Investment, Market Value and three Returns rows. "
            "Detected sample rows: " + " | ".join(sample_headers)
        )

    logger.info(
        "SIP_FILE_COMPLETE | sheet=%s | records=%s",
        worksheet.title,
        len(records),
    )
    for record in records.values():
        logger.info(
            "SIP_FUND_FOUND | fund=%s | canonical=%s | row=%s",
            record.excel_fund_name,
            record.canonical_fund_name,
            record.fund_row,
        )
    return records


def _read_notes_from_workbook(workbook, logger) -> dict[str, str]:
    """Read fund-specific notes from any sheet: column A fund, column B note."""
    notes: dict[str, str] = {}
    for worksheet in workbook.worksheets:
        for row in range(1, worksheet.max_row + 1):
            fund_name = _clean_text(worksheet.cell(row, 1).value)
            note = _clean_text(worksheet.cell(row, 2).value)
            if not fund_name or not note or "fund" not in fund_name.casefold():
                continue
            # Ignore dates/codes beside fund headings in the SIP-data sheet.
            if len(note) < 20 and not any(ch in note for ch in (".", "^", ":")):
                continue
            notes[_fund_key(fund_name)] = note
            logger.info(
                "SIP_NOTE_FOUND | sheet=%s | row=%s | fund=%s",
                worksheet.title,
                row,
                fund_name,
            )
    return notes


def read_multiple_sip_files(
    excel_files: list[tuple[str, bytes]],
    logger,
) -> dict[str, SIPRecord]:
    """Combine SIP records and fund notes from multiple XLSX files."""
    if not excel_files:
        raise ValueError("Upload at least one SIP Excel file.")

    records: dict[str, SIPRecord] = {}
    notes: dict[str, str] = {}

    for file_name, excel_bytes in excel_files:
        workbook = load_workbook(
            io.BytesIO(excel_bytes),
            data_only=True,
            read_only=False,
        )
        notes.update(_read_notes_from_workbook(workbook, logger))

        if len(workbook.worksheets) >= 2:
            worksheet = workbook.worksheets[DEFAULT_SIP_SHEET_INDEX]
            file_records = _find_sip_blocks(worksheet, logger)
            for key, record in file_records.items():
                # Later files may supplement records, but avoid silently
                # replacing one fully populated record with another.
                if key not in records:
                    records[key] = record

    if not records:
        raise ValueError(
            "No SIP records were found in the second worksheet of the "
            "uploaded files."
        )

    return {
        key: SIPRecord(
            excel_fund_name=record.excel_fund_name,
            canonical_fund_name=(
                SIP_FUND_NAME_ALIASES.get(
                    _base_fund_name(record.excel_fund_name),
                    record.canonical_fund_name,
                )
            ),
            periods=record.periods,
            sheet_name=record.sheet_name,
            fund_row=record.fund_row,
            note=notes.get(key, ""),
        )
        for key, record in records.items()
    }


def _rgb_to_office(rgb: tuple[int, int, int]) -> int:
    """Convert RGB to the integer used by Office COM (BGR byte order)."""
    red, green, blue = rgb
    return red + (green << 8) + (blue << 16)


def _darken(rgb: tuple[int, int, int], factor: float = 0.72) -> tuple[int, int, int]:
    return tuple(max(0, min(255, round(component * factor))) for component in rgb)


def _fund_colors(fund_name: str) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    digest = hashlib.sha256(_fund_key(fund_name).encode("utf-8")).digest()
    return SIP_COLOR_PALETTE[digest[0] % len(SIP_COLOR_PALETTE)]


def _fill_is_visible(fill) -> bool:
    try:
        return int(fill.Visible) != MsoFalse
    except Exception:
        return False


def _set_line_color(line, rgb: tuple[int, int, int]) -> None:
    try:
        line.ForeColor.RGB = _rgb_to_office(rgb)
    except Exception:
        pass


def _style_sip_fund_name(shape, dark_rgb: tuple[int, int, int]) -> None:
    """Apply the dark fund color to SIPFundName without changing geometry."""
    try:
        if _fill_is_visible(shape.Fill):
            shape.Fill.ForeColor.RGB = _rgb_to_office(dark_rgb)
        _set_line_color(shape.Line, _darken(dark_rgb, 0.70))
        if shape.HasTextFrame:
            shape.TextFrame.TextRange.Font.Color.RGB = _rgb_to_office((255, 255, 255))
    except Exception:
        pass


def _style_sip_table(
    shape,
    dark_rgb: tuple[int, int, int],
    light_rgb: tuple[int, int, int],
) -> None:
    """Recolor existing fills only; preserve cells that currently have no fill."""
    table = shape.Table
    header_border = _darken(light_rgb, 0.64)
    body_border = _darken(light_rgb, 0.72)

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            cell = table.Cell(row, column)
            cell_shape = cell.Shape
            has_fill = _fill_is_visible(cell_shape.Fill)

            if has_fill:
                # Filled header/section cells receive the medium-light shade.
                cell_shape.Fill.ForeColor.RGB = _rgb_to_office(light_rgb)
                try:
                    cell_shape.TextFrame.TextRange.Font.Color.RGB = _rgb_to_office(
                        (255, 255, 255) if row == 1 else (0, 0, 0)
                    )
                except Exception:
                    pass

            border_rgb = header_border if has_fill else body_border
            for border_index in range(1, 7):
                try:
                    border = cell.Borders.Item(border_index)
                    border.ForeColor.RGB = _rgb_to_office(border_rgb)
                except Exception:
                    pass

    # Keep the table object's own outline coordinated with the darker shade.
    _set_line_color(shape.Line, _darken(dark_rgb, 0.78))


def _update_sip_note(shape, note: str) -> bool:
    """Replace the final table row with the matched fund note when supplied."""
    if not note or not shape.HasTable:
        return False
    table = shape.Table
    last_row = table.Rows.Count
    note_shape = table.Cell(last_row, 1).Shape
    note_shape.TextFrame.TextRange.Text = note
    return True


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if shape.Type == 6:  # msoGroup
            for index in range(1, shape.GroupItems.Count + 1):
                child_text = _shape_text(shape.GroupItems.Item(index))
                if child_text:
                    parts.append(child_text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    cell = table.Cell(row, column).Shape
                    if cell.HasTextFrame and cell.TextFrame.HasText:
                        parts.append(cell.TextFrame.TextRange.Text)
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""
    return " ".join(_clean_text(part) for part in parts if part).strip()


def _set_shape_text(shape, value: str) -> None:
    if shape.HasTextFrame:
        shape.TextFrame.TextRange.Text = value
    elif shape.HasTable:
        shape.Table.Cell(1, 1).Shape.TextFrame.TextRange.Text = value
    else:
        raise ValueError(f"Object '{shape.Name}' does not support text.")


def _format_indian_number(value: object) -> str:
    """Format Investment and Market Value as rounded whole Indian numbers."""
    if _is_na(value):
        return "NA"

    number = Decimal(str(value)).quantize(
        Decimal("1"),
        rounding=ROUND_HALF_UP,
    )
    sign = "-" if number < 0 else ""
    digits = str(abs(int(number)))

    if len(digits) <= 3:
        return sign + digits

    last_three = digits[-3:]
    leading = digits[:-3]
    pairs: list[str] = []
    while leading:
        pairs.insert(0, leading[-2:])
        leading = leading[:-2]

    return sign + ",".join(pairs + [last_three])


def _format_return(value: object) -> str:
    """Format Scheme and Benchmark returns as percentages with 2 decimals."""
    if _is_na(value):
        return "NA"
    number = Decimal(str(value)).quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )
    return f"{number:.2f}%"


def _row_type(value: object) -> str | None:
    return PPT_ROW_ALIASES.get(_text_key(value))


def _period_has_no_data(values: SIPPeriodValues) -> bool:
    """Return True only when every SIP value for a period is NA or blank."""
    return all(
        _is_na(value)
        for value in (
            values.investment,
            values.market_value,
            values.scheme_returns,
            values.benchmark_returns,
            values.additional_benchmark_returns,
        )
    )


def _map_sip_table(shape) -> tuple[dict[str, int], dict[str, int]]:
    """Map PowerPoint SIP period headers and metric rows dynamically."""
    table = shape.Table
    period_columns: dict[str, int] = {}
    row_numbers: dict[str, int] = {}

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            cell = table.Cell(row, column).Shape
            text = ""
            if cell.HasTextFrame and cell.TextFrame.HasText:
                text = cell.TextFrame.TextRange.Text

            period = _period_key(text)
            if period in {"1", "3", "5", "10", "SI"}:
                period_columns[period] = column

            metric = _row_type(text)
            if metric:
                row_numbers[metric] = row

    return period_columns, row_numbers


def _delete_all_na_period_columns(
    shape,
    record: SIPRecord,
    logger,
    slide_number: int,
) -> list[str]:
    """Delete PowerPoint period columns whose complete Excel column is NA."""
    period_columns, _ = _map_sip_table(shape)

    columns_to_delete: list[tuple[int, str]] = []
    for period in ("1", "3", "5", "10", "SI"):
        values = record.periods.get(period)
        if (
            values is not None
            and _period_has_no_data(values)
            and period in period_columns
        ):
            columns_to_delete.append((period_columns[period], period))

    # Delete rightmost columns first so earlier column indexes stay valid.
    deleted_periods: list[str] = []
    for column, period in sorted(columns_to_delete, reverse=True):
        shape.Table.Columns.Item(column).Delete()
        deleted_periods.append(period)
        logger.info(
            "SIP_PERIOD_COLUMN_DELETED | slide=%s | fund=%s | "
            "period=%s | original_column=%s | reason=all_values_na",
            slide_number,
            record.canonical_fund_name,
            period,
            column,
        )

    return deleted_periods


def _set_sip_table_width(shape) -> None:
    """Set the complete SIP table object width to exactly 19.5 centimetres."""
    shape.Width = SIP_TABLE_WIDTH_CM * POINTS_PER_CM


def _update_sip_table(
    shape,
    record: SIPRecord,
    logger,
    slide_number: int,
) -> int:
    """
    Delete fully-NA period columns, resize the table, and update remaining data.

    A period column is deleted only when all five corresponding Excel values
    are NA or blank. Partially populated periods remain in the table, and each
    individual missing value is displayed as NA.
    """
    if not shape.HasTable:
        raise ValueError("SIP Table exists but is not a PowerPoint table.")

    deleted_periods = _delete_all_na_period_columns(
        shape,
        record,
        logger,
        slide_number,
    )

    # Resize after deletion so all remaining columns fit within 19.5 cm.
    _set_sip_table_width(shape)

    # Column indexes change after deletion, so map the table again.
    period_columns, row_numbers = _map_sip_table(shape)

    active_periods = {
        period
        for period in ("1", "3", "5", "10", "SI")
        if not _period_has_no_data(record.periods[period])
    }
    required_rows = {
        "investment",
        "market_value",
        "scheme_returns",
        "benchmark_returns",
        "additional_benchmark_returns",
    }

    missing_periods = active_periods - period_columns.keys()
    missing_rows = required_rows - row_numbers.keys()
    if missing_periods or missing_rows:
        details = []
        if missing_periods:
            details.append(
                "periods=" + ", ".join(sorted(missing_periods))
            )
        if missing_rows:
            details.append(
                "rows=" + ", ".join(sorted(missing_rows))
            )
        raise ValueError(
            "SIP Table labels could not be mapped after deleting all-NA "
            "columns: " + "; ".join(details)
        )

    changed = len(deleted_periods)

    # The PowerPoint order may differ from Excel. Use the mapped header column.
    for period in ("SI", "10", "5", "3", "1"):
        if period not in active_periods:
            continue

        column = period_columns[period]
        values = record.periods[period]
        output = {
            "investment": _format_indian_number(values.investment),
            "market_value": _format_indian_number(values.market_value),
            "scheme_returns": _format_return(values.scheme_returns),
            "benchmark_returns": _format_return(values.benchmark_returns),
            "additional_benchmark_returns": _format_return(
                values.additional_benchmark_returns
            ),
        }

        for metric, text in output.items():
            cell = shape.Table.Cell(
                row_numbers[metric],
                column,
            ).Shape
            cell.TextFrame.TextRange.Text = text
            changed += 1

    logger.info(
        "SIP_TABLE_RESIZED | slide=%s | fund=%s | width_cm=%.1f | "
        "columns_remaining=%s | periods_deleted=%s",
        slide_number,
        record.canonical_fund_name,
        SIP_TABLE_WIDTH_CM,
        shape.Table.Columns.Count,
        ",".join(sorted(deleted_periods)) or "none",
    )

    return changed


def _delete_named_shape(slide, object_name: str, logger) -> bool:
    shape = find_shape_recursive(slide.Shapes, object_name)
    if shape is None:
        return False
    shape.Delete()
    logger.info(
        "SIP_OBJECT_DELETED | slide=%s | object=%s",
        slide.SlideIndex,
        object_name,
    )
    return True


def _delete_sip_objects(
    slide,
    sip_table_object: str,
    sip_fund_name_object: str,
    sip_performance_date_object: str,
    logger,
) -> int:
    deleted = 0
    for object_name in (
        sip_table_object,
        sip_fund_name_object,
        sip_performance_date_object,
    ):
        deleted += int(_delete_named_shape(slide, object_name, logger))
    return deleted


def apply_sip(
    current_ppt_bytes: bytes,
    fund_object: str,
    sip_table_object: str,
    sip_fund_name_object: str,
    sip_performance_date_object: str,
    logger,
    sip_excel_files: list[tuple[str, bytes]] | None = None,
    sip_excel_bytes: bytes | None = None,
    strict: bool = False,
    sheet_name: str | None = None,
) -> bytes:
    """Match FundDetails with second-tab SIP data and update SIP objects."""
    if sip_excel_files is None:
        if sip_excel_bytes is None:
            raise ValueError("No SIP Excel file was supplied.")
        sip_excel_files = [("uploaded_sip.xlsx", sip_excel_bytes)]

    records = read_multiple_sip_files(
        sip_excel_files,
        logger,
    )
    logger.info(
        "SIP_START | ppt_bytes=%s | records=%s | strict=%s",
        len(current_ppt_bytes),
        len(records),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "sip_input.pptx"
            output_path = Path(temp_dir) / "sip_output.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False
            presentation = powerpoint.Presentations.Open(
                str(input_path.resolve()), False, False, False
            )

            updated_slides = 0
            deleted_objects = 0
            skipped_slides = 0
            total_changes = 0

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                fund_shape = find_shape_recursive(slide.Shapes, fund_object)

                if fund_shape is None:
                    message = f"Object '{fund_object}' missing on slide {slide_number}."
                    if strict:
                        raise ValueError(message)
                    logger.warning("SIP_SKIP | slide=%s | reason=%s", slide_number, message)
                    skipped_slides += 1
                    continue

                ppt_fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(ppt_fund_name))
                sip_table = find_shape_recursive(slide.Shapes, sip_table_object)

                # If the fund has no second-tab SIP record, remove all three SIP
                # objects so template/sample content is not retained.
                if record is None:
                    deleted_objects += _delete_sip_objects(
                        slide,
                        sip_table_object,
                        sip_fund_name_object,
                        sip_performance_date_object,
                        logger,
                    )
                    logger.info(
                        "SIP_DATA_ABSENT | slide=%s | fund=%s | action=objects_deleted",
                        slide_number,
                        ppt_fund_name,
                    )
                    continue

                # A fund may appear on several slides. Only the slide containing
                # SIP Table is an SIP slide; other slides are left unchanged.
                if sip_table is None:
                    logger.info(
                        "SIP_TABLE_ABSENT | slide=%s | fund=%s | action=unchanged",
                        slide_number,
                        ppt_fund_name,
                    )
                    continue

                sip_fund_shape = find_shape_recursive(
                    slide.Shapes, sip_fund_name_object
                )
                if sip_fund_shape is None:
                    message = (
                        f"Object '{sip_fund_name_object}' missing on slide "
                        f"{slide_number}."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning("SIP_SKIP | slide=%s | reason=%s", slide_number, message)
                    skipped_slides += 1
                    continue

                try:
                    changes = _update_sip_table(
                        sip_table,
                        record,
                        logger,
                        slide_number,
                    )
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "SIP_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        ppt_fund_name,
                        error,
                    )
                    skipped_slides += 1
                    continue

                display_fund_name = (
                    f"{record.canonical_fund_name} - Regular Plan - Growth Option"
                )
                _set_shape_text(sip_fund_shape, display_fund_name)
                changes += 1

                dark_rgb, light_rgb = _fund_colors(
                    record.canonical_fund_name
                )
                _style_sip_fund_name(sip_fund_shape, dark_rgb)
                _style_sip_table(sip_table, dark_rgb, light_rgb)

                if _update_sip_note(sip_table, record.note):
                    changes += 1
                    logger.info(
                        "SIP_NOTE_UPDATED | slide=%s | fund=%s",
                        slide_number,
                        record.canonical_fund_name,
                    )

                total_changes += changes
                updated_slides += 1
                logger.info(
                    "SIP_UPDATED | slide=%s | fund=%s | excel_fund=%s | changes=%s",
                    slide_number,
                    ppt_fund_name,
                    record.excel_fund_name,
                    changes,
                )

            presentation.SaveAs(
                str(output_path.resolve()),
                PP_SAVE_AS_OPEN_XML_PRESENTATION,
            )
            presentation.Close()
            presentation = None
            output = output_path.read_bytes()

            logger.info(
                "SIP_COMPLETE | slides_updated=%s | objects_deleted=%s | "
                "slides_skipped=%s | changes=%s | bytes=%s",
                updated_slides,
                deleted_objects,
                skipped_slides,
                total_changes,
                len(output),
            )
            return output

    except Exception:
        logger.exception("SIP_FAILED")
        raise
    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        presentation = None
        powerpoint = None
        pythoncom.CoUninitialize()
