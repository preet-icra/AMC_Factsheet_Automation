from __future__ import annotations

import io
import re
import tempfile
from time import perf_counter
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
POINTS_PER_CM = 72.0 / 2.54

# Slide objects that must remain anchored even when the PTC section is
# deleted, expanded, or reduced.
PTC_FIXED_OBJECT_NAMES = {
    "FooterText",
}

REQUIRED_EXCEL_HEADERS = {
    "scheme_name": {"scheme name", "scheme", "fund name"},
    "security_name": {"security name", "security", "instrument name"},
    "rating": {"rating", "credit rating"},
    "weighted_average_maturity": {
        "weighted average maturity",
        "weighted average maturity years",
        "weighted avg maturity",
        "wam",
    },
}

PPT_HEADER_ALIASES = {
    "security_name": {"security name", "security"},
    "rating": {"rating", "credit rating"},
    "weighted_average_maturity": {
        "weighted average maturity",
        "weighted average maturity years",
        "weighted avg maturity",
        "wam",
    },
}

# Left side is the Excel Scheme Name; right side is PowerPoint FundDetails.
PTC_FUND_ALIASES = {
    "Axis Children's Fund": "Axis Children's Fund",
    "Axis Childrens Fund": "Axis Children's Fund",
}


@dataclass(frozen=True)
class PTCRow:
    security_name: str
    rating: str
    weighted_average_maturity: str
    source_row: int


@dataclass(frozen=True)
class PTCRecord:
    excel_fund_name: str
    canonical_fund_name: str
    rows: tuple[PTCRow, ...]
    sheet_name: str


@dataclass(frozen=True)
class ShapeBounds:
    left: float
    top: float
    width: float
    height: float

    @property
    def bottom(self) -> float:
        return self.top + self.height


@dataclass(frozen=True)
class SectionBounds:
    left: float
    top: float
    right: float
    bottom: float

    @property
    def height(self) -> float:
        return self.bottom - self.top


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
        "\r": " ",
        "\n": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _canonical_fund_name(value: object) -> str:
    clean_name = _clean_text(value)
    aliases = {
        _text_key(excel_name): ppt_name
        for excel_name, ppt_name in PTC_FUND_ALIASES.items()
    }
    return aliases.get(_text_key(clean_name), clean_name)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _header_type(value: object, aliases: dict[str, set[str]]) -> str | None:
    key = _text_key(value)
    for header_type, names in aliases.items():
        if key in {_text_key(name) for name in names}:
            return header_type
    return None


def _find_header_row(worksheet) -> tuple[int, dict[str, int]]:
    for row in range(1, min(worksheet.max_row, 50) + 1):
        columns: dict[str, int] = {}
        for column in range(1, worksheet.max_column + 1):
            header_type = _header_type(
                worksheet.cell(row, column).value,
                REQUIRED_EXCEL_HEADERS,
            )
            if header_type and header_type not in columns:
                columns[header_type] = column

        if set(REQUIRED_EXCEL_HEADERS).issubset(columns):
            return row, columns

    raise ValueError(
        "The second worksheet does not contain the required PTC headers: "
        "Scheme Name, Security Name, Rating, and Weighted Average Maturity."
    )


def _format_maturity(value: object) -> str:
    if value is None or _clean_text(value).casefold() in {"", "na", "n/a", "-"}:
        return ""

    try:
        number = Decimal(str(value)).quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP,
        )
        return f"{number:.2f}"
    except (InvalidOperation, ValueError):
        return _clean_text(value)


def read_ptc_excel(
    excel_bytes: bytes,
    logger,
    source_file: str = "",
) -> dict[str, PTCRecord]:
    """Read PTC records from the workbook's second worksheet."""
    logger.info(
        "PTC_FILE_START | file=%s | bytes=%s",
        source_file or "uploaded.xlsx",
        len(excel_bytes),
    )

    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )
    if len(workbook.worksheets) < 2:
        raise ValueError("The PTC workbook must contain a second worksheet.")

    worksheet = workbook.worksheets[1]
    header_row, columns = _find_header_row(worksheet)

    grouped: dict[str, list[PTCRow]] = {}
    names: dict[str, str] = {}

    for row in range(header_row + 1, worksheet.max_row + 1):
        scheme_name = _clean_text(
            worksheet.cell(row, columns["scheme_name"]).value
        )
        security_name = _clean_text(
            worksheet.cell(row, columns["security_name"]).value
        )
        rating = _clean_text(
            worksheet.cell(row, columns["rating"]).value
        )
        maturity = _format_maturity(
            worksheet.cell(
                row,
                columns["weighted_average_maturity"],
            ).value
        )

        if not scheme_name:
            continue
        if not security_name:
            logger.warning(
                "PTC_ROW_SKIPPED | sheet=%s | row=%s | fund=%s | "
                "reason=security_name_blank",
                worksheet.title,
                row,
                scheme_name,
            )
            continue

        key = _fund_key(scheme_name)
        names.setdefault(key, scheme_name)
        grouped.setdefault(key, []).append(
            PTCRow(
                security_name=security_name,
                rating=rating,
                weighted_average_maturity=maturity,
                source_row=row,
            )
        )

    records = {
        key: PTCRecord(
            excel_fund_name=names[key],
            canonical_fund_name=_canonical_fund_name(names[key]),
            rows=tuple(rows),
            sheet_name=worksheet.title,
        )
        for key, rows in grouped.items()
    }

    if not records:
        raise ValueError(
            f"No usable PTC rows were found in the second worksheet "
            f"'{worksheet.title}'."
        )

    logger.info(
        "PTC_FILE_COMPLETE | sheet=%s | funds=%s | rows=%s",
        worksheet.title,
        len(records),
        sum(len(record.rows) for record in records.values()),
    )
    for record in records.values():
        logger.info(
            "PTC_FUND_FOUND | fund=%s | canonical=%s | rows=%s",
            record.excel_fund_name,
            record.canonical_fund_name,
            len(record.rows),
        )
    return records


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if shape.Type == 6:  # msoGroup
            for index in range(1, shape.GroupItems.Count + 1):
                text = _shape_text(shape.GroupItems.Item(index))
                if text:
                    parts.append(text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    cell = table.Cell(row, column).Shape
                    if cell.HasTextFrame and cell.TextFrame.HasText:
                        parts.append(cell.TextFrame.TextRange.Text)
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""
    return " ".join(_clean_text(part) for part in parts if _clean_text(part))


def _shape_bounds(shape) -> ShapeBounds:
    return ShapeBounds(
        left=float(shape.Left),
        top=float(shape.Top),
        width=float(shape.Width),
        height=float(shape.Height),
    )


def _section_bounds(shapes: list) -> SectionBounds:
    bounds = [_shape_bounds(shape) for shape in shapes]
    return SectionBounds(
        left=min(item.left for item in bounds),
        top=min(item.top for item in bounds),
        right=max(item.left + item.width for item in bounds),
        bottom=max(item.bottom for item in bounds),
    )


def _is_shape_below_section(shape, section: SectionBounds) -> bool:
    """Return True for slide content positioned below and near the PTC section."""
    bounds = _shape_bounds(shape)
    horizontal_overlap = min(
        bounds.left + bounds.width,
        section.right,
    ) - max(bounds.left, section.left)

    return (
        bounds.top >= section.bottom - 0.5
        and horizontal_overlap > 0
    )


def _move_content_below_section(
    slide,
    section: SectionBounds,
    delta_points: float,
    excluded_names: set[str],
    logger,
) -> int:
    """Move downstream content while keeping configured fixed objects anchored."""
    if abs(delta_points) < 0.01:
        return 0

    excluded_keys = {
        _clean_text(name).casefold()
        for name in excluded_names
    }

    moved = 0
    for index in range(1, slide.Shapes.Count + 1):
        shape = slide.Shapes.Item(index)
        shape_name = str(shape.Name)
        shape_name_key = _clean_text(shape_name).casefold()

        if shape_name_key in excluded_keys:
            continue

        if shape_name_key in PTC_FIXED_OBJECT_NAMES:
            logger.info(
                "PTC_FIXED_OBJECT_UNCHANGED | slide=%s | object=%s",
                slide.SlideIndex,
                shape_name,
            )
            continue

        if not _is_shape_below_section(shape, section):
            continue

        shape.Top = shape.Top + delta_points
        moved += 1
        logger.info(
            "PTC_DOWNSTREAM_SHAPE_MOVED | slide=%s | object=%s | "
            "delta_cm=%.3f",
            slide.SlideIndex,
            shape_name,
            delta_points / POINTS_PER_CM,
        )

    return moved


def _map_ptc_table(shape) -> tuple[int, dict[str, int]]:
    if not shape.HasTable:
        raise ValueError("PTCTable exists but is not a PowerPoint table.")

    table = shape.Table
    for row in range(1, table.Rows.Count + 1):
        columns: dict[str, int] = {}
        for column in range(1, table.Columns.Count + 1):
            cell = table.Cell(row, column).Shape
            text = ""
            if cell.HasTextFrame and cell.TextFrame.HasText:
                text = cell.TextFrame.TextRange.Text

            header_type = _header_type(text, PPT_HEADER_ALIASES)
            if header_type and header_type not in columns:
                columns[header_type] = column

        if set(PPT_HEADER_ALIASES).issubset(columns):
            return row, columns

    raise ValueError(
        "PTCTable headers could not be mapped. Expected Security Name, "
        "Rating, and Weighted Average Maturity (Years)."
    )


def _resize_table_rows(table, header_row: int, required_rows: int) -> None:
    existing_rows = table.Rows.Count - header_row
    while existing_rows < required_rows:
        table.Rows.Add()
        existing_rows += 1
    while existing_rows > required_rows:
        table.Rows.Item(table.Rows.Count).Delete()
        existing_rows -= 1


def _update_ptc_table(shape, record: PTCRecord) -> int:
    header_row, columns = _map_ptc_table(shape)
    table = shape.Table
    _resize_table_rows(table, header_row, len(record.rows))

    changed = 0
    for offset, ptc_row in enumerate(record.rows, start=1):
        target_row = header_row + offset
        table.Cell(
            target_row,
            columns["security_name"],
        ).Shape.TextFrame.TextRange.Text = ptc_row.security_name
        table.Cell(
            target_row,
            columns["rating"],
        ).Shape.TextFrame.TextRange.Text = ptc_row.rating
        table.Cell(
            target_row,
            columns["weighted_average_maturity"],
        ).Shape.TextFrame.TextRange.Text = (
            ptc_row.weighted_average_maturity
        )
        changed += 3

    return changed


def _find_ptc_shapes(
    slide,
    ptc_table_object: str,
    ptc_text_bg_object: str,
    ptc_icon_object: str,
    ptc_table_box_object: str,
) -> dict[str, object]:
    result: dict[str, object] = {}
    for object_name in (
        ptc_table_object,
        ptc_text_bg_object,
        ptc_icon_object,
        ptc_table_box_object,
    ):
        shape = find_shape_recursive(slide.Shapes, object_name)
        if shape is not None:
            result[object_name] = shape
    return result


def _delete_ptc_section_and_close_gap(
    slide,
    ptc_table_object: str,
    ptc_text_bg_object: str,
    ptc_icon_object: str,
    ptc_table_box_object: str,
    logger,
) -> tuple[int, int, float]:
    """Delete the PTC section and shift all later content upward by its height."""
    shapes = _find_ptc_shapes(
        slide,
        ptc_table_object,
        ptc_text_bg_object,
        ptc_icon_object,
        ptc_table_box_object,
    )
    if not shapes:
        return 0, 0, 0.0

    section = _section_bounds(list(shapes.values()))
    excluded_names = set(shapes)

    for object_name, shape in shapes.items():
        shape.Delete()
        logger.info(
            "PTC_OBJECT_DELETED | slide=%s | object=%s",
            slide.SlideIndex,
            object_name,
        )

    moved = _move_content_below_section(
        slide,
        section,
        -section.height,
        excluded_names,
        logger,
    )
    return len(shapes), moved, section.height


def _adjust_for_table_height_change(
    slide,
    original_section: SectionBounds,
    original_table_bottom: float,
    original_box_bottom: float,
    table_shape,
    table_box_shape,
    section_shapes: list,
    excluded_names: set[str],
    logger,
) -> tuple[int, float]:
    """
    Make PTCTableBox follow PTCTable and move downstream content accordingly.

    The original gap between the bottom of PTCTable and the bottom of
    PTCTableBox is treated as template padding. After PowerPoint adds or removes
    table rows, the same padding is applied below the resized table.
    """
    original_bottom_padding = max(
        0.0,
        original_box_bottom - original_table_bottom,
    )

    resized_table_bottom = float(
        table_shape.Top + table_shape.Height
    )
    required_box_bottom = (
        resized_table_bottom + original_bottom_padding
    )
    required_box_height = max(
        1.0,
        required_box_bottom - float(table_box_shape.Top),
    )

    old_box_height = float(table_box_shape.Height)
    table_box_shape.Height = required_box_height

    updated_section = _section_bounds(section_shapes)
    delta = updated_section.bottom - original_section.bottom

    logger.info(
        "PTC_TABLE_BOX_RESIZED | slide=%s | old_height_cm=%.3f | "
        "new_height_cm=%.3f | bottom_padding_cm=%.3f | "
        "section_delta_cm=%.3f",
        slide.SlideIndex,
        old_box_height / POINTS_PER_CM,
        required_box_height / POINTS_PER_CM,
        original_bottom_padding / POINTS_PER_CM,
        delta / POINTS_PER_CM,
    )

    moved = _move_content_below_section(
        slide,
        original_section,
        delta,
        excluded_names,
        logger,
    )
    return moved, delta


def apply_ptc(
    current_ppt_bytes: bytes,
    ptc_excel_bytes: bytes,
    fund_object: str,
    ptc_table_object: str,
    ptc_text_bg_object: str,
    ptc_icon_object: str,
    ptc_table_box_object: str,
    logger,
    strict: bool = False,
    source_file: str = "",
) -> bytes:
    """Update PTC sections and dynamically close or expand downstream space."""
    records = read_ptc_excel(
        ptc_excel_bytes,
        logger,
        source_file=source_file,
    )

    logger.info(
        "PTC_START | ppt_bytes=%s | records=%s | strict=%s",
        len(current_ppt_bytes),
        len(records),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory(
            ignore_cleanup_errors=True
        ) as temp_dir:
            input_path = Path(temp_dir) / "ptc_input.pptx"
            output_path = Path(temp_dir) / "ptc_output.pptx"
            input_path.write_bytes(current_ppt_bytes)

            operation_start = perf_counter()
            powerpoint_start = perf_counter()
            powerpoint = win32com.client.DispatchEx(
                "PowerPoint.Application"
            )
            powerpoint.DisplayAlerts = False
            logger.info(
                "PTC_TIMING | stage=powerpoint_started | seconds=%.3f",
                perf_counter() - powerpoint_start,
            )

            # Do not set PowerPoint.Visible=True. DispatchEx remains hidden and
            # WithWindow=False prevents slide-window redraw during automation.
            presentation_open_start = perf_counter()
            presentation = powerpoint.Presentations.Open(
                str(input_path.resolve()),
                False,
                False,
                False,
            )
            logger.info(
                "PTC_TIMING | stage=presentation_opened | slides=%s | "
                "seconds=%.3f",
                presentation.Slides.Count,
                perf_counter() - presentation_open_start,
            )

            updated_slides = 0
            deleted_objects = 0
            moved_objects = 0
            skipped_slides = 0
            total_changes = 0
            slide_processing_start = perf_counter()

            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                fund_shape = find_shape_recursive(
                    slide.Shapes,
                    fund_object,
                )

                if fund_shape is None:
                    message = (
                        f"Object '{fund_object}' missing on slide "
                        f"{slide_number}."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "PTC_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped_slides += 1
                    continue

                ppt_fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(ppt_fund_name))

                if record is None or not record.rows:
                    deleted, moved, removed_height = (
                        _delete_ptc_section_and_close_gap(
                            slide,
                            ptc_table_object,
                            ptc_text_bg_object,
                            ptc_icon_object,
                            ptc_table_box_object,
                            logger,
                        )
                    )
                    deleted_objects += deleted
                    moved_objects += moved
                    logger.info(
                        "PTC_DATA_ABSENT | slide=%s | fund=%s | "
                        "objects_deleted=%s | downstream_moved=%s | "
                        "gap_closed_cm=%.3f",
                        slide_number,
                        ppt_fund_name,
                        deleted,
                        moved,
                        removed_height / POINTS_PER_CM,
                    )
                    continue

                shapes = _find_ptc_shapes(
                    slide,
                    ptc_table_object,
                    ptc_text_bg_object,
                    ptc_icon_object,
                    ptc_table_box_object,
                )
                table_shape = shapes.get(ptc_table_object)

                # The fund can appear on several slides. Only the slide with
                # PTCTable is the PTC section slide.
                if table_shape is None:
                    logger.info(
                        "PTC_TABLE_ABSENT | slide=%s | fund=%s | "
                        "action=unchanged",
                        slide_number,
                        ppt_fund_name,
                    )
                    continue

                table_box_shape = shapes.get(ptc_table_box_object)
                if table_box_shape is None:
                    message = (
                        f"Object '{ptc_table_box_object}' missing on slide "
                        f"{slide_number} for fund '{ppt_fund_name}'."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "PTC_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        ppt_fund_name,
                        message,
                    )
                    skipped_slides += 1
                    continue

                original_section = _section_bounds(list(shapes.values()))
                original_table_bottom = float(
                    table_shape.Top + table_shape.Height
                )
                original_box_bottom = float(
                    table_box_shape.Top + table_box_shape.Height
                )
                excluded_names = set(shapes)

                try:
                    changes = _update_ptc_table(table_shape, record)
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "PTC_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        ppt_fund_name,
                        error,
                    )
                    skipped_slides += 1
                    continue

                moved, delta = _adjust_for_table_height_change(
                    slide,
                    original_section,
                    original_table_bottom,
                    original_box_bottom,
                    table_shape,
                    table_box_shape,
                    list(shapes.values()),
                    excluded_names,
                    logger,
                )
                moved_objects += moved
                total_changes += changes
                updated_slides += 1

                logger.info(
                    "PTC_UPDATED | slide=%s | fund=%s | rows=%s | "
                    "changes=%s | downstream_moved=%s | "
                    "height_delta_cm=%.3f",
                    slide_number,
                    ppt_fund_name,
                    len(record.rows),
                    changes,
                    moved,
                    delta / POINTS_PER_CM,
                )

            logger.info(
                "PTC_TIMING | stage=slides_processed | seconds=%.3f",
                perf_counter() - slide_processing_start,
            )

            save_start = perf_counter()
            presentation.SaveAs(
                str(output_path.resolve()),
                PP_SAVE_AS_OPEN_XML_PRESENTATION,
            )
            logger.info(
                "PTC_TIMING | stage=presentation_saved | seconds=%.3f",
                perf_counter() - save_start,
            )
            presentation.Close()
            presentation = None
            output = output_path.read_bytes()

            logger.info(
                "PTC_COMPLETE | slides_updated=%s | objects_deleted=%s | "
                "objects_moved=%s | slides_skipped=%s | changes=%s | "
                "bytes=%s | total_seconds=%.3f",
                updated_slides,
                deleted_objects,
                moved_objects,
                skipped_slides,
                total_changes,
                len(output),
                perf_counter() - operation_start,
            )
            return output

    except Exception:
        logger.exception("PTC_FAILED")
        raise

    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        presentation = None
        powerpoint = None
        pythoncom.CoUninitialize()
