from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
POINTS_PER_CM = 72.0 / 2.54
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_GROUP = 6

SOURCE_FUND_OBJECT = "FundName"
SOURCE_TABLE_OBJECT = "PtcTable"
TARGET_TABLE_OBJECT = "PTCTable"
TARGET_BOX_OBJECT = "PTCTableBox"
TARGET_TEXT_BG_OBJECT = "PTCTableTextBG"
TARGET_ICON_OBJECT = "PTCTableIcon"

PTC_FIXED_OBJECT_NAMES = {"footertext"}

PTC_HEADER_ALIASES = {
    "security_name": {
        "security name",
        "security",
        "instrument name",
        "instrument",
    },
    "rating": {
        "rating",
        "credit rating",
    },
    "weighted_average_maturity": {
        "weighted average maturity",
        "weighted average maturity years",
        "weighted average maturity year",
        "weighted avg maturity",
        "weighted average maturity (years)",
        "wam",
    },
}

PTC_FUND_ALIASES = {
    "Axis Childrens Fund": "Axis Children's Fund",
    "Axis Focused 25 Fund": "Axis Focused Fund",
}


@dataclass(frozen=True)
class PTCRow:
    security_name: str
    rating: str
    weighted_average_maturity: str
    source_row: int


@dataclass(frozen=True)
class PTCRecord:
    source_fund_name: str
    canonical_fund_name: str
    rows: tuple[PTCRow, ...]
    source_fund_slide: int
    source_table_slide: int


@dataclass(frozen=True)
class ShapeBounds:
    left: float
    top: float
    width: float
    height: float

    @property
    def bottom(self) -> float:
        return self.top + self.height


@dataclass(frozen=True)
class SectionBounds:
    left: float
    top: float
    right: float
    bottom: float

    @property
    def height(self) -> float:
        return self.bottom - self.top


# -----------------------------------------------------------------------------
# Normalization
# -----------------------------------------------------------------------------


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
        "\r": " ",
        "\n": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    text = _clean_text(value)
    for pattern in (
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*"
        r"growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:compulsory\s+lock-in|no\s+lock-in)(?=\s*-|$)",
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
    ):
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base = _base_fund_name(value)
    aliases = {
        _text_key(source): target
        for source, target in PTC_FUND_ALIASES.items()
    }
    return aliases.get(_text_key(base), base)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _is_valid_fund_name(value: object) -> bool:
    text = _clean_text(value)
    key = _text_key(text)
    if not text or len(text) > 150:
        return False
    if any(token in key for token in (
        "http",
        "www",
        "riskometer",
        "forviewinglatest",
        "pleasereferwebsite",
    )):
        return False
    return "axis" in key and "fund" in key


def _header_type(value: object) -> str | None:
    key = _text_key(value)
    for field_name, aliases in PTC_HEADER_ALIASES.items():
        if key in {_text_key(alias) for alias in aliases}:
            return field_name
    return None


def _format_maturity(value: object) -> str:
    text = _clean_text(value)
    if not text or text.casefold() in {"na", "n/a", "-"}:
        return ""
    try:
        return f"{float(text.replace(',', '')):.2f}"
    except ValueError:
        return text


# -----------------------------------------------------------------------------
# Shape and table discovery
# -----------------------------------------------------------------------------


def _cell_text(table, row: int, column: int) -> str:
    try:
        shape = table.Cell(row, column).Shape
        if shape.HasTextFrame and shape.TextFrame.HasText:
            return _clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                text = _shape_text(shape.GroupItems.Item(index))
                if text:
                    parts.append(text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    parts.append(_cell_text(table, row, column))
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(str(shape.TextFrame.TextRange.Text or ""))
    except Exception:
        return ""
    return " ".join(_clean_text(part) for part in parts if _clean_text(part))


def _iter_shapes_recursive(shapes):
    for index in range(1, shapes.Count + 1):
        try:
            shape = shapes.Item(index)
        except Exception:
            continue
        yield shape
        try:
            if int(shape.Type) == MSO_GROUP:
                yield from _iter_shapes_recursive(shape.GroupItems)
        except Exception:
            pass


def _shape_name_key(shape) -> str:
    try:
        return _text_key(shape.Name)
    except Exception:
        return ""


def _find_named_shape_with_owner(slide, object_name: str):
    wanted = _text_key(object_name)

    def walk(shape, owner):
        if _shape_name_key(shape) == wanted:
            return shape, owner
        try:
            if int(shape.Type) == MSO_GROUP:
                for index in range(1, shape.GroupItems.Count + 1):
                    result = walk(shape.GroupItems.Item(index), owner)
                    if result is not None:
                        return result
        except Exception:
            pass
        return None

    for index in range(1, slide.Shapes.Count + 1):
        try:
            top_level = slide.Shapes.Item(index)
        except Exception:
            continue
        result = walk(top_level, top_level)
        if result is not None:
            return result
    return None, None


def _find_named_shape_robust(slide, object_name: str):
    shape, _ = _find_named_shape_with_owner(slide, object_name)
    if shape is not None:
        return shape
    return find_shape_recursive(slide.Shapes, object_name)


def _find_table_shape(shape):
    if shape is None:
        return None
    try:
        if shape.HasTable:
            return shape
    except Exception:
        pass
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                result = _find_table_shape(shape.GroupItems.Item(index))
                if result is not None:
                    return result
    except Exception:
        pass
    return None


def _map_ptc_table(shape) -> tuple[object, int, dict[str, int]]:
    table_shape = _find_table_shape(shape)
    if table_shape is None:
        raise ValueError("The PTC object does not contain a PowerPoint table.")

    table = table_shape.Table
    required = set(PTC_HEADER_ALIASES)
    for row in range(1, table.Rows.Count + 1):
        columns: dict[str, int] = {}
        for column in range(1, table.Columns.Count + 1):
            field = _header_type(_cell_text(table, row, column))
            if field and field not in columns:
                columns[field] = column
        if required.issubset(columns):
            return table_shape, row, columns

    raise ValueError(
        "PTC table headers could not be mapped. Expected Security Name, "
        "Rating, and Weighted Average Maturity (Years)."
    )


def _find_ptc_table_by_content(slide):
    for shape in _iter_shapes_recursive(slide.Shapes):
        try:
            if not shape.HasTable:
                continue
        except Exception:
            continue
        try:
            _map_ptc_table(shape)
            return shape
        except ValueError:
            continue
    return None


def _find_fund_shape_by_content(slide):
    candidates = []
    for shape in _iter_shapes_recursive(slide.Shapes):
        try:
            if shape.HasTable:
                continue
        except Exception:
            pass
        text = _shape_text(shape)
        if _is_valid_fund_name(text):
            candidates.append((len(text), shape))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


# -----------------------------------------------------------------------------
# Source indexing
# -----------------------------------------------------------------------------


def _read_source_rows(shape) -> tuple[PTCRow, ...]:
    table_shape, header_row, columns = _map_ptc_table(shape)
    table = table_shape.Table
    rows: list[PTCRow] = []

    for row in range(header_row + 1, table.Rows.Count + 1):
        security_name = _cell_text(table, row, columns["security_name"])
        rating = _cell_text(table, row, columns["rating"])
        maturity = _cell_text(
            table,
            row,
            columns["weighted_average_maturity"],
        )
        if not security_name:
            continue
        if not rating and not maturity:
            continue
        rows.append(
            PTCRow(
                security_name=security_name,
                rating=rating,
                weighted_average_maturity=_format_maturity(maturity),
                source_row=row,
            )
        )
    return tuple(rows)


def _build_source_index(
    source_presentation,
    source_fund_object: str,
    source_table_object: str,
    logger,
) -> dict[str, PTCRecord]:
    records: dict[str, PTCRecord] = {}
    pending_fund_name = ""
    pending_fund_slide = 0

    for slide_number in range(1, source_presentation.Slides.Count + 1):
        pythoncom.PumpWaitingMessages()
        slide = source_presentation.Slides.Item(slide_number)

        fund_shape = _find_named_shape_robust(slide, source_fund_object)
        if fund_shape is None:
            fund_shape = _find_fund_shape_by_content(slide)
        current_fund = _shape_text(fund_shape) if fund_shape else ""
        if current_fund and not _is_valid_fund_name(current_fund):
            current_fund = ""

        table_shape = _find_named_shape_robust(slide, source_table_object)
        if _find_table_shape(table_shape) is None:
            table_shape = _find_ptc_table_by_content(slide)

        if table_shape is None:
            if current_fund:
                pending_fund_name = current_fund
                pending_fund_slide = slide_number
                logger.info(
                    "PTC_SOURCE_FUND_PENDING | slide=%s | fund=%s",
                    slide_number,
                    current_fund,
                )
            continue

        effective_fund = current_fund or pending_fund_name
        effective_fund_slide = (
            slide_number if current_fund else pending_fund_slide
        )
        if not effective_fund:
            logger.warning(
                "PTC_SOURCE_TABLE_UNASSIGNED | slide=%s | table=%s",
                slide_number,
                getattr(table_shape, "Name", "<unnamed>"),
            )
            continue

        try:
            rows = _read_source_rows(table_shape)
        except ValueError as error:
            logger.warning(
                "PTC_SOURCE_SKIPPED | slide=%s | fund=%s | reason=%s",
                slide_number,
                effective_fund,
                error,
            )
            pending_fund_name = ""
            pending_fund_slide = 0
            continue

        if rows:
            key = _fund_key(effective_fund)
            record = PTCRecord(
                source_fund_name=effective_fund,
                canonical_fund_name=_canonical_fund_name(effective_fund),
                rows=rows,
                source_fund_slide=effective_fund_slide,
                source_table_slide=slide_number,
            )
            if key not in records:
                records[key] = record
                logger.info(
                    "PTC_SOURCE_FOUND | fund_slide=%s | table_slide=%s | "
                    "fund=%s | rows=%s",
                    effective_fund_slide,
                    slide_number,
                    record.canonical_fund_name,
                    len(rows),
                )
            else:
                logger.warning(
                    "PTC_SOURCE_DUPLICATE | fund=%s | ignored_slide=%s",
                    record.canonical_fund_name,
                    slide_number,
                )

        pending_fund_name = ""
        pending_fund_slide = 0

    logger.info("PTC_SOURCE_INDEX_COMPLETE | funds=%s", len(records))
    if not records:
        raise ValueError(
            "No usable PTC source tables were found. Processing stopped before "
            "the target presentation was modified."
        )
    return records


# -----------------------------------------------------------------------------
# Target update, layout, and deletion
# -----------------------------------------------------------------------------


def _set_cell_text_preserve_format(cell_shape, value: str) -> None:
    text_range = cell_shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")
    if old_text:
        text_range.Characters(1, len(old_text)).Text = str(value)
    else:
        text_range.Text = str(value)


def _resize_rows(table, header_row: int, required_rows: int) -> None:
    template_height = None
    if table.Rows.Count > header_row:
        try:
            template_height = float(table.Rows.Item(header_row + 1).Height)
        except Exception:
            pass

    existing = table.Rows.Count - header_row
    while existing < required_rows:
        table.Rows.Add()
        existing += 1
    while existing > required_rows:
        table.Rows.Item(table.Rows.Count).Delete()
        existing -= 1

    if template_height is not None:
        for row in range(header_row + 1, table.Rows.Count + 1):
            try:
                table.Rows.Item(row).Height = template_height
            except Exception:
                pass


def _update_target_table(shape, record: PTCRecord) -> int:
    table_shape, header_row, columns = _map_ptc_table(shape)
    table = table_shape.Table
    _resize_rows(table, header_row, len(record.rows))

    changed = 0
    for offset, source_row in enumerate(record.rows, start=1):
        row = header_row + offset
        _set_cell_text_preserve_format(
            table.Cell(row, columns["security_name"]).Shape,
            source_row.security_name,
        )
        _set_cell_text_preserve_format(
            table.Cell(row, columns["rating"]).Shape,
            source_row.rating,
        )
        _set_cell_text_preserve_format(
            table.Cell(row, columns["weighted_average_maturity"]).Shape,
            source_row.weighted_average_maturity,
        )
        changed += 3
    return changed


def _shape_bounds(shape) -> ShapeBounds:
    return ShapeBounds(
        left=float(shape.Left),
        top=float(shape.Top),
        width=float(shape.Width),
        height=float(shape.Height),
    )


def _section_bounds(shapes: list) -> SectionBounds:
    bounds = [_shape_bounds(shape) for shape in shapes]
    return SectionBounds(
        left=min(item.left for item in bounds),
        top=min(item.top for item in bounds),
        right=max(item.left + item.width for item in bounds),
        bottom=max(item.bottom for item in bounds),
    )


def _move_content_below_section(
    slide,
    section: SectionBounds,
    delta: float,
    excluded_ids: set[int],
    logger,
) -> int:
    if abs(delta) < 0.01:
        return 0
    moved = 0
    for index in range(1, slide.Shapes.Count + 1):
        shape = slide.Shapes.Item(index)
        try:
            if int(shape.Id) in excluded_ids:
                continue
        except Exception:
            pass
        name_key = _text_key(getattr(shape, "Name", ""))
        if name_key in PTC_FIXED_OBJECT_NAMES:
            continue
        bounds = _shape_bounds(shape)
        overlap = min(bounds.left + bounds.width, section.right) - max(
            bounds.left,
            section.left,
        )
        if bounds.top >= section.bottom - 0.5 and overlap > 0:
            shape.Top = shape.Top + delta
            moved += 1
    return moved


def _find_target_shapes(
    slide,
    table_object: str,
    text_bg_object: str,
    icon_object: str,
    box_object: str,
) -> dict[str, object]:
    result = {}
    for name in (table_object, text_bg_object, icon_object, box_object):
        shape = _find_named_shape_robust(slide, name)
        if shape is not None:
            result[name] = shape
    return result


def _delete_ptc_objects(
    slide,
    table_object: str,
    text_bg_object: str,
    icon_object: str,
    box_object: str,
    logger,
) -> tuple[int, int, float]:
    """
    Delete the complete PTC section and close the resulting vertical gap.

    PTCTable and PTCTableBox are resolved by Selection Pane names. The purple
    heading is additionally resolved by the exact visible text
    'WEIGHTED AVERAGE MATURITY OF PTC' because templates often assign an
    automatic shape or group name. The orange icon fallback is deliberately
    narrow and selects only one small shape immediately to the left of that
    heading. Unrelated slide objects are never selected by a broad area scan.
    """
    owners: dict[str, tuple[object, set[str]]] = {}

    def add_owner(owner, reason: str) -> None:
        if owner is None:
            return
        try:
            key = str(owner.Id)
        except Exception:
            key = f"{_shape_name_key(owner)}:{id(owner)}"
        if key not in owners:
            owners[key] = (owner, set())
        owners[key][1].add(reason)

    # First resolve all four configured object names, including nested objects.
    for name in (table_object, box_object, text_bg_object, icon_object):
        matched, owner = _find_named_shape_with_owner(slide, name)
        if matched is None or owner is None:
            logger.info(
                "PTC_OBJECT_NAME_NOT_FOUND | slide=%s | object=%s",
                slide.SlideIndex,
                name,
            )
            continue
        add_owner(owner, name)

    # Resolve the purple PTC heading by exact semantic text. This works when
    # PTCTextandBG or PTCTableTextBG is not the real Selection Pane name.
    heading_token = _text_key("WEIGHTED AVERAGE MATURITY OF PTC")
    heading_owner = None
    heading_geometry = None

    for index in range(1, slide.Shapes.Count + 1):
        try:
            candidate = slide.Shapes.Item(index)
            visible_key = _text_key(_shape_text(candidate))
        except Exception:
            continue

        if heading_token not in visible_key:
            continue

        heading_owner = candidate
        add_owner(candidate, "ptc_heading_text")
        try:
            heading_geometry = (
                float(candidate.Left),
                float(candidate.Top),
                float(candidate.Width),
                float(candidate.Height),
            )
        except Exception:
            heading_geometry = None
        break

    # Resolve one small icon immediately to the left of the heading. The limits
    # deliberately exclude tables, wide boxes, footers, and other sections.
    if heading_geometry is not None:
        h_left, h_top, h_width, h_height = heading_geometry
        h_center_y = h_top + h_height / 2.0
        best_icon = None
        best_distance = None

        for index in range(1, slide.Shapes.Count + 1):
            try:
                candidate = slide.Shapes.Item(index)
                if heading_owner is not None and int(candidate.Id) == int(
                    heading_owner.Id
                ):
                    continue
                if candidate.HasTable:
                    continue
                c_left = float(candidate.Left)
                c_top = float(candidate.Top)
                c_width = float(candidate.Width)
                c_height = float(candidate.Height)
            except Exception:
                continue

            c_right = c_left + c_width
            c_center_y = c_top + c_height / 2.0
            horizontal_gap = h_left - c_right
            vertical_offset = abs(c_center_y - h_center_y)

            is_small_icon = (
                12.0 <= c_width <= 75.0
                and 12.0 <= c_height <= 75.0
            )
            is_immediately_left = -12.0 <= horizontal_gap <= 50.0
            is_vertically_aligned = (
                vertical_offset <= max(14.0, h_height * 0.80)
            )

            if not (
                is_small_icon
                and is_immediately_left
                and is_vertically_aligned
            ):
                continue

            distance = abs(horizontal_gap) + vertical_offset
            if best_distance is None or distance < best_distance:
                best_icon = candidate
                best_distance = distance

        if best_icon is not None:
            add_owner(best_icon, "ptc_icon_geometry")
        else:
            logger.info(
                "PTC_ICON_FALLBACK_NOT_FOUND | slide=%s",
                slide.SlideIndex,
            )
    elif heading_owner is None:
        logger.info(
            "PTC_HEADING_FALLBACK_NOT_FOUND | slide=%s",
            slide.SlideIndex,
        )

    if not owners:
        return 0, 0, 0.0

    # Measure the complete resolved section before deleting any COM object.
    owner_values = [owner for owner, _ in owners.values()]
    section = _section_bounds(owner_values)
    excluded_ids: set[int] = set()
    for owner in owner_values:
        try:
            excluded_ids.add(int(owner.Id))
        except Exception:
            pass

    # Delete in reverse z-order to keep COM collection references stable.
    owner_items = list(owners.values())
    owner_items.sort(
        key=lambda item: int(getattr(item[0], "ZOrderPosition", 0)),
        reverse=True,
    )

    deleted = 0
    for owner, reasons in owner_items:
        try:
            owner_name = str(owner.Name)
        except Exception:
            owner_name = "<group>"
        try:
            owner.Delete()
            deleted += 1
            logger.info(
                "PTC_OWNER_DELETED | slide=%s | owner=%s | reasons=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
            )
        except Exception as error:
            logger.warning(
                "PTC_OWNER_DELETE_FAILED | slide=%s | owner=%s | "
                "reasons=%s | error=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
                error,
            )

    moved = _move_content_below_section(
        slide,
        section,
        -section.height,
        excluded_ids,
        logger,
    )
    logger.info(
        "PTC_SECTION_DELETED | slide=%s | owners=%s | gap_closed_cm=%.3f",
        slide.SlideIndex,
        deleted,
        section.height / POINTS_PER_CM,
    )
    return deleted, moved, section.height


def _adjust_layout_after_update(
    slide,
    original_section: SectionBounds,
    original_table_bottom: float,
    original_box_bottom: float,
    table_shape,
    box_shape,
    section_shapes: list,
    logger,
) -> tuple[int, float]:
    padding = max(0.0, original_box_bottom - original_table_bottom)
    new_table_bottom = float(table_shape.Top + table_shape.Height)
    box_shape.Height = max(
        1.0,
        new_table_bottom + padding - float(box_shape.Top),
    )
    updated_section = _section_bounds(section_shapes)
    delta = updated_section.bottom - original_section.bottom
    excluded_ids = {
        int(shape.Id)
        for shape in section_shapes
        if getattr(shape, "Id", None) is not None
    }
    moved = _move_content_below_section(
        slide,
        original_section,
        delta,
        excluded_ids,
        logger,
    )
    return moved, delta


# -----------------------------------------------------------------------------
# COM and public operation
# -----------------------------------------------------------------------------


def _retry_com(name: str, operation, logger, attempts: int = 6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(error, "hresult", error.args[0] if error.args else None)
            if code not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "PTC_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def apply_ptc(
    current_ppt_bytes: bytes,
    ptc_source_ppt_bytes: bytes | None = None,
    fund_object: str = "FundDetails",
    ptc_table_object: str = TARGET_TABLE_OBJECT,
    ptc_text_bg_object: str = TARGET_TEXT_BG_OBJECT,
    ptc_icon_object: str = TARGET_ICON_OBJECT,
    ptc_table_box_object: str = TARGET_BOX_OBJECT,
    logger=None,
    strict: bool = False,
    source_file: str = "",
    source_fund_object: str = SOURCE_FUND_OBJECT,
    source_table_object: str = SOURCE_TABLE_OBJECT,
    ptc_excel_bytes: bytes | None = None,
) -> bytes:
    """Copy PTC rows from a source PowerPoint into the target PowerPoint."""
    if logger is None:
        raise ValueError("A logger is required for PTC processing.")
    if ptc_source_ppt_bytes is None:
        if ptc_excel_bytes is not None:
            raise ValueError(
                "PTC now requires a source PowerPoint instead of Excel. "
                "Pass ptc_source_ppt_bytes."
            )
        raise ValueError("Upload a source PTC PowerPoint.")

    pythoncom.CoInitialize()
    powerpoint = source_presentation = target_presentation = None
    operation_start = perf_counter()

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "ptc_source.pptx"
            target_path = temp / "ptc_target.pptx"
            output_path = temp / "ptc_output.pptx"
            source_path.write_bytes(ptc_source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.DisplayAlerts = False
            source_presentation = _retry_com(
                "open PTC source",
                lambda: powerpoint.Presentations.Open(
                    str(source_path.resolve()), True, False, False
                ),
                logger,
            )
            target_presentation = _retry_com(
                "open PTC target",
                lambda: powerpoint.Presentations.Open(
                    str(target_path.resolve()), False, False, False
                ),
                logger,
            )

            records = _build_source_index(
                source_presentation,
                source_fund_object,
                source_table_object,
                logger,
            )

            updated = deleted = moved_total = skipped = changes_total = 0
            for slide_number in range(1, target_presentation.Slides.Count + 1):
                slide = target_presentation.Slides.Item(slide_number)
                shapes = _find_target_shapes(
                    slide,
                    ptc_table_object,
                    ptc_text_bg_object,
                    ptc_icon_object,
                    ptc_table_box_object,
                )
                table_wrapper = shapes.get(ptc_table_object)
                if table_wrapper is None:
                    continue

                fund_shape = _find_named_shape_robust(slide, fund_object)
                if fund_shape is None:
                    if strict:
                        raise ValueError(
                            f"Object '{fund_object}' missing on slide {slide_number}."
                        )
                    skipped += 1
                    continue

                fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(fund_name))
                if record is None or not record.rows:
                    deleted_now, moved_now, _ = _delete_ptc_objects(
                        slide,
                        ptc_table_object,
                        ptc_text_bg_object,
                        ptc_icon_object,
                        ptc_table_box_object,
                        logger,
                    )
                    deleted += deleted_now
                    moved_total += moved_now
                    logger.info(
                        "PTC_DATA_ABSENT | slide=%s | fund=%s | deleted=%s",
                        slide_number,
                        fund_name,
                        deleted_now,
                    )
                    continue

                table_shape = _find_table_shape(table_wrapper)
                box_shape = shapes.get(ptc_table_box_object)
                if table_shape is None or box_shape is None:
                    if strict:
                        raise ValueError(
                            f"PTC table or box missing on slide {slide_number}."
                        )
                    skipped += 1
                    continue

                section_shapes = list(shapes.values())
                original_section = _section_bounds(section_shapes)
                original_table_bottom = float(table_shape.Top + table_shape.Height)
                original_box_bottom = float(box_shape.Top + box_shape.Height)

                try:
                    changes = _update_target_table(table_wrapper, record)
                    moved, delta = _adjust_layout_after_update(
                        slide,
                        original_section,
                        original_table_bottom,
                        original_box_bottom,
                        table_shape,
                        box_shape,
                        section_shapes,
                        logger,
                    )
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "PTC_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        fund_name,
                        error,
                    )
                    skipped += 1
                    continue

                updated += 1
                changes_total += changes
                moved_total += moved
                logger.info(
                    "PTC_UPDATED | target_slide=%s | source_table_slide=%s | "
                    "fund=%s | rows=%s | changes=%s | height_delta_cm=%.3f",
                    slide_number,
                    record.source_table_slide,
                    record.canonical_fund_name,
                    len(record.rows),
                    changes,
                    delta / POINTS_PER_CM,
                )

            _retry_com(
                "save PTC target",
                lambda: target_presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            target_presentation.Close()
            target_presentation = None
            source_presentation.Close()
            source_presentation = None

            output = output_path.read_bytes()
            logger.info(
                "PTC_COMPLETE | source_funds=%s | slides_updated=%s | "
                "objects_deleted=%s | objects_moved=%s | skipped=%s | "
                "changes=%s | bytes=%s | total_seconds=%.3f",
                len(records),
                updated,
                deleted,
                moved_total,
                skipped,
                changes_total,
                len(output),
                perf_counter() - operation_start,
            )
            return output

    except Exception:
        logger.exception("PTC_FAILED")
        raise
    finally:
        for presentation in (target_presentation, source_presentation):
            if presentation is not None:
                try:
                    presentation.Close()
                except Exception:
                    pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
