from __future__ import annotations

import io
import tempfile
from pathlib import Path

import pandas as pd
import pythoncom
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
POINTS_PER_CM = 72.0 / 2.54
FUND_DETAILS_LONG_NAME_LIMIT = 50
FUND_DETAILS_UPWARD_SHIFT_CM = 0.2


def _unique_headers(values: list[object]) -> list[str]:
    """Create non-empty, unique column headings from an Excel header row."""
    seen: dict[str, int] = {}
    result: list[str] = []

    for index, value in enumerate(values, start=1):
        base = str(value or "").strip() or f"Column_{index}"
        seen[base] = seen.get(base, 0) + 1
        result.append(
            base if seen[base] == 1 else f"{base}_{seen[base]}"
        )

    return result


def read_fund_names(
    excel_bytes: bytes,
    sheet_name: str,
    fund_column: str,
    logger,
) -> pd.DataFrame:
    """Read the authoritative fund-name workbook."""
    logger.info("STEP_1_FUND_FILE_START | bytes=%s", len(excel_bytes))

    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )

    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"Sheet '{sheet_name}' was not found.")

    worksheet = workbook[sheet_name]
    rows = [
        [cell.value for cell in row]
        for row in worksheet.iter_rows()
    ]

    header_index = next(
        (
            index
            for index, row in enumerate(rows)
            if any(
                normalize(value) == normalize(fund_column)
                for value in row
            )
        ),
        None,
    )

    if header_index is None:
        raise ValueError(
            f"Column '{fund_column}' was not found in sheet "
            f"'{sheet_name}'."
        )

    headers = _unique_headers(rows[header_index])
    data = pd.DataFrame(
        rows[header_index + 1:],
        columns=headers,
    )

    actual_column = next(
        column
        for column in data.columns
        if normalize(column) == normalize(fund_column)
    )

    data = data[
        data[actual_column]
        .fillna("")
        .astype(str)
        .str.strip()
        .ne("")
    ].copy()

    data.rename(
        columns={actual_column: fund_column},
        inplace=True,
    )

    data[fund_column] = (
        data[fund_column]
        .astype(str)
        .str.strip()
    )

    normalized_names = data[fund_column].map(normalize)
    duplicates = data.loc[
        normalized_names.duplicated(keep=False),
        fund_column,
    ].tolist()

    if duplicates:
        raise ValueError(
            "Duplicate fund names: " + ", ".join(duplicates)
        )

    data.reset_index(drop=True, inplace=True)

    logger.info(
        "STEP_1_FUND_FILE_COMPLETE | funds=%s",
        len(data),
    )

    for index, name in enumerate(data[fund_column], start=1):
        logger.info(
            "STEP_1_FUND_FOUND | index=%s | fund=%s",
            index,
            name,
        )

    return data


def _clean_upper_fund_name(value: str) -> str:
    """Normalize whitespace and convert a fund name to uppercase."""
    return " ".join(str(value).split()).upper()


def _find_case_insensitive(text: str, search_text: str) -> int:
    """Return the zero-based position of search_text, ignoring case."""
    return text.casefold().find(search_text.casefold())


def _safe_font_color(text_range, fallback: int | None = None) -> int | None:
    """Read a PowerPoint text range's RGB font color when available."""
    try:
        color = text_range.Font.Color.RGB
        return int(color)
    except Exception:
        return fallback


def _replace_and_preserve_funddetails_colors(
    text_range,
    old_name: str,
    new_name: str,
) -> int:
    """
    Replace one fund name, convert it to uppercase, and preserve two colors.

    The first word, normally AXIS, receives the color used by the first word
    in the template. The remainder receives the color used by the text after
    the first word in the template.

    This deliberately updates character ranges instead of assigning to
    shape.TextFrame.TextRange.Text for the whole shape. Updating the whole
    shape at once would collapse the mixed-color formatting into one color.
    """
    current_text = str(text_range.Text or "")
    cleaned_old_name = " ".join(str(old_name).split())
    cleaned_new_name = _clean_upper_fund_name(new_name)

    if not cleaned_old_name or not cleaned_new_name:
        return 0

    match_start_zero_based = _find_case_insensitive(
        current_text,
        cleaned_old_name,
    )

    if match_start_zero_based < 0:
        return 0

    match_start = match_start_zero_based + 1
    old_length = len(cleaned_old_name)

    old_first_word = cleaned_old_name.split(maxsplit=1)[0]
    old_first_length = len(old_first_word)

    new_parts = cleaned_new_name.split(maxsplit=1)
    new_first_word = new_parts[0]
    new_first_length = len(new_first_word)

    # Capture the two colors before changing the text.
    first_word_range = text_range.Characters(
        match_start,
        max(old_first_length, 1),
    )
    first_word_color = _safe_font_color(first_word_range)

    old_remainder_offset = old_first_length
    while (
        old_remainder_offset < old_length
        and cleaned_old_name[old_remainder_offset].isspace()
    ):
        old_remainder_offset += 1

    if old_remainder_offset < old_length:
        remainder_sample = text_range.Characters(
            match_start + old_remainder_offset,
            1,
        )
        remainder_color = _safe_font_color(
            remainder_sample,
            first_word_color,
        )
    else:
        remainder_color = first_word_color

    # Replace only the matched template fund name.
    target_range = text_range.Characters(match_start, old_length)
    target_range.Text = cleaned_new_name

    new_total_length = len(cleaned_new_name)
    new_range = text_range.Characters(match_start, new_total_length)

    # Apply the second-part color to the complete name first.
    if remainder_color is not None:
        new_range.Font.Color.RGB = remainder_color

    # Restore the template AXIS color to the first word only.
    if first_word_color is not None:
        new_first_range = text_range.Characters(
            match_start,
            new_first_length,
        )
        new_first_range.Font.Color.RGB = first_word_color

    return 1


def _replace_in_funddetails(
    shape,
    old_name: str,
    new_name: str,
) -> int:
    """
    Update FundDetails in a text shape or table while preserving two colors.
    """
    changed = 0

    if shape.HasTable:
        table = shape.Table

        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell_shape = table.Cell(row, column).Shape

                if (
                    cell_shape.HasTextFrame
                    and cell_shape.TextFrame.HasText
                ):
                    changed += _replace_and_preserve_funddetails_colors(
                        cell_shape.TextFrame.TextRange,
                        old_name,
                        new_name,
                    )

    elif shape.HasTextFrame and shape.TextFrame.HasText:
        changed += _replace_and_preserve_funddetails_colors(
            shape.TextFrame.TextRange,
            old_name,
            new_name,
        )

    return changed


def _move_funddetails_for_long_name(
    shape,
    fund_name: str,
) -> bool:
    """Move FundDetails upward by 0.1 cm when the name exceeds 46 characters."""
    character_count = len(str(fund_name))

    if character_count <= FUND_DETAILS_LONG_NAME_LIMIT:
        return False

    upward_shift_points = (
        FUND_DETAILS_UPWARD_SHIFT_CM * POINTS_PER_CM
    )
    shape.Top = shape.Top - upward_shift_points
    return True


def create_scheme_presentation(
    template_bytes: bytes,
    selected_funds: pd.DataFrame,
    fund_column: str,
    fund_object: str,
    template_fund_name: str,
    slides_per_fund: int,
    logger,
) -> bytes:
    """Create fund slides and update FundDetails with preserved formatting."""
    if selected_funds.empty:
        raise ValueError("Select at least one scheme.")

    if not isinstance(slides_per_fund, int) or slides_per_fund < 1:
        raise ValueError(
            "slides_per_fund must be a positive integer; "
            f"received {slides_per_fund!r}."
        )

    expected_slides = len(selected_funds) * slides_per_fund

    logger.info(
        "STEP_1_START | schemes=%s | expected_slides=%s",
        len(selected_funds),
        expected_slides,
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_path = Path(temp_dir) / "template.pptx"
            output_path = Path(temp_dir) / "scheme_output.pptx"
            template_path.write_bytes(template_bytes)

            powerpoint = win32com.client.DispatchEx(
                "PowerPoint.Application"
            )
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False

            presentation = powerpoint.Presentations.Open(
                str(template_path.resolve()),
                False,
                False,
                False,
            )

            actual_template_slides = presentation.Slides.Count

            if actual_template_slides != slides_per_fund:
                raise ValueError(
                    f"Template must have {slides_per_fund} slide(s); "
                    f"found {actual_template_slides}."
                )

            for block in range(2, len(selected_funds) + 1):
                before = presentation.Slides.Count
                slide_numbers = list(
                    range(1, slides_per_fund + 1)
                )
                presentation.Slides.Range(slide_numbers).Copy()
                presentation.Slides.Paste(
                    presentation.Slides.Count + 1
                )

                logger.info(
                    "STEP_1_BLOCK_COPIED | block=%s | slides=%s -> %s",
                    block,
                    before,
                    presentation.Slides.Count,
                )

            total_changes = 0

            for fund_index, (_, fund) in enumerate(
                selected_funds.iterrows(),
                start=1,
            ):
                fund_name = _clean_upper_fund_name(
                    fund[fund_column]
                )

                first_slide = (
                    (fund_index - 1) * slides_per_fund + 1
                )
                last_slide = first_slide + slides_per_fund - 1

                logger.info(
                    "STEP_1_FUND_START | scheme=%s | slides=%s-%s",
                    fund_name,
                    first_slide,
                    last_slide,
                )

                for slide_number in range(
                    first_slide,
                    last_slide + 1,
                ):
                    slide = presentation.Slides.Item(slide_number)
                    shape = find_shape_recursive(
                        slide.Shapes,
                        fund_object,
                    )

                    if shape is None:
                        raise ValueError(
                            f"Object '{fund_object}' missing on "
                            f"slide {slide_number}."
                        )

                    changes = _replace_in_funddetails(
                        shape,
                        template_fund_name,
                        fund_name,
                    )

                    if changes == 0:
                        raise ValueError(
                            f"Text '{template_fund_name}' not found inside "
                            f"'{fund_object}' on slide {slide_number}. "
                            "Make sure the template FundDetails object "
                            "contains the configured template fund name."
                        )

                    moved_up = _move_funddetails_for_long_name(
                        shape,
                        fund_name,
                    )

                    if moved_up:
                        logger.info(
                            "STEP_1_FUNDDETAILS_MOVED | slide=%s | "
                            "fund=%s | characters=%s | direction=up | "
                            "distance_cm=%.1f",
                            slide_number,
                            fund_name,
                            len(fund_name),
                            FUND_DETAILS_UPWARD_SHIFT_CM,
                        )

                    total_changes += changes

                    logger.info(
                        "STEP_1_FUNDDETAILS_CHANGED | slide=%s | "
                        "%s -> %s | uppercase=true | colors=preserved",
                        slide_number,
                        template_fund_name,
                        fund_name,
                    )

                    # Release per-slide COM references before continuing.
                    shape = None
                    slide = None

            presentation.SaveAs(
                str(output_path.resolve()),
                PP_SAVE_AS_OPEN_XML_PRESENTATION,
            )

            presentation.Close()
            presentation = None

            output = output_path.read_bytes()

            logger.info(
                "STEP_1_COMPLETE | schemes=%s | slides=%s | "
                "changes=%s | bytes=%s",
                len(selected_funds),
                expected_slides,
                total_changes,
                len(output),
            )

            return output

    except Exception:
        logger.exception("STEP_1_FAILED")
        raise

    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass

        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass

        presentation = None
        powerpoint = None
        pythoncom.CoUninitialize()
