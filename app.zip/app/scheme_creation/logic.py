from __future__ import annotations

import io
import re
import tempfile
import time
from time import perf_counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal

import pandas as pd
import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize

PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
PP_ALIGN_LEFT = 1
PP_ALIGN_CENTER = 2
PP_ALIGN_RIGHT = 3
PP_ALIGN_JUSTIFY = 4
POINTS_PER_CM = 72.0 / 2.54

RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
COM_RETRY_ATTEMPTS = 8

TextCase = Literal["upper", "lower", "title", "preserve"]
ColorMode = Literal["preserve", "uniform", "split_first_word"]
ResizeMode = Literal["none", "shrink_to_fit"]
ProgressCallback = Callable[[int, str, str], None]


@dataclass(frozen=True)
class LengthPositionRule:
    character_limit: int
    top_shift_cm: float = 0.0
    left_shift_cm: float = 0.0
    width_adjustment_cm: float = 0.0
    height_adjustment_cm: float = 0.0
    font_size: float | None = None


@dataclass(frozen=True)
class FundDetailsFormatting:
    text_case: TextCase = "upper"
    color_mode: ColorMode = "preserve"
    uniform_rgb: int | None = None
    first_word_rgb: int | None = None
    remainder_rgb: int | None = None
    font_name: str | None = None
    font_size: float | None = None
    bold: bool | None = None
    italic: bool | None = None
    alignment: int | None = None
    word_wrap: bool | None = None
    auto_size: ResizeMode = "none"
    length_rules: tuple[LengthPositionRule, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class SchemeProfile:
    key: str
    display_name: str
    template_fund_name: str
    fund_object: str
    slides_per_fund: int
    fund_details: FundDetailsFormatting
    static_text_replacements: dict[str, str] = field(default_factory=dict)
    global_text_replacements: dict[str, str] = field(default_factory=dict)
    strict_slide_count: bool = True


SCHEME_PROFILES: dict[str, SchemeProfile] = {
    "axis_equity": SchemeProfile(
        key="axis_equity", display_name="Axis Mutual Fund - Equity",
        template_fund_name="Axis Large Cap Fund", fund_object="FundDetails",
        slides_per_fund=3,
        fund_details=FundDetailsFormatting(
            text_case="upper", color_mode="split_first_word",
            font_name="Arial", bold=True, alignment=PP_ALIGN_LEFT,
            word_wrap=True, auto_size="none",
            length_rules=(
                LengthPositionRule(character_limit=50, top_shift_cm=-0.2),
                LengthPositionRule(character_limit=70, top_shift_cm=-0.3, font_size=15),
            ),
        ),
    ),
    "axis_debt": SchemeProfile(
        key="axis_debt", display_name="Axis Mutual Fund - Debt",
        template_fund_name="Axis Liquid Fund", fund_object="FundDetails",
        slides_per_fund=4,
        fund_details=FundDetailsFormatting(
            text_case="upper", color_mode="split_first_word",
            font_name="Arial", bold=True, alignment=PP_ALIGN_LEFT,
            word_wrap=True, auto_size="shrink_to_fit",
            length_rules=(
                LengthPositionRule(character_limit=48, top_shift_cm=-0.15, font_size=15),
                LengthPositionRule(character_limit=68, top_shift_cm=-0.25, font_size=13),
            ),
        ),
    ),
    "axis_hybrid": SchemeProfile(
        key="axis_hybrid", display_name="Axis Mutual Fund - Hybrid",
        template_fund_name="Axis Multi Asset Allocation Fund",
        fund_object="FundDetails", slides_per_fund=4,
        fund_details=FundDetailsFormatting(
            text_case="upper", color_mode="split_first_word",
            font_name="Arial", bold=True, alignment=PP_ALIGN_LEFT,
            word_wrap=True, auto_size="shrink_to_fit",
            length_rules=(
                LengthPositionRule(character_limit=52, top_shift_cm=-0.15, font_size=14),
                LengthPositionRule(character_limit=72, top_shift_cm=-0.25, font_size=12),
            ),
        ),
    ),
    "hsbc": SchemeProfile(
        key="hsbc", display_name="HSBC Mutual Fund",
        template_fund_name="HSBC Large Cap Fund", fund_object="FundDetails",
        slides_per_fund=1,
        fund_details=FundDetailsFormatting(
            text_case="upper", color_mode="uniform", uniform_rgb=0x1F4E79,
            font_name="Arial", bold=True, alignment=PP_ALIGN_LEFT,
            word_wrap=True, auto_size="shrink_to_fit",
            length_rules=(
                LengthPositionRule(character_limit=48, top_shift_cm=-0.15, font_size=15),
                LengthPositionRule(character_limit=65, top_shift_cm=-0.25, font_size=13),
            ),
        ),
        global_text_replacements={"{{AMC_NAME}}": "HSBC MUTUAL FUND"},
    ),
    "nippon": SchemeProfile(
        key="nippon", display_name="Nippon India Mutual Fund",
        template_fund_name="Nippon India Large Cap Fund", fund_object="FundDetails",
        slides_per_fund=1,
        fund_details=FundDetailsFormatting(
            text_case="upper", color_mode="preserve", font_name="Arial",
            bold=True, alignment=PP_ALIGN_CENTER, word_wrap=True,
            auto_size="shrink_to_fit",
            length_rules=(
                LengthPositionRule(character_limit=52, top_shift_cm=-0.15, font_size=15),
                LengthPositionRule(character_limit=72, top_shift_cm=-0.25, font_size=13),
            ),
        ),
        global_text_replacements={"{{AMC_NAME}}": "NIPPON INDIA MUTUAL FUND"},
    ),
    "navi": SchemeProfile(
        key="navi", display_name="Navi Mutual Fund",
        template_fund_name="Navi Nifty 50 Index Fund", fund_object="FundDetails",
        slides_per_fund=1,
        fund_details=FundDetailsFormatting(
            text_case="title", color_mode="uniform", uniform_rgb=0x008C95,
            font_name="Arial", bold=False, alignment=PP_ALIGN_CENTER,
            word_wrap=True, auto_size="shrink_to_fit",
            length_rules=(
                LengthPositionRule(character_limit=45, top_shift_cm=-0.1, font_size=15),
                LengthPositionRule(character_limit=62, top_shift_cm=-0.2, font_size=13),
            ),
        ),
        global_text_replacements={"{{AMC_NAME}}": "Navi Mutual Fund"},
    ),
    "quantum": SchemeProfile(
        key="quantum", display_name="Quantum Mutual Fund",
        template_fund_name="Quantum Long Term Equity Value Fund",
        fund_object="FundDetails", slides_per_fund=1,
        fund_details=FundDetailsFormatting(
            text_case="upper", color_mode="uniform", uniform_rgb=0x7030A0,
            font_name="Arial", bold=True, alignment=PP_ALIGN_RIGHT,
            word_wrap=True, auto_size="shrink_to_fit",
            length_rules=(
                LengthPositionRule(character_limit=55, top_shift_cm=-0.15, font_size=14),
                LengthPositionRule(character_limit=75, top_shift_cm=-0.25, font_size=12),
            ),
        ),
        global_text_replacements={"{{AMC_NAME}}": "QUANTUM MUTUAL FUND"},
    ),
}


def _emit_progress(callback: ProgressCallback | None, percent: int, stage: str, message: str) -> None:
    if callback is not None:
        callback(min(100, max(1, int(percent))), stage, message)


def _normalize_profile_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value).casefold())


def get_scheme_profile(amc_name: str) -> SchemeProfile:
    aliases = {
        "axis": "axis_equity", "axismutualfund": "axis_equity",
        "axisequity": "axis_equity", "axismutualfundequity": "axis_equity",
        "axisdebt": "axis_debt", "axismutualfunddebt": "axis_debt",
        "axishybrid": "axis_hybrid", "axismutualfundhybrid": "axis_hybrid",
        "hsbc": "hsbc", "hsbcmutualfund": "hsbc",
        "nippon": "nippon", "nipponindia": "nippon", "nipponindiamutualfund": "nippon",
        "navi": "navi", "navimutualfund": "navi",
        "quantum": "quantum", "quantummutualfund": "quantum",
    }
    key = aliases.get(_normalize_profile_key(amc_name))
    if key is None:
        raise ValueError(f"Unsupported AMC selection: {amc_name!r}.")
    return SCHEME_PROFILES[key]


def get_available_scheme_profiles() -> list[dict[str, str]]:
    return [
        {"value": "axis", "label": "Axis Mutual Fund"},
        {"value": "hsbc", "label": SCHEME_PROFILES["hsbc"].display_name},
        {"value": "nippon", "label": SCHEME_PROFILES["nippon"].display_name},
        {"value": "navi", "label": SCHEME_PROFILES["navi"].display_name},
        {"value": "quantum", "label": SCHEME_PROFILES["quantum"].display_name},
    ]


def get_axis_categories() -> list[dict[str, str]]:
    return [
        {"value": "equity", "label": "Equity"},
        {"value": "debt", "label": "Debt"},
        {"value": "hybrid", "label": "Hybrid"},
    ]


def resolve_profile_key(selected_amc: str, selected_category: str | None = None) -> str:
    amc_key = _normalize_profile_key(selected_amc)
    if amc_key in {"axis", "axismutualfund"}:
        category = _normalize_profile_key(selected_category or "")
        if category not in {"equity", "debt", "hybrid"}:
            raise ValueError("Select an Axis category: Equity, Debt, or Hybrid.")
        return f"axis_{category}"
    return get_scheme_profile(selected_amc).key


def _unique_headers(values: list[object]) -> list[str]:
    seen: dict[str, int] = {}
    result: list[str] = []
    for index, value in enumerate(values, start=1):
        base = str(value or "").strip() or f"Column_{index}"
        seen[base] = seen.get(base, 0) + 1
        result.append(base if seen[base] == 1 else f"{base}_{seen[base]}")
    return result


def read_fund_names(excel_bytes: bytes, sheet_name: str, fund_column: str, logger) -> pd.DataFrame:
    if not excel_bytes:
        raise ValueError("A non-empty Excel file is required.")
    workbook = load_workbook(io.BytesIO(excel_bytes), data_only=True, read_only=True)
    try:
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"Sheet '{sheet_name}' was not found.")
        rows = [list(row) for row in workbook[sheet_name].iter_rows(values_only=True)]
        header_index = next(
            (i for i, row in enumerate(rows) if any(normalize(v) == normalize(fund_column) for v in row)),
            None,
        )
        if header_index is None:
            raise ValueError(f"Column '{fund_column}' was not found in sheet '{sheet_name}'.")
        headers = _unique_headers(rows[header_index])
        data_rows = []
        for row in rows[header_index + 1:]:
            current = list(row) + [None] * max(0, len(headers) - len(row))
            data_rows.append(current[:len(headers)])
        data = pd.DataFrame(data_rows, columns=headers)
        actual = next(c for c in data.columns if normalize(c) == normalize(fund_column))
        data = data[data[actual].fillna("").astype(str).str.strip().ne("")].copy()
        data.rename(columns={actual: fund_column}, inplace=True)
        data[fund_column] = data[fund_column].astype(str).map(lambda value: " ".join(value.split()))
        normalized = data[fund_column].map(normalize)
        if normalized.duplicated(keep=False).any():
            duplicates = data.loc[normalized.duplicated(keep=False), fund_column].drop_duplicates().tolist()
            raise ValueError("Duplicate fund names: " + ", ".join(duplicates))
        data.reset_index(drop=True, inplace=True)
        logger.info("FUND_FILE_COMPLETE | funds=%s", len(data))
        return data
    finally:
        workbook.close()


def _format_fund_name(value: object, text_case: TextCase) -> str:
    cleaned = " ".join(str(value or "").split())
    return {
        "upper": cleaned.upper(),
        "lower": cleaned.lower(),
        "title": cleaned.title(),
        "preserve": cleaned,
    }[text_case]


def _find_case_insensitive(text: str, search_text: str) -> int:
    return text.casefold().find(search_text.casefold())


def _safe(getter: Callable[[], Any], fallback: Any = None) -> Any:
    try:
        return getter()
    except Exception:
        return fallback


def _set_font_boolean(font, name: str, value: bool) -> None:
    setattr(font, name, -1 if value else 0)


def _capture_text_style(text_range) -> dict[str, Any]:
    """Capture text and paragraph formatting from a PowerPoint text range."""
    style: dict[str, Any] = {}
    font = text_range.Font

    for key, getter in {
        "font_name": lambda: font.Name,
        "font_size": lambda: font.Size,
        "bold": lambda: font.Bold,
        "italic": lambda: font.Italic,
        "underline": lambda: font.Underline,
        "color_rgb": lambda: font.Color.RGB,
        "alignment": lambda: text_range.ParagraphFormat.Alignment,
        "baseline_offset": lambda: font.BaselineOffset,
        "character_spacing": lambda: font.Spacing,
    }.items():
        value = _safe(getter)
        if value is not None:
            style[key] = value

    return style


def _apply_captured_text_style(
    text_range,
    style: dict[str, Any],
) -> None:
    """Apply captured formatting without failing on unsupported properties."""
    font = text_range.Font
    assignments = (
        ("Name", style.get("font_name")),
        ("Size", style.get("font_size")),
        ("Bold", style.get("bold")),
        ("Italic", style.get("italic")),
        ("Underline", style.get("underline")),
        ("BaselineOffset", style.get("baseline_offset")),
        ("Spacing", style.get("character_spacing")),
    )
    for property_name, value in assignments:
        if value is None:
            continue
        try:
            setattr(font, property_name, value)
        except Exception:
            pass

    if style.get("color_rgb") is not None:
        try:
            font.Color.RGB = style["color_rgb"]
        except Exception:
            pass

    if style.get("alignment") is not None:
        try:
            text_range.ParagraphFormat.Alignment = style["alignment"]
        except Exception:
            pass


def _capture_shape_frame_settings(shape) -> list[dict[str, Any]]:
    """Capture WordWrap and AutoSize for every FundDetails text frame."""
    settings: list[dict[str, Any]] = []
    for frame in _frames(shape):
        settings.append(
            {
                "frame": frame,
                "word_wrap": _safe(lambda frame=frame: frame.WordWrap),
                "auto_size": _safe(lambda frame=frame: frame.AutoSize),
                "margin_left": _safe(lambda frame=frame: frame.MarginLeft),
                "margin_right": _safe(lambda frame=frame: frame.MarginRight),
                "margin_top": _safe(lambda frame=frame: frame.MarginTop),
                "margin_bottom": _safe(lambda frame=frame: frame.MarginBottom),
                "vertical_anchor": _safe(
                    lambda frame=frame: frame.VerticalAnchor
                ),
            }
        )
    return settings


def _restore_shape_frame_settings(
    settings: list[dict[str, Any]],
) -> None:
    """Restore text-frame behavior and margins from the template."""
    property_map = {
        "word_wrap": "WordWrap",
        "auto_size": "AutoSize",
        "margin_left": "MarginLeft",
        "margin_right": "MarginRight",
        "margin_top": "MarginTop",
        "margin_bottom": "MarginBottom",
        "vertical_anchor": "VerticalAnchor",
    }
    for item in settings:
        frame = item["frame"]
        for key, property_name in property_map.items():
            value = item.get(key)
            if value is None:
                continue
            try:
                setattr(frame, property_name, value)
            except Exception:
                pass


def _capture_template_name_styles(
    text_range,
    start: int,
    old_name: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Capture first-word and remaining-text styles from the template name."""
    first_length = len(old_name.split(maxsplit=1)[0])
    first_style = _capture_text_style(
        text_range.Characters(start, max(first_length, 1))
    )

    remainder_offset = first_length
    while (
        remainder_offset < len(old_name)
        and old_name[remainder_offset].isspace()
    ):
        remainder_offset += 1

    if remainder_offset < len(old_name):
        remainder_style = _capture_text_style(
            text_range.Characters(
                start + remainder_offset,
                max(1, len(old_name) - remainder_offset),
            )
        )
    else:
        remainder_style = dict(first_style)

    return first_style, remainder_style


def _apply_preserved_name_styles(
    text_range,
    start: int,
    new_name: str,
    first_style: dict[str, Any],
    remainder_style: dict[str, Any],
) -> None:
    """Preserve different template formatting for first and later words."""
    new_range = text_range.Characters(start, len(new_name))
    _apply_captured_text_style(new_range, remainder_style)

    first_length = len(new_name.split(maxsplit=1)[0])
    if first_length:
        _apply_captured_text_style(
            text_range.Characters(start, first_length),
            first_style,
        )


def _capture_split_colors(text_range, start: int, old_name: str) -> tuple[int | None, int | None]:
    first_length = len(old_name.split(maxsplit=1)[0])
    first = _safe(lambda: int(text_range.Characters(start, max(first_length, 1)).Font.Color.RGB))
    offset = first_length
    while offset < len(old_name) and old_name[offset].isspace():
        offset += 1
    remainder = _safe(lambda: int(text_range.Characters(start + offset, 1).Font.Color.RGB), first)
    return first, remainder


def _apply_font(text_range, formatting: FundDetailsFormatting) -> None:
    font = text_range.Font
    if formatting.font_name is not None:
        font.Name = formatting.font_name
    if formatting.font_size is not None:
        font.Size = formatting.font_size
    if formatting.bold is not None:
        _set_font_boolean(font, "Bold", formatting.bold)
    if formatting.italic is not None:
        _set_font_boolean(font, "Italic", formatting.italic)
    if formatting.alignment is not None:
        text_range.ParagraphFormat.Alignment = formatting.alignment


def _replace_range(
    text_range,
    old_name: str,
    new_name: str,
    formatting: FundDetailsFormatting,
) -> int:
    """
    Replace each occurrence once and always advance beyond inserted text.

    The earlier implementation searched from the beginning after every
    replacement. When the selected fund was the template fund itself, for
    example Axis Large Cap Fund, the case-insensitive search found the newly
    inserted name again and looped forever. A forward-only cursor prevents
    that condition while still supporting more than one occurrence.
    """
    changed = 0
    search_from = 0
    old_key = old_name.casefold()

    while True:
        current_text = str(text_range.Text or "")
        zero = current_text.casefold().find(old_key, search_from)
        if zero < 0:
            break

        start = zero + 1
        template_first_style, template_remainder_style = (
            _capture_template_name_styles(
                text_range,
                start,
                old_name,
            )
        )
        first = remainder = None
        if formatting.color_mode == "split_first_word":
            first, remainder = _capture_split_colors(
                text_range,
                start,
                old_name,
            )
            first = (
                formatting.first_word_rgb
                if formatting.first_word_rgb is not None
                else first
            )
            remainder = (
                formatting.remainder_rgb
                if formatting.remainder_rgb is not None
                else remainder
            )

        text_range.Characters(start, len(old_name)).Text = new_name
        new_range = text_range.Characters(start, len(new_name))

        # Reapply the template's first-word and remainder formatting before
        # profile overrides. This preserves color splits, font, size, bold,
        # italic, underline, and alignment even when the new name is longer.
        _apply_preserved_name_styles(
            text_range,
            start,
            new_name,
            template_first_style,
            template_remainder_style,
        )

        if (
            formatting.color_mode == "uniform"
            and formatting.uniform_rgb is not None
        ):
            new_range.Font.Color.RGB = formatting.uniform_rgb
        elif formatting.color_mode == "split_first_word":
            if remainder is not None:
                new_range.Font.Color.RGB = remainder
            first_length = len(new_name.split(maxsplit=1)[0])
            if first is not None and first_length:
                text_range.Characters(
                    start,
                    first_length,
                ).Font.Color.RGB = first

        _apply_font(new_range, formatting)
        changed += 1

        # Continue after the inserted value, even when old_name and new_name
        # are identical after case normalization.
        search_from = zero + max(len(new_name), 1)

    return changed


def _replace_in_funddetails(shape, old_name: str, new_name: str, formatting: FundDetailsFormatting) -> int:
    old_clean = " ".join(old_name.split())
    changed = 0
    if bool(shape.HasTable):
        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell = table.Cell(row, column).Shape
                if bool(cell.HasTextFrame) and bool(cell.TextFrame.HasText):
                    changed += _replace_range(cell.TextFrame.TextRange, old_clean, new_name, formatting)
    elif bool(shape.HasTextFrame) and bool(shape.TextFrame.HasText):
        changed += _replace_range(shape.TextFrame.TextRange, old_clean, new_name, formatting)
    return changed


def _frames(shape) -> list[Any]:
    result = []
    if bool(shape.HasTable):
        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell = table.Cell(row, column).Shape
                if bool(cell.HasTextFrame):
                    result.append(cell.TextFrame)
    elif bool(shape.HasTextFrame):
        result.append(shape.TextFrame)
    return result


def _apply_text_frame_settings(shape, formatting: FundDetailsFormatting) -> None:
    for frame in _frames(shape):
        if formatting.word_wrap is not None:
            desired = -1 if formatting.word_wrap else 0
            if _safe(lambda: frame.WordWrap) != desired:
                frame.WordWrap = desired
        desired_auto = 2 if formatting.auto_size == "shrink_to_fit" else 0
        if _safe(lambda: frame.AutoSize) != desired_auto:
            frame.AutoSize = desired_auto


def _set_shape_font_size(shape, size: float) -> None:
    for frame in _frames(shape):
        if bool(frame.HasText):
            frame.TextRange.Font.Size = size


def _apply_length_formatting(shape, fund_name: str, formatting: FundDetailsFormatting) -> LengthPositionRule | None:
    matches = [rule for rule in formatting.length_rules if len(fund_name) > rule.character_limit]
    if not matches:
        return None
    rule = max(matches, key=lambda item: item.character_limit)
    if rule.top_shift_cm:
        shape.Top = shape.Top + rule.top_shift_cm * POINTS_PER_CM
    if rule.left_shift_cm:
        shape.Left = shape.Left + rule.left_shift_cm * POINTS_PER_CM
    if rule.width_adjustment_cm:
        new_width = (
            shape.Width
            + rule.width_adjustment_cm * POINTS_PER_CM
        )
        if new_width <= 0:
            raise ValueError(
                "A length rule attempted to set a non-positive width."
            )
        shape.Width = new_width
    if rule.height_adjustment_cm:
        new_height = (
            shape.Height
            + rule.height_adjustment_cm * POINTS_PER_CM
        )
        if new_height <= 0:
            raise ValueError(
                "A length rule attempted to set a non-positive height."
            )
        shape.Height = new_height
    if rule.font_size is not None:
        _set_shape_font_size(shape, rule.font_size)
    return rule


def _replace_plain(text_range, replacements: dict[str, str]) -> int:
    changed = 0
    for old, new in replacements.items():
        while old and (zero := _find_case_insensitive(str(text_range.Text or ""), old)) >= 0:
            text_range.Characters(zero + 1, len(old)).Text = str(new)
            changed += 1
    return changed


def _replace_shape_recursive(shape, replacements: dict[str, str]) -> int:
    changed = 0
    if int(shape.Type) == 6:
        for index in range(1, shape.GroupItems.Count + 1):
            changed += _replace_shape_recursive(shape.GroupItems.Item(index), replacements)
    elif bool(shape.HasTable):
        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell = table.Cell(row, column).Shape
                if bool(cell.HasTextFrame) and bool(cell.TextFrame.HasText):
                    changed += _replace_plain(cell.TextFrame.TextRange, replacements)
    elif bool(shape.HasTextFrame) and bool(shape.TextFrame.HasText):
        changed += _replace_plain(shape.TextFrame.TextRange, replacements)
    return changed


def _apply_global(slide, replacements: dict[str, str]) -> int:
    if not replacements:
        return 0
    return sum(_replace_shape_recursive(slide.Shapes.Item(i), replacements) for i in range(1, slide.Shapes.Count + 1))


def _set_complete_text(shape, value: str) -> int:
    changed = 0
    if bool(shape.HasTable):
        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                table.Cell(row, column).Shape.TextFrame.TextRange.Text = value
                changed += 1
    elif bool(shape.HasTextFrame):
        shape.TextFrame.TextRange.Text = value
        changed += 1
    return changed


def _apply_static(slide, replacements: dict[str, str], slide_number: int) -> int:
    changed = 0
    for shape_name, text in replacements.items():
        shape = find_shape_recursive(slide.Shapes, shape_name)
        if shape is None:
            raise ValueError(f"Configured object '{shape_name}' is missing on slide {slide_number}.")
        changed += _set_complete_text(shape, text)
    return changed


def _validate_selected_funds(selected_funds: pd.DataFrame, fund_column: str) -> pd.DataFrame:
    if selected_funds is None or selected_funds.empty:
        raise ValueError("Select at least one scheme.")
    if fund_column not in selected_funds.columns:
        raise ValueError(f"Fund column '{fund_column}' does not exist.")
    cleaned = selected_funds.copy()
    cleaned[fund_column] = cleaned[fund_column].fillna("").astype(str).map(lambda value: " ".join(value.split()))
    cleaned = cleaned[cleaned[fund_column].ne("")].reset_index(drop=True)
    normalized = cleaned[fund_column].map(normalize)
    if normalized.duplicated(keep=False).any():
        raise ValueError("Duplicate selected fund names were found.")
    return cleaned


def _com_code(error: Exception) -> int | None:
    return getattr(error, "hresult", error.args[0] if error.args and isinstance(error.args[0], int) else None)


def _retry_com(name: str, operation, logger, attempts: int = COM_RETRY_ATTEMPTS):
    delay = 0.75
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            if _com_code(error) not in {RPC_E_CALL_REJECTED, RPC_E_SERVERCALL_RETRYLATER} or attempt == attempts:
                raise
            logger.warning("SCHEME_COM_RETRY | operation=%s | attempt=%s/%s | wait=%.2f", name, attempt, attempts, delay)
            time.sleep(delay)
            delay = min(4.0, delay * 1.7)


def _duplicate_template_block_fast(
    presentation,
    template_numbers: list[int],
    logger,
):
    """
    Duplicate the template slide range without using the Windows clipboard.

    PowerPoint Copy/Paste becomes progressively slower for presentations with
    many slides and can wait on the Office clipboard. SlideRange.Duplicate is
    native to the presentation and is normally much faster. Copy/Paste remains
    a compatibility fallback for PowerPoint builds that reject Duplicate.
    """
    before = presentation.Slides.Count
    try:
        duplicated = presentation.Slides.Range(template_numbers).Duplicate()
        try:
            duplicated.MoveTo(presentation.Slides.Count)
        except Exception:
            # Duplicate may already be positioned at the end in some builds.
            pass
        after = presentation.Slides.Count
        logger.info(
            "SCHEME_BLOCK_DUPLICATED | method=native_duplicate | "
            "before=%s | after=%s",
            before,
            after,
        )
        return duplicated
    except Exception:
        logger.warning(
            "SCHEME_NATIVE_DUPLICATE_FAILED | fallback=copy_paste",
            exc_info=True,
        )
        slide_range = presentation.Slides.Range(template_numbers)
        slide_range.Copy()
        pasted = presentation.Slides.Paste(presentation.Slides.Count + 1)
        after = presentation.Slides.Count
        logger.info(
            "SCHEME_BLOCK_DUPLICATED | method=copy_paste | "
            "before=%s | after=%s",
            before,
            after,
        )
        return pasted


def create_scheme_presentation(
    template_bytes: bytes,
    selected_funds: pd.DataFrame,
    fund_column: str,
    selected_amc: str,
    logger,
    *,
    selected_category: str | None = None,
    profile_overrides: SchemeProfile | None = None,
    progress_callback: ProgressCallback | None = None,
) -> bytes:
    """Create profile-formatted scheme slides with real stage progress."""
    _emit_progress(progress_callback, 1, "Validating inputs", "Checking template and selected funds")
    if not template_bytes:
        raise ValueError("A non-empty PowerPoint template is required.")
    profile = profile_overrides or SCHEME_PROFILES[resolve_profile_key(selected_amc, selected_category)]
    funds = _validate_selected_funds(selected_funds, fund_column)
    fund_count = len(funds)
    expected_slides = fund_count * profile.slides_per_fund
    _emit_progress(progress_callback, 4, "Inputs validated", f"Validated {fund_count} fund(s)")
    operation_start = perf_counter()
    logger.info(
        "SCHEME_CREATION_START | profile=%s | funds=%s | "
        "expected_slides=%s",
        profile.key,
        fund_count,
        expected_slides,
    )

    pythoncom.CoInitialize()
    powerpoint = presentation = None
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            template_path = Path(temp_dir) / f"{profile.key}_template.pptx"
            output_path = Path(temp_dir) / f"{profile.key}_output.pptx"
            template_path.write_bytes(template_bytes)
            _emit_progress(progress_callback, 7, "Preparing template", "Template copied to the working directory")
            _emit_progress(progress_callback, 10, "Starting PowerPoint", "Starting Microsoft PowerPoint automation")
            stage_start = perf_counter()
            powerpoint = _retry_com(
                "start PowerPoint",
                lambda: win32com.client.DispatchEx("PowerPoint.Application"),
                logger,
            )
            logger.info(
                "SCHEME_TIMING | stage=powerpoint_started | seconds=%.3f",
                perf_counter() - stage_start,
            )
            _retry_com("set DisplayAlerts", lambda: setattr(powerpoint, "DisplayAlerts", False), logger)
            _emit_progress(progress_callback, 13, "PowerPoint started", "PowerPoint automation is ready")
            _emit_progress(progress_callback, 15, "Opening template", "Opening the presentation without a window")
            stage_start = perf_counter()
            presentation = _retry_com(
                "open template",
                lambda: powerpoint.Presentations.Open(str(template_path.resolve()), False, False, False),
                logger,
            )
            logger.info(
                "SCHEME_TIMING | stage=template_opened | seconds=%.3f",
                perf_counter() - stage_start,
            )
            actual = presentation.Slides.Count
            _emit_progress(progress_callback, 17, "Template opened", f"Template contains {actual} slide(s)")
            if profile.strict_slide_count and actual != profile.slides_per_fund:
                raise ValueError(f"Template must contain exactly {profile.slides_per_fund} slide(s); found {actual}.")
            if actual < profile.slides_per_fund:
                raise ValueError(f"Template contains {actual} slides; at least {profile.slides_per_fund} required.")

            template_numbers = list(
                range(1, profile.slides_per_fund + 1)
            )
            copy_total = max(0, fund_count - 1)
            duplicate_start = perf_counter()

            if copy_total == 0:
                _emit_progress(
                    progress_callback,
                    45,
                    "Copying slide blocks",
                    "No additional slide block is needed",
                )

            last_reported_percent = 17
            for block in range(2, fund_count + 1):
                duplicated = _retry_com(
                    f"duplicate slide block {block - 1}",
                    lambda: _duplicate_template_block_fast(
                        presentation,
                        template_numbers,
                        logger,
                    ),
                    logger,
                    attempts=4,
                )
                duplicated = None
                copied = block - 1
                percent = 18 + round(27 * copied / copy_total)

                # Avoid excessive Streamlit rerenders when many funds are
                # selected. Report only when the displayed percentage changes.
                if percent > last_reported_percent:
                    _emit_progress(
                        progress_callback,
                        percent,
                        "Copying slide blocks",
                        (
                            f"Copied block {copied} of {copy_total}; "
                            f"{presentation.Slides.Count} slides ready"
                        ),
                    )
                    last_reported_percent = percent

            logger.info(
                "SCHEME_TIMING | stage=slide_blocks_duplicated | "
                "blocks=%s | seconds=%.3f",
                copy_total,
                perf_counter() - duplicate_start,
            )

            if presentation.Slides.Count != expected_slides:
                raise RuntimeError(f"Expected {expected_slides} slides; found {presentation.Slides.Count}.")

            total_fund = total_global = total_static = 0
            update_start = perf_counter()
            _emit_progress(
                progress_callback,
                46,
                "Updating funds",
                f"Updating {fund_count} fund(s) across {expected_slides} slides",
            )
            last_fund_percent = 45
            for fund_index, (_, row) in enumerate(
                funds.iterrows(),
                start=1,
            ):
                formatted = _format_fund_name(
                    row[fund_column],
                    profile.fund_details.text_case,
                )
                fund_update_start = perf_counter()
                logger.info(
                    "SCHEME_FUND_UPDATE_START | index=%s/%s | fund=%s",
                    fund_index,
                    fund_count,
                    formatted,
                )
                first_slide = (fund_index - 1) * profile.slides_per_fund + 1
                last_slide = first_slide + profile.slides_per_fund - 1
                for slide_number in range(first_slide, last_slide + 1):
                    slide = presentation.Slides.Item(slide_number)
                    shape = find_shape_recursive(slide.Shapes, profile.fund_object)
                    if shape is None:
                        raise ValueError(f"Object '{profile.fund_object}' missing on slide {slide_number}.")
                    frame_settings = _capture_shape_frame_settings(shape)
                    fund_changes = _replace_in_funddetails(
                        shape,
                        profile.template_fund_name,
                        formatted,
                        profile.fund_details,
                    )
                    if fund_changes == 0:
                        raise ValueError(
                            f"Template text '{profile.template_fund_name}' "
                            f"not found on slide {slide_number}."
                        )

                    # Restore the template's wrapping, auto-size, margins, and
                    # vertical alignment. The latest app passes None / none for
                    # all visual overrides, so no template setting is changed.
                    _restore_shape_frame_settings(frame_settings)

                    # Apply text-frame overrides only when explicitly supplied
                    # by a non-preserve profile.
                    if (
                        profile.fund_details.word_wrap is not None
                        or profile.fund_details.auto_size != "none"
                    ):
                        _apply_text_frame_settings(
                            shape,
                            profile.fund_details,
                        )
                    rule = _apply_length_formatting(shape, formatted, profile.fund_details)
                    if rule:
                        logger.info("LENGTH_RULE_APPLIED | slide=%s | fund=%s | limit=%s", slide_number, formatted, rule.character_limit)
                    global_changes = _apply_global(slide, profile.global_text_replacements) if profile.global_text_replacements else 0
                    static_changes = _apply_static(slide, profile.static_text_replacements, slide_number) if profile.static_text_replacements else 0
                    total_fund += fund_changes
                    total_global += global_changes
                    total_static += static_changes
                    shape = slide = None
                logger.info(
                    "SCHEME_FUND_UPDATE_COMPLETE | index=%s/%s | fund=%s | "
                    "slides=%s-%s | seconds=%.3f",
                    fund_index,
                    fund_count,
                    formatted,
                    first_slide,
                    last_slide,
                    perf_counter() - fund_update_start,
                )
                percent = 46 + round(44 * fund_index / fund_count)
                if percent > last_fund_percent or fund_index == fund_count:
                    _emit_progress(
                        progress_callback,
                        percent,
                        "Updating funds",
                        (
                            f"Updated fund {fund_index} of {fund_count}: "
                            f"{formatted} | slides {first_slide}-{last_slide}"
                        ),
                    )
                    last_fund_percent = percent

            logger.info(
                "SCHEME_TIMING | stage=funds_updated | funds=%s | "
                "slides=%s | seconds=%.3f",
                fund_count,
                expected_slides,
                perf_counter() - update_start,
            )

            _emit_progress(
                progress_callback,
                92,
                "Saving presentation",
                f"Saving {expected_slides} completed slides",
            )
            save_start = perf_counter()
            _retry_com(
                "save presentation",
                lambda: presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            logger.info(
                "SCHEME_TIMING | stage=presentation_saved | seconds=%.3f",
                perf_counter() - save_start,
            )
            _emit_progress(progress_callback, 96, "Presentation saved", "PowerPoint saved the output file")
            _retry_com("close presentation", presentation.Close, logger, attempts=4)
            presentation = None
            _emit_progress(progress_callback, 98, "Verifying output", "Checking the generated presentation file")
            if not output_path.exists():
                raise RuntimeError("PowerPoint did not create the output file.")
            output = output_path.read_bytes()
            if not output:
                raise RuntimeError("The generated presentation is empty.")
            logger.info(
                "SCHEME_CREATION_COMPLETE | profile=%s | funds=%s | "
                "slides=%s | bytes=%s | total_seconds=%.3f",
                profile.key,
                fund_count,
                expected_slides,
                len(output),
                perf_counter() - operation_start,
            )
            _emit_progress(progress_callback, 100, "Completed", f"Presentation ready: {fund_count} fund(s), {expected_slides} slide(s)")
            return output
    except Exception:
        logger.exception("SCHEME_CREATION_FAILED | selected_amc=%s", selected_amc)
        raise
    finally:
        if presentation is not None:
            try:
                _retry_com("cleanup close presentation", presentation.Close, logger, attempts=3)
            except Exception:
                pass
        if powerpoint is not None:
            try:
                _retry_com("quit PowerPoint", powerpoint.Quit, logger, attempts=3)
            except Exception:
                pass
        pythoncom.CoUninitialize()