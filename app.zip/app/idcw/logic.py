from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
POINTS_PER_CM = 72.0 / 2.54
IDCW_TABLE_WIDTH_CM = 18.79
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_GROUP = 6
MSO_AUTOSIZE_SHAPE_TO_FIT_TEXT = 1

SOURCE_FUND_OBJECT = "FundName"
SOURCE_TABLE_OBJECT = "IDCWTable"
SOURCE_NOTE_OBJECT = "IDCWNote"

TARGET_TABLE_OBJECT = "IDCWTable"
TARGET_BOX_OBJECT = "IDCWBox"
TARGET_NOTE_OBJECT = "IDCWNote"
TARGET_ICON_TEXT_BG_OBJECT = "IDCWIconTextBG"

IDCW_FIXED_OBJECT_NAMES = {"footertext"}

IDCW_FUND_ALIASES = {
    "Axis Childrens Fund": "Axis Children's Fund",
    "Axis Focused 25 Fund": "Axis Focused Fund",
}


@dataclass(frozen=True)
class IDCWRecord:
    source_fund_name: str
    canonical_fund_name: str
    table_values: tuple[tuple[str, ...], ...]
    note_text: str
    source_fund_slide: int
    source_table_slide: int


@dataclass(frozen=True)
class ShapeBounds:
    left: float
    top: float
    width: float
    height: float

    @property
    def right(self) -> float:
        return self.left + self.width

    @property
    def bottom(self) -> float:
        return self.top + self.height


@dataclass(frozen=True)
class SectionBounds:
    left: float
    top: float
    right: float
    bottom: float

    @property
    def height(self) -> float:
        return self.bottom - self.top


# -----------------------------------------------------------------------------
# Normalization
# -----------------------------------------------------------------------------


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
        "\r": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return "\n".join(" ".join(line.split()) for line in text.split("\n")).strip()


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    text = _clean_text(value).replace("\n", " ")
    for pattern in (
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
    ):
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base = _base_fund_name(value)
    aliases = {_text_key(k): v for k, v in IDCW_FUND_ALIASES.items()}
    return aliases.get(_text_key(base), base)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _is_valid_fund_name(value: object) -> bool:
    text = _clean_text(value).replace("\n", " ")
    key = _text_key(text)
    if not text or len(text) > 150:
        return False
    if any(token in key for token in (
        "http", "www", "riskometer", "forviewinglatest", "pleasereferwebsite"
    )):
        return False
    return "axis" in key and "fund" in key


# -----------------------------------------------------------------------------
# PowerPoint shape helpers
# -----------------------------------------------------------------------------


def _cell_text(table, row: int, column: int) -> str:
    try:
        cell = table.Cell(row, column).Shape
        if cell.HasTextFrame and cell.TextFrame.HasText:
            return _clean_text(cell.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                part = _shape_text(shape.GroupItems.Item(index))
                if part:
                    parts.append(part)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    parts.append(_cell_text(table, row, column))
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(str(shape.TextFrame.TextRange.Text or ""))
    except Exception:
        return ""
    return "\n".join(_clean_text(part) for part in parts if _clean_text(part))


def _iter_shapes_recursive(shapes):
    for index in range(1, shapes.Count + 1):
        try:
            shape = shapes.Item(index)
        except Exception:
            continue
        yield shape
        try:
            if int(shape.Type) == MSO_GROUP:
                yield from _iter_shapes_recursive(shape.GroupItems)
        except Exception:
            pass


def _iter_shapes_with_owner(slide):
    """Yield every shape together with its top-level deletable owner."""
    def walk(shape, owner):
        yield shape, owner
        try:
            if int(shape.Type) == MSO_GROUP:
                for child_index in range(1, shape.GroupItems.Count + 1):
                    child = shape.GroupItems.Item(child_index)
                    yield from walk(child, owner)
        except Exception:
            pass

    for index in range(1, slide.Shapes.Count + 1):
        try:
            owner = slide.Shapes.Item(index)
        except Exception:
            continue
        yield from walk(owner, owner)


def _shape_name_key(shape) -> str:
    try:
        return _text_key(shape.Name)
    except Exception:
        return ""


def _find_named_shape_with_owner(slide, object_name: str):
    wanted = _text_key(object_name)

    def walk(shape, owner):
        if _shape_name_key(shape) == wanted:
            return shape, owner
        try:
            if int(shape.Type) == MSO_GROUP:
                for index in range(1, shape.GroupItems.Count + 1):
                    result = walk(shape.GroupItems.Item(index), owner)
                    if result is not None:
                        return result
        except Exception:
            pass
        return None

    for index in range(1, slide.Shapes.Count + 1):
        try:
            owner = slide.Shapes.Item(index)
        except Exception:
            continue
        result = walk(owner, owner)
        if result is not None:
            return result
    return None, None


def _find_named_shape_robust(slide, object_name: str):
    shape, _ = _find_named_shape_with_owner(slide, object_name)
    if shape is not None:
        return shape
    return find_shape_recursive(slide.Shapes, object_name)


def _find_table_shape(shape):
    if shape is None:
        return None
    try:
        if shape.HasTable:
            return shape
    except Exception:
        pass
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                result = _find_table_shape(shape.GroupItems.Item(index))
                if result is not None:
                    return result
    except Exception:
        pass
    return None


def _find_fund_shape_by_content(slide):
    candidates = []
    for shape in _iter_shapes_recursive(slide.Shapes):
        try:
            if shape.HasTable:
                continue
        except Exception:
            pass
        text = _shape_text(shape)
        if _is_valid_fund_name(text):
            candidates.append((len(text), shape))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def _read_table_values(shape) -> tuple[tuple[str, ...], ...]:
    table_shape = _find_table_shape(shape)
    if table_shape is None:
        raise ValueError("IDCWTable does not contain a PowerPoint table.")
    table = table_shape.Table
    return tuple(
        tuple(_cell_text(table, row, column) for column in range(1, table.Columns.Count + 1))
        for row in range(1, table.Rows.Count + 1)
    )


# -----------------------------------------------------------------------------
# Source indexing
# -----------------------------------------------------------------------------


def _build_source_index(
    source_presentation,
    source_fund_object: str,
    source_table_object: str,
    source_note_object: str,
    logger,
) -> dict[str, IDCWRecord]:
    records: dict[str, IDCWRecord] = {}
    pending_fund_name = ""
    pending_fund_slide = 0

    for slide_number in range(1, source_presentation.Slides.Count + 1):
        pythoncom.PumpWaitingMessages()
        slide = source_presentation.Slides.Item(slide_number)

        fund_shape = _find_named_shape_robust(slide, source_fund_object)
        if fund_shape is None:
            fund_shape = _find_fund_shape_by_content(slide)
        current_fund = _shape_text(fund_shape) if fund_shape else ""
        if current_fund and not _is_valid_fund_name(current_fund):
            current_fund = ""

        table_wrapper = _find_named_shape_robust(slide, source_table_object)
        actual_table = _find_table_shape(table_wrapper)
        note_shape = _find_named_shape_robust(slide, source_note_object)

        if actual_table is None:
            if current_fund:
                pending_fund_name = current_fund
                pending_fund_slide = slide_number
                logger.info(
                    "IDCW_SOURCE_FUND_PENDING | slide=%s | fund=%s",
                    slide_number,
                    current_fund,
                )
            continue

        effective_fund = current_fund or pending_fund_name
        fund_slide = slide_number if current_fund else pending_fund_slide
        if not effective_fund:
            logger.warning(
                "IDCW_SOURCE_TABLE_UNASSIGNED | slide=%s | reason=no_fund",
                slide_number,
            )
            continue

        table_values = _read_table_values(table_wrapper)
        usable = any(any(cell for cell in row) for row in table_values)
        if not usable:
            pending_fund_name = ""
            pending_fund_slide = 0
            continue

        note_text = _shape_text(note_shape) if note_shape is not None else ""
        key = _fund_key(effective_fund)
        if key not in records:
            records[key] = IDCWRecord(
                source_fund_name=effective_fund,
                canonical_fund_name=_canonical_fund_name(effective_fund),
                table_values=table_values,
                note_text=note_text,
                source_fund_slide=fund_slide,
                source_table_slide=slide_number,
            )
            logger.info(
                "IDCW_SOURCE_FOUND | fund_slide=%s | table_slide=%s | "
                "fund=%s | rows=%s | columns=%s | note=%s",
                fund_slide,
                slide_number,
                _canonical_fund_name(effective_fund),
                len(table_values),
                len(table_values[0]) if table_values else 0,
                bool(note_text),
            )

        pending_fund_name = ""
        pending_fund_slide = 0

    logger.info("IDCW_SOURCE_INDEX_COMPLETE | funds=%s", len(records))
    if not records:
        raise ValueError(
            "No usable source IDCWTable objects were found. Processing stopped "
            "before the target presentation was modified."
        )
    return records


# -----------------------------------------------------------------------------
# Target table, note, and box layout
# -----------------------------------------------------------------------------


def _set_cell_text_preserve_format(cell_shape, value: str) -> None:
    """Replace cell text directly while retaining the target cell formatting."""
    if not cell_shape.HasTextFrame:
        raise ValueError("An IDCW target cell does not support text.")
    cell_shape.TextFrame.TextRange.Text = str(value)


def _resize_table_rows(table, required_rows: int) -> None:
    """Resize rows and preserve the target template's nearest row heights."""
    if required_rows < 1:
        raise ValueError("The source IDCW table contains no rows.")

    template_height = None
    if table.Rows.Count:
        try:
            template_height = float(table.Rows.Item(table.Rows.Count).Height)
        except Exception:
            pass

    while table.Rows.Count < required_rows:
        table.Rows.Add()
    while table.Rows.Count > required_rows:
        table.Rows.Item(table.Rows.Count).Delete()

    if template_height is not None:
        for row in range(1, table.Rows.Count + 1):
            try:
                table.Rows.Item(row).Height = template_height
            except Exception:
                pass


def _resize_table_columns(table, required_columns: int, logger=None) -> None:
    """
    Resize the target IDCW table to the source column count.

    PowerPoint carries formatting from adjacent target columns when a column is
    added. Deleting columns retains the formatting of the remaining target
    columns. This supports source layouts with Regular/Direct plans (10
    columns) and Regular/Retail/Direct plans (14 columns) without copying the
    source table's visual style.
    """
    if required_columns < 1:
        raise ValueError("The source IDCW table contains no columns.")

    original_columns = int(table.Columns.Count)
    while table.Columns.Count < required_columns:
        table.Columns.Add()
    while table.Columns.Count > required_columns:
        table.Columns.Item(table.Columns.Count).Delete()

    if logger is not None and original_columns != required_columns:
        logger.info(
            "IDCW_TARGET_COLUMNS_RESIZED | old_columns=%s | new_columns=%s",
            original_columns,
            required_columns,
        )


def _write_and_verify_cell(table, row: int, column: int, value: str) -> None:
    """Write a target cell and confirm PowerPoint retained the new value."""
    cell_shape = table.Cell(row, column).Shape
    _set_cell_text_preserve_format(cell_shape, value)
    actual = _cell_text(table, row, column)
    expected = _clean_text(value)
    if actual != expected:
        # Retry once using the full TextRange assignment after pumping COM.
        pythoncom.PumpWaitingMessages()
        cell_shape.TextFrame.TextRange.Text = str(value)
        actual = _cell_text(table, row, column)
        if actual != expected:
            raise ValueError(
                f"IDCW cell write verification failed at row {row}, column "
                f"{column}. Expected {expected!r}, retained {actual!r}."
            )


def _copy_table_values(target_wrapper, record: IDCWRecord, logger=None) -> int:
    """Reshape the target table, copy all source values, and verify the copy."""
    target_shape = _find_table_shape(target_wrapper)
    if target_shape is None:
        raise ValueError("Target IDCWTable does not contain a PowerPoint table.")

    if not record.table_values:
        raise ValueError("The source IDCWTable contains no rows.")

    required_rows = len(record.table_values)
    required_columns = max(len(row) for row in record.table_values)
    if any(len(row) != required_columns for row in record.table_values):
        raise ValueError("The source IDCWTable has inconsistent row widths.")

    table = target_shape.Table

    # Columns are resized before rows because deleting a merged plan block can
    # alter the table's row and merge structure in PowerPoint.
    _resize_table_columns(table, required_columns, logger)
    _resize_table_rows(table, required_rows)

    # The target factsheet layout requires a fixed IDCW table width. Set this
    # after changing columns because PowerPoint can change the table width when
    # columns are added or removed.
    target_shape.Width = IDCW_TABLE_WIDTH_CM * POINTS_PER_CM
    if logger is not None:
        logger.info(
            "IDCW_TARGET_WIDTH_SET | width_cm=%.2f | columns=%s",
            IDCW_TABLE_WIDTH_CM,
            required_columns,
        )

    changed = 0
    verification_failures: list[str] = []
    for row_index, row_values in enumerate(record.table_values, start=1):
        for column_index, value in enumerate(row_values, start=1):
            try:
                _write_and_verify_cell(
                    table,
                    row_index,
                    column_index,
                    value,
                )
                changed += 1
            except Exception as error:
                verification_failures.append(
                    f"r{row_index}c{column_index}: {error}"
                )

    if verification_failures:
        preview = "; ".join(verification_failures[:5])
        raise ValueError(
            f"IDCW table copy failed for {len(verification_failures)} cell(s): "
            f"{preview}"
        )

    # Perform a complete second pass after all writes, because merged-cell
    # recalculation can overwrite neighboring cells after later assignments.
    mismatches: list[str] = []
    for row_index, row_values in enumerate(record.table_values, start=1):
        for column_index, expected_value in enumerate(row_values, start=1):
            actual = _cell_text(table, row_index, column_index)
            expected = _clean_text(expected_value)
            if actual != expected:
                mismatches.append(
                    f"r{row_index}c{column_index} expected={expected!r} "
                    f"actual={actual!r}"
                )

    if mismatches:
        raise ValueError(
            "IDCW post-copy verification failed: " + "; ".join(mismatches[:5])
        )

    if logger is not None:
        logger.info(
            "IDCW_TABLE_COPY_VERIFIED | fund=%s | rows=%s | columns=%s | "
            "cells=%s",
            record.canonical_fund_name,
            required_rows,
            required_columns,
            changed,
        )
    return changed


def _set_note_text_and_fit(note_shape, note_text: str) -> None:
    if note_shape is None or not note_shape.HasTextFrame:
        raise ValueError("Target IDCWNote is missing or does not support text.")
    original_width = float(note_shape.Width)
    note_shape.TextFrame.TextRange.Text = note_text
    try:
        note_shape.TextFrame.AutoSize = MSO_AUTOSIZE_SHAPE_TO_FIT_TEXT
        note_shape.Width = original_width
    except Exception:
        pass


def _shape_bounds(shape) -> ShapeBounds:
    return ShapeBounds(
        left=float(shape.Left),
        top=float(shape.Top),
        width=float(shape.Width),
        height=float(shape.Height),
    )


def _section_bounds(shapes: list) -> SectionBounds:
    bounds = [_shape_bounds(shape) for shape in shapes]
    return SectionBounds(
        left=min(item.left for item in bounds),
        top=min(item.top for item in bounds),
        right=max(item.right for item in bounds),
        bottom=max(item.bottom for item in bounds),
    )


def _move_content_below_section(
    slide,
    original_section: SectionBounds,
    delta: float,
    excluded_ids: set[int],
    logger,
) -> int:
    if abs(delta) < 0.01:
        return 0
    moved = 0
    for index in range(1, slide.Shapes.Count + 1):
        shape = slide.Shapes.Item(index)
        try:
            if int(shape.Id) in excluded_ids:
                continue
        except Exception:
            pass
        if _shape_name_key(shape) in IDCW_FIXED_OBJECT_NAMES:
            continue
        bounds = _shape_bounds(shape)
        overlap = min(bounds.right, original_section.right) - max(
            bounds.left, original_section.left
        )
        if bounds.top >= original_section.bottom - 0.5 and overlap > 0:
            shape.Top = float(shape.Top) + delta
            moved += 1
    return moved


def _adjust_idcw_layout(
    slide,
    original_section: SectionBounds,
    table_shape,
    note_shape,
    box_shape,
    original_table_note_gap: float,
    original_note_box_padding: float,
    section_shapes: list,
    logger,
) -> tuple[int, float]:
    table_bottom = float(table_shape.Top + table_shape.Height)
    note_shape.Top = table_bottom + original_table_note_gap
    note_bottom = float(note_shape.Top + note_shape.Height)
    box_shape.Height = max(
        1.0,
        note_bottom + original_note_box_padding - float(box_shape.Top),
    )

    updated_section = _section_bounds(section_shapes)
    delta = updated_section.bottom - original_section.bottom
    excluded_ids = set()
    for shape in section_shapes:
        try:
            excluded_ids.add(int(shape.Id))
        except Exception:
            pass
    moved = _move_content_below_section(
        slide,
        original_section,
        delta,
        excluded_ids,
        logger,
    )
    logger.info(
        "IDCW_LAYOUT_UPDATED | slide=%s | delta_cm=%.3f | note_top_cm=%.3f | "
        "box_height_cm=%.3f",
        slide.SlideIndex,
        delta / POINTS_PER_CM,
        float(note_shape.Top) / POINTS_PER_CM,
        float(box_shape.Height) / POINTS_PER_CM,
    )
    return moved, delta


def _delete_idcw_section(
    slide,
    table_object: str,
    box_object: str,
    note_object: str,
    icon_text_bg_object: str,
    logger,
) -> int:
    """
    Delete the complete IDCW section, including a blank heading bar and icon.

    Some templates remove the heading text before this operation runs. In that
    case text matching cannot find the remaining purple bar. This function
    therefore captures IDCWBox geometry first and selects only shallow objects
    crossing the top edge of that exact box, plus one compact object at its
    upper-left corner. The lookup is local to IDCWBox and cannot reach PTC or
    Details of Exposure sections lower on the slide.
    """
    owners: dict[str, tuple[object, set[str]]] = {}

    def add_owner(owner, reason: str) -> None:
        if owner is None:
            return
        try:
            key = str(owner.Id)
        except Exception:
            key = f"{_shape_name_key(owner)}:{id(owner)}"
        if key not in owners:
            owners[key] = (owner, set())
        owners[key][1].add(reason)

    # Resolve the box first. Its original geometry is the safest anchor for a
    # heading whose text and Selection Pane name are both unavailable.
    box_match, box_owner = _find_named_shape_with_owner(slide, box_object)
    box_geometry = None
    if box_match is not None:
        try:
            box_geometry = (
                float(box_match.Left),
                float(box_match.Top),
                float(box_match.Width),
                float(box_match.Height),
            )
        except Exception:
            box_geometry = None

    # Resolve all explicitly configured objects and their top-level owners.
    exact_matches: dict[str, object] = {}
    for name in (
        table_object,
        box_object,
        note_object,
        icon_text_bg_object,
    ):
        matched, owner = _find_named_shape_with_owner(slide, name)
        if matched is None or owner is None:
            logger.info(
                "IDCW_OBJECT_NAME_NOT_FOUND | slide=%s | object=%s",
                slide.SlideIndex,
                name,
            )
            continue
        exact_matches[name] = matched
        add_owner(owner, name)

    # First semantic fallback for templates where the heading still has text.
    heading_tokens = (
        _text_key("INCOME DISTRIBUTION CUM CAPITAL WITHDRAWAL (IDCW)"),
        _text_key("INCOME DISTRIBUTION CUM CAPITAL WITHDRAWAL"),
    )
    semantic_heading_found = False
    for index in range(1, slide.Shapes.Count + 1):
        try:
            candidate = slide.Shapes.Item(index)
            visible_key = _text_key(_shape_text(candidate))
        except Exception:
            continue
        if any(token in visible_key for token in heading_tokens):
            add_owner(candidate, "idcw_heading_text")
            semantic_heading_found = True

    # Geometry fallback for the screenshot case: the heading text is blank and
    # only the purple bar and orange icon remain. All candidates are resolved
    # before any object is deleted.
    if box_geometry is not None:
        box_left, box_top, box_width, box_height = box_geometry
        box_right = box_left + box_width
        box_top_band_min = box_top - 45.0
        box_top_band_max = box_top + 28.0

        table_match = exact_matches.get(table_object)
        note_match = exact_matches.get(note_object)
        excluded_ids: set[int] = set()
        for matched in (box_match, table_match, note_match):
            if matched is not None:
                try:
                    excluded_ids.add(int(matched.Id))
                except Exception:
                    pass

        heading_candidates: list[tuple[float, object, str]] = []
        icon_candidates: list[tuple[float, object, str]] = []

        for candidate, candidate_owner in _iter_shapes_with_owner(slide):
            try:
                owner_id = int(candidate_owner.Id)
                if owner_id in excluded_ids:
                    continue
                if candidate.HasTable:
                    continue
                c_left = float(candidate.Left)
                c_top = float(candidate.Top)
                c_width = float(candidate.Width)
                c_height = float(candidate.Height)
                c_right = c_left + c_width
                c_bottom = c_top + c_height
            except Exception:
                continue

            # Purple heading bar: shallow, directly across the top edge of the
            # exact IDCWBox, and substantial in width. This also catches a group
            # containing the bar and its now-empty text box.
            crosses_top_band = (
                c_bottom >= box_top_band_min
                and c_top <= box_top_band_max
            )
            horizontally_in_box = (
                c_right >= box_left - 5.0
                and c_left <= box_right
            )
            is_shallow_heading = (
                80.0 <= c_width <= box_width + 30.0
                and 4.0 <= c_height <= 75.0
            )
            if crosses_top_band and horizontally_in_box and is_shallow_heading:
                score = (
                    abs(c_top - box_top)
                    + abs(c_left - box_left) * 0.05
                    - min(c_width, box_width) * 0.001
                )
                heading_candidates.append(
                    (
                        score,
                        candidate_owner,
                        "idcw_heading_box_geometry",
                    )
                )

            # Orange icon: compact and centered at the upper-left corner of the
            # exact IDCWBox. Only the nearest candidate is selected.
            c_center_x = c_left + c_width / 2.0
            c_center_y = c_top + c_height / 2.0
            corner_x = box_left
            corner_y = box_top
            is_compact = (
                4.0 <= c_width <= 95.0
                and 4.0 <= c_height <= 95.0
            )
            corner_distance = (
                (c_center_x - box_left) ** 2
                + (c_center_y - box_top) ** 2
            ) ** 0.5
            near_upper_left = corner_distance <= 72.0
            if is_compact and near_upper_left:
                distance = abs(c_center_x - corner_x) + abs(
                    c_center_y - corner_y
                )
                icon_candidates.append(
                    (
                        distance,
                        candidate_owner,
                        "idcw_icon_box_geometry",
                    )
                )

        # Multiple shallow shapes can form the bar, such as a background plus
        # a transparent text box. Delete every qualifying top-level owner in the
        # narrow box-top band.
        for _, candidate, reason in sorted(
            heading_candidates,
            key=lambda item: item[0],
        ):
            add_owner(candidate, reason)

        if icon_candidates:
            _, icon_candidate, reason = min(
                icon_candidates,
                key=lambda item: item[0],
            )
            add_owner(icon_candidate, reason)
        else:
            logger.info(
                "IDCW_ICON_BOX_FALLBACK_NOT_FOUND | slide=%s",
                slide.SlideIndex,
            )

        logger.info(
            "IDCW_BOX_TOP_FALLBACK | slide=%s | semantic_heading=%s | "
            "heading_candidates=%s | icon_candidates=%s",
            slide.SlideIndex,
            semantic_heading_found,
            len(heading_candidates),
            len(icon_candidates),
        )
    else:
        logger.warning(
            "IDCW_BOX_GEOMETRY_UNAVAILABLE | slide=%s",
            slide.SlideIndex,
        )

    deleted = 0
    owner_items = list(owners.values())
    owner_items.sort(
        key=lambda item: int(getattr(item[0], "ZOrderPosition", 0)),
        reverse=True,
    )

    for owner, reasons in owner_items:
        try:
            owner_name = str(owner.Name)
        except Exception:
            owner_name = "<group>"
        try:
            owner.Delete()
            deleted += 1
            logger.info(
                "IDCW_OWNER_DELETED | slide=%s | owner=%s | reasons=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
            )
        except Exception as error:
            logger.warning(
                "IDCW_OWNER_DELETE_FAILED | slide=%s | owner=%s | "
                "reasons=%s | error=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
                error,
            )

    return deleted


# -----------------------------------------------------------------------------
# COM and public operation
# -----------------------------------------------------------------------------


def _retry_com(name: str, operation, logger, attempts: int = 6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(error, "hresult", error.args[0] if error.args else None)
            if code not in {RPC_E_CALL_REJECTED, RPC_E_SERVERCALL_RETRYLATER} or attempt == attempts:
                raise
            logger.warning(
                "IDCW_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def apply_idcw(
    current_ppt_bytes: bytes,
    idcw_source_ppt_bytes: bytes,
    fund_object: str = "FundDetails",
    idcw_table_object: str = TARGET_TABLE_OBJECT,
    idcw_box_object: str = TARGET_BOX_OBJECT,
    idcw_note_object: str = TARGET_NOTE_OBJECT,
    idcw_icon_text_bg_object: str = TARGET_ICON_TEXT_BG_OBJECT,
    logger=None,
    strict: bool = False,
    source_file: str = "",
    source_fund_object: str = SOURCE_FUND_OBJECT,
    source_table_object: str = SOURCE_TABLE_OBJECT,
    source_note_object: str = SOURCE_NOTE_OBJECT,
) -> bytes:
    """Copy IDCW table values and note from source PPT into target PPT."""
    if logger is None:
        raise ValueError("A logger is required for IDCW processing.")
    if not current_ppt_bytes or not idcw_source_ppt_bytes:
        raise ValueError("Both target and source PowerPoint files are required.")

    pythoncom.CoInitialize()
    powerpoint = source_presentation = target_presentation = None
    operation_start = perf_counter()

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "idcw_source.pptx"
            target_path = temp / "idcw_target.pptx"
            output_path = temp / "idcw_output.pptx"
            source_path.write_bytes(idcw_source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.DisplayAlerts = False
            source_presentation = _retry_com(
                "open IDCW source",
                lambda: powerpoint.Presentations.Open(
                    str(source_path.resolve()), True, False, False
                ),
                logger,
            )
            target_presentation = _retry_com(
                "open IDCW target",
                lambda: powerpoint.Presentations.Open(
                    str(target_path.resolve()), False, False, False
                ),
                logger,
            )

            records = _build_source_index(
                source_presentation,
                source_fund_object,
                source_table_object,
                source_note_object,
                logger,
            )

            updated = deleted = skipped = moved_total = changes_total = 0
            for slide_number in range(1, target_presentation.Slides.Count + 1):
                slide = target_presentation.Slides.Item(slide_number)
                table_wrapper = _find_named_shape_robust(slide, idcw_table_object)
                if table_wrapper is None:
                    continue

                fund_shape = _find_named_shape_robust(slide, fund_object)
                if fund_shape is None:
                    if strict:
                        raise ValueError(
                            f"Object '{fund_object}' missing on slide {slide_number}."
                        )
                    skipped += 1
                    continue

                fund_name = _shape_text(fund_shape)
                record = records.get(_fund_key(fund_name))
                if record is None:
                    deleted += _delete_idcw_section(
                        slide,
                        idcw_table_object,
                        idcw_box_object,
                        idcw_note_object,
                        idcw_icon_text_bg_object,
                        logger,
                    )
                    logger.info(
                        "IDCW_DATA_ABSENT | slide=%s | fund=%s",
                        slide_number,
                        fund_name,
                    )
                    continue

                table_shape = _find_table_shape(table_wrapper)
                box_shape = _find_named_shape_robust(slide, idcw_box_object)
                note_shape = _find_named_shape_robust(slide, idcw_note_object)
                icon_bg_shape = _find_named_shape_robust(
                    slide, idcw_icon_text_bg_object
                )
                if table_shape is None or box_shape is None or note_shape is None:
                    message = "Target IDCWTable, IDCWBox, or IDCWNote is missing."
                    if strict:
                        raise ValueError(f"Slide {slide_number}: {message}")
                    logger.warning(
                        "IDCW_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        fund_name,
                        message,
                    )
                    skipped += 1
                    continue

                section_shapes = [table_shape, box_shape, note_shape]
                if icon_bg_shape is not None:
                    section_shapes.append(icon_bg_shape)
                original_section = _section_bounds(section_shapes)
                table_bottom = float(table_shape.Top + table_shape.Height)
                original_table_note_gap = max(0.0, float(note_shape.Top) - table_bottom)
                original_note_bottom = float(note_shape.Top + note_shape.Height)
                original_note_box_padding = max(
                    0.0,
                    float(box_shape.Top + box_shape.Height) - original_note_bottom,
                )

                try:
                    changes = _copy_table_values(table_wrapper, record, logger)
                    _set_note_text_and_fit(note_shape, record.note_text)
                    moved, delta = _adjust_idcw_layout(
                        slide,
                        original_section,
                        table_shape,
                        note_shape,
                        box_shape,
                        original_table_note_gap,
                        original_note_box_padding,
                        section_shapes,
                        logger,
                    )
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "IDCW_SKIP | slide=%s | fund=%s | reason=%s",
                        slide_number,
                        fund_name,
                        error,
                    )
                    skipped += 1
                    continue

                updated += 1
                changes_total += changes + 1
                moved_total += moved
                logger.info(
                    "IDCW_UPDATED | target_slide=%s | source_table_slide=%s | "
                    "fund=%s | rows=%s | columns=%s | note=%s | "
                    "height_delta_cm=%.3f",
                    slide_number,
                    record.source_table_slide,
                    record.canonical_fund_name,
                    len(record.table_values),
                    len(record.table_values[0]) if record.table_values else 0,
                    bool(record.note_text),
                    delta / POINTS_PER_CM,
                )

            _retry_com(
                "save IDCW target",
                lambda: target_presentation.SaveAs(
                    str(output_path.resolve()), PP_SAVE_AS_OPEN_XML_PRESENTATION
                ),
                logger,
            )
            target_presentation.Close()
            target_presentation = None
            source_presentation.Close()
            source_presentation = None

            output = output_path.read_bytes()
            logger.info(
                "IDCW_COMPLETE | source_funds=%s | slides_updated=%s | "
                "objects_deleted=%s | objects_moved=%s | skipped=%s | "
                "changes=%s | bytes=%s | total_seconds=%.3f",
                len(records), updated, deleted, moved_total, skipped,
                changes_total, len(output), perf_counter() - operation_start,
            )
            return output
    except Exception:
        logger.exception("IDCW_FAILED")
        raise
    finally:
        for presentation in (target_presentation, source_presentation):
            if presentation is not None:
                try:
                    presentation.Close()
                except Exception:
                    pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
