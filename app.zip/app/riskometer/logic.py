from __future__ import annotations

import io
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize, shape_texts

try:
    from config import RISKOMETER_FUND_ALIASES as CONFIG_RISKOMETER_ALIASES
except ImportError:
    CONFIG_RISKOMETER_ALIASES: dict[str, str] = {}

PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
MSO_FALSE = 0
MSO_GROUP = 6
MSO_LINKED_PICTURE = 11
MSO_PICTURE = 13
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
POINTS_PER_CM = 72.0 / 2.54
RISKOMETER_IMAGE_WIDTH_CM = 4.3
RISKOMETER_IMAGE_HEIGHT_CM = 2.25
RISKOMETER_IMAGE_WIDTH_PT = RISKOMETER_IMAGE_WIDTH_CM * POINTS_PER_CM
RISKOMETER_IMAGE_HEIGHT_PT = RISKOMETER_IMAGE_HEIGHT_CM * POINTS_PER_CM

BUILTIN_RISKOMETER_FUND_ALIASES: dict[str, str] = {
    "AXIS NIFTY MIDCAP 50 INDEX FUND": "Axis Nifty Midcap 50 Index Fund",
    "AXIS NIFTY SMALLCAP 50 INDEX FUND": "Axis Nifty Smallcap 50 Index Fund",
    "Axis Children’s Fund": "Axis Children's Fund",
    "Axis CRISIL IBX50:50 Gilt Plus SDL June 2028 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL June 2028 Index Fund"
    ),
    "Axis CRISIL IBX50:50 Gilt Plus SDL Sep 2027 Index Fund": (
        "Axis Crisil IBX 50:50 Gilt Plus SDL September 2027 Index Fund"
    ),
    "Axis CRISIL IBX AAA Bond NBFC Jun 2027 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC - Jun 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond Fin Ser. Sep27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond Financial Services - Sep 2027 Index Fund"
    ),
    "Axis CRISIL-IBX AAA Bond NBFC-HFC-Jun27 Index Fund": (
        "Axis CRISIL-IBX AAA Bond NBFC-HFC - JUN 2027 Index Fund"
    ),
    "Axis CRISIL-IBX Fin. Svcs 3-6 Mon Debt Index Fund": (
        "Axis CRISIL-IBX Financial Services 3-6 Months Debt Index Fund"
    ),
}
RISKOMETER_FUND_ALIASES = {
    **BUILTIN_RISKOMETER_FUND_ALIASES,
    **CONFIG_RISKOMETER_ALIASES,
}
NORMALIZED_RISKOMETER_ALIASES = {
    normalize(source): normalize(target)
    for source, target in RISKOMETER_FUND_ALIASES.items()
}


@dataclass(frozen=True)
class RiskometerRecord:
    excel_fund_name: str
    canonical_fund_name: str
    benchmark_name: str
    fund_image_bytes: bytes
    benchmark_image_bytes: bytes
    fund_image_extension: str
    benchmark_image_extension: str
    sheet_name: str
    source_row: int


def _clean(value: object) -> str:
    if value is None:
        return ""
    return " ".join(str(value).replace("\xa0", " ").split())


def _canonical_name(name: str) -> str:
    direct = RISKOMETER_FUND_ALIASES.get(name)
    if direct:
        return direct
    key = normalize(name)
    for source, target in RISKOMETER_FUND_ALIASES.items():
        if normalize(source) == key:
            return target
    return name


def _record_key(name: str) -> str:
    return NORMALIZED_RISKOMETER_ALIASES.get(
        normalize(name),
        normalize(_canonical_name(name)),
    )


def _find_headers(worksheet) -> tuple[int, dict[str, int]]:
    accepted = {
        "fund": {"fund", "scheme", "scheme name", "fund name"},
        "benchmark": {"benchmark", "benchmark name"},
        "fund_image": {"riskometer of fund", "risk-o-meter of fund"},
        "benchmark_image": {
            "riskometer of benchmark",
            "risk-o-meter of benchmark",
        },
    }
    for row in range(1, min(worksheet.max_row, 25) + 1):
        columns: dict[str, int] = {}
        for column in range(1, worksheet.max_column + 1):
            text = normalize(worksheet.cell(row, column).value)
            for field, aliases in accepted.items():
                if text in aliases:
                    columns[field] = column
        if set(accepted).issubset(columns):
            return row, columns
    raise ValueError(
        f"Sheet '{worksheet.title}' must contain Fund, Benchmark, "
        "Riskometer of Fund, and Riskometer of Benchmark headers."
    )


def _image_anchor(image) -> tuple[int, int]:
    anchor = image.anchor
    if isinstance(anchor, str):
        from openpyxl.utils.cell import coordinate_to_tuple
        row, column = coordinate_to_tuple(anchor)
        return row, column
    marker = getattr(anchor, "_from", None)
    if marker is None:
        raise ValueError("An embedded Excel image has no readable cell anchor.")
    return int(marker.row) + 1, int(marker.col) + 1


def _image_extension(image) -> str:
    value = str(getattr(image, "format", "png") or "png").lower()
    return "jpg" if value in {"jpeg", "jpg"} else "png"


def _images_by_anchor(worksheet) -> dict[tuple[int, int], list[tuple[bytes, str]]]:
    result: dict[tuple[int, int], list[tuple[bytes, str]]] = {}
    for image in getattr(worksheet, "_images", []):
        row, column = _image_anchor(image)
        result.setdefault((row, column), []).append(
            (image._data(), _image_extension(image))
        )
    return result


def _find_row_image(
    images: dict[tuple[int, int], list[tuple[bytes, str]]],
    row: int,
    expected_column: int,
) -> tuple[bytes, str] | None:
    exact = images.get((row, expected_column))
    if exact:
        return exact[0]
    # Some workbooks anchor a picture one row/column inside a large merged cell.
    candidates: list[tuple[int, tuple[bytes, str]]] = []
    for (image_row, image_column), values in images.items():
        if abs(image_row - row) <= 1:
            distance = abs(image_row - row) * 10 + abs(image_column - expected_column)
            candidates.append((distance, values[0]))
    return min(candidates, key=lambda item: item[0])[1] if candidates else None


def read_riskometer_excel(
    excel_bytes: bytes,
    logger,
    classify_risk: bool = False,
    detailed_logging: bool = True,
) -> dict[str, RiskometerRecord]:
    """
    Read fund names, benchmark names, and embedded Riskometer images.

    ``classify_risk`` is retained only for backward compatibility with the
    current app.py preview call. Risk categories are no longer detected because
    RiskoMeterTable2 processing has been removed.
    """
    if not excel_bytes:
        raise ValueError("A non-empty Riskometer Excel workbook is required.")
    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )
    records: dict[str, RiskometerRecord] = {}
    try:
        for worksheet in workbook.worksheets:
            try:
                header_row, columns = _find_headers(worksheet)
            except ValueError as error:
                logger.info(
                    "RISKOMETER_SHEET_SKIPPED | sheet=%s | reason=%s",
                    worksheet.title,
                    error,
                )
                continue
            anchored_images = _images_by_anchor(worksheet)
            for row in range(header_row + 1, worksheet.max_row + 1):
                fund = _clean(worksheet.cell(row, columns["fund"]).value)
                benchmark = _clean(
                    worksheet.cell(row, columns["benchmark"]).value
                )
                if not fund:
                    continue
                if not benchmark:
                    raise ValueError(
                        f"Blank Benchmark for '{fund}' on row {row}."
                    )
                fund_picture = _find_row_image(
                    anchored_images,
                    row,
                    columns["fund_image"],
                )
                benchmark_picture = _find_row_image(
                    anchored_images,
                    row,
                    columns["benchmark_image"],
                )
                if fund_picture is None or benchmark_picture is None:
                    raise ValueError(
                        f"Riskometer image missing for '{fund}' on row {row}. "
                        "Images must be embedded in the Fund and Benchmark "
                        "riskometer columns."
                    )
                canonical = _canonical_name(fund)
                key = _record_key(fund)
                if key in records:
                    raise ValueError(
                        f"Duplicate/colliding Riskometer fund: '{fund}'."
                    )
                records[key] = RiskometerRecord(
                    excel_fund_name=fund,
                    canonical_fund_name=canonical,
                    benchmark_name=benchmark,
                    fund_image_bytes=fund_picture[0],
                    benchmark_image_bytes=benchmark_picture[0],
                    fund_image_extension=fund_picture[1],
                    benchmark_image_extension=benchmark_picture[1],
                    sheet_name=worksheet.title,
                    source_row=row,
                )
                if detailed_logging:
                    logger.info(
                        "RISKOMETER_FUND_READ | sheet=%s | row=%s | fund=%s | "
                        "canonical=%s | benchmark=%s",
                        worksheet.title,
                        row,
                        fund,
                        canonical,
                        benchmark,
                    )
        if not records:
            raise ValueError("No valid Riskometer records were found.")
        logger.info(
            "RISKOMETER_EXCEL_COMPLETE | funds=%s",
            len(records),
        )
        return records
    finally:
        workbook.close()


def _match_fund(fund_shape, records):
    for text in shape_texts(fund_shape):
        record = records.get(normalize(text))
        if record:
            return record
    return None


def _get_cell(table, row: int, column: int):
    try:
        return table.Cell(row, column)
    except Exception:
        return None


def _cell_text(table, row: int, column: int) -> str:
    cell = _get_cell(table, row, column)
    if cell is None or not cell.Shape.HasTextFrame:
        return ""
    return _clean(cell.Shape.TextFrame.TextRange.Text)


def _find_text_row(table, search_text: str) -> int | None:
    target = normalize(search_text)
    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            if target in normalize(_cell_text(table, row, column)):
                return row
    return None


def _first_text_shape_on_row(table, row: int):
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)
        if cell is not None and cell.Shape.HasTextFrame:
            return cell.Shape
    raise ValueError(f"No text cell is accessible on RiskoMeterTable row {row}.")


def _largest_cell_shape_on_row(table, row: int):
    """
    Return the largest accessible cell shape on a physical PowerPoint row.

    PowerPoint table-cell shapes do not reliably expose ``Shape.Name`` through
    COM. Requesting that property can raise E_NOTIMPL (-2147467263), which was
    the cause of the Riskometer failure. Merged-cell duplicates are therefore
    identified by their safe geometry values instead of the unsupported Name
    property.
    """
    candidates = []
    seen_geometry: set[tuple[float, float, float, float]] = set()

    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue

        try:
            shape = cell.Shape
            left = round(float(shape.Left), 4)
            top = round(float(shape.Top), 4)
            width = round(float(shape.Width), 4)
            height = round(float(shape.Height), 4)
        except Exception:
            # Ignore inaccessible merged-cell coordinates and continue looking
            # for another usable cell on the same physical row.
            continue

        geometry = (left, top, width, height)
        if geometry in seen_geometry:
            continue
        seen_geometry.add(geometry)
        candidates.append((width * height, shape))

    if not candidates:
        raise ValueError(
            f"No accessible image cell was found in RiskoMeterTable row {row}."
        )

    return max(candidates, key=lambda item: item[0])[1]


def _replace_text_preserve_format(shape, new_text: str) -> None:
    text_range = shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")
    if old_text:
        text_range.Characters(1, len(old_text)).Text = new_text
    else:
        text_range.Text = new_text


def _shape_bounds(shape) -> tuple[float, float, float, float]:
    left = float(shape.Left)
    top = float(shape.Top)
    width = float(shape.Width)
    height = float(shape.Height)
    return left, top, left + width, top + height


def _intersection_area(
    first: tuple[float, float, float, float],
    second: tuple[float, float, float, float],
) -> float:
    left = max(first[0], second[0])
    top = max(first[1], second[1])
    right = min(first[2], second[2])
    bottom = min(first[3], second[3])
    if right <= left or bottom <= top:
        return 0.0
    return (right - left) * (bottom - top)


def _region_from_rows(
    table,
    first_row: int,
    last_row: int,
) -> tuple[float, float, float, float]:
    """Return the union of all accessible table-cell geometry in row range."""
    bounds: list[tuple[float, float, float, float]] = []
    for row in range(first_row, last_row + 1):
        for column in range(1, table.Columns.Count + 1):
            cell = _get_cell(table, row, column)
            if cell is None:
                continue
            try:
                bounds.append(_shape_bounds(cell.Shape))
            except Exception:
                continue
    if not bounds:
        raise ValueError(
            f"No accessible RiskoMeterTable geometry was found in rows "
            f"{first_row}-{last_row}."
        )
    return (
        min(value[0] for value in bounds),
        min(value[1] for value in bounds),
        max(value[2] for value in bounds),
        max(value[3] for value in bounds),
    )


def _table_bounds(
    table,
    table_shape=None,
) -> tuple[float, float, float, float]:
    """Return safe bounds for the complete RiskoMeterTable."""
    if table_shape is not None:
        try:
            return _shape_bounds(table_shape)
        except Exception:
            pass

    bounds: list[tuple[float, float, float, float]] = []
    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            cell = _get_cell(table, row, column)
            if cell is None:
                continue
            try:
                bounds.append(_shape_bounds(cell.Shape))
            except Exception:
                continue
    if not bounds:
        raise ValueError("RiskoMeterTable geometry is not accessible.")
    return (
        min(value[0] for value in bounds),
        min(value[1] for value in bounds),
        max(value[2] for value in bounds),
        max(value[3] for value in bounds),
    )


def _row_bounds(
    table,
    row: int,
) -> tuple[float, float, float, float]:
    """Return the union of accessible cells on one physical table row."""
    return _region_from_rows(table, row, row)


def _riskometer_regions_from_headings(
    table,
    table_shape,
    scheme_heading_row: int,
    benchmark_heading_row: int,
) -> tuple[
    tuple[float, float, float, float],
    tuple[float, float, float, float],
]:
    """
    Build image regions from heading geometry instead of assumed row counts.

    Compact templates may place the Benchmark Riskometer heading immediately
    after the scheme-name row. In that layout, the scheme picture is an
    independent slide picture floating between headings, not a dedicated table
    row. Therefore ranges such as rows 3-2 are invalid and must not be used.
    """
    whole = _table_bounds(table, table_shape)
    scheme_heading = _row_bounds(table, scheme_heading_row)
    benchmark_heading = _row_bounds(table, benchmark_heading_row)

    left, _, right, table_bottom = whole
    scheme_top = scheme_heading[3]
    scheme_bottom = benchmark_heading[1]
    benchmark_top = benchmark_heading[3]
    benchmark_bottom = table_bottom

    minimum_height = max(RISKOMETER_IMAGE_HEIGHT_PT * 0.45, 8.0)

    # If headings overlap or are adjacent, create a safe search band around
    # their vertical midpoint. This still lets picture overlap determine the
    # exact old-image center before deletion.
    if scheme_bottom - scheme_top < minimum_height:
        midpoint = (scheme_heading[3] + benchmark_heading[1]) / 2.0
        scheme_top = max(whole[1], midpoint - RISKOMETER_IMAGE_HEIGHT_PT)
        scheme_bottom = min(
            table_bottom,
            midpoint + RISKOMETER_IMAGE_HEIGHT_PT * 0.20,
        )

    if benchmark_bottom - benchmark_top < minimum_height:
        benchmark_bottom = benchmark_top + RISKOMETER_IMAGE_HEIGHT_PT * 1.35

    return (
        (left, scheme_top, right, scheme_bottom),
        (left, benchmark_top, right, benchmark_bottom),
    )


def _is_picture_shape(shape) -> bool:
    try:
        return int(shape.Type) in {MSO_PICTURE, MSO_LINKED_PICTURE}
    except Exception:
        return False


def _delete_named_generated_picture(slide, picture_name: str) -> None:
    """Delete a picture generated by an earlier run, if present."""
    for index in range(slide.Shapes.Count, 0, -1):
        try:
            shape = slide.Shapes.Item(index)
            if str(shape.Name) == picture_name:
                shape.Delete()
        except Exception:
            continue


def _remove_old_riskometer_and_get_center(
    slide,
    region: tuple[float, float, float, float],
    generated_picture_name: str,
    logger,
    slide_number: int,
    image_kind: str,
) -> tuple[float, float]:
    """
    Delete old pictures overlapping a riskometer region and return their center.

    The existing template picture with the greatest overlap determines the
    replacement center. Every picture substantially overlapping that same
    region is deleted, which removes both the original template riskometer and
    any duplicate inserted by an earlier run.
    """
    _delete_named_generated_picture(slide, generated_picture_name)

    region_area = max(
        (region[2] - region[0]) * (region[3] - region[1]),
        1.0,
    )
    matches: list[tuple[float, int, float, float]] = []

    for index in range(1, slide.Shapes.Count + 1):
        try:
            shape = slide.Shapes.Item(index)
            if not _is_picture_shape(shape):
                continue
            bounds = _shape_bounds(shape)
            shape_area = max(
                (bounds[2] - bounds[0]) * (bounds[3] - bounds[1]),
                1.0,
            )
            intersection = _intersection_area(bounds, region)
            overlap_of_picture = intersection / shape_area
            overlap_of_region = intersection / region_area
            if overlap_of_picture < 0.20 and overlap_of_region < 0.12:
                continue
            center_x = (bounds[0] + bounds[2]) / 2.0
            center_y = (bounds[1] + bounds[3]) / 2.0
            score = max(overlap_of_picture, overlap_of_region)
            matches.append((score, index, center_x, center_y))
        except Exception:
            continue

    if matches:
        matches.sort(key=lambda item: item[0], reverse=True)
        center_x = matches[0][2]
        center_y = matches[0][3]
        # Delete in descending index order so the PowerPoint collection remains
        # stable while multiple overlapping old pictures are removed.
        for _, index, _, _ in sorted(
            matches,
            key=lambda item: item[1],
            reverse=True,
        ):
            try:
                slide.Shapes.Item(index).Delete()
            except Exception:
                pass
        logger.info(
            "RISKOMETER_OLD_IMAGES_DELETED | slide=%s | kind=%s | count=%s | "
            "center=(%.2f,%.2f)",
            slide_number,
            image_kind,
            len(matches),
            center_x,
            center_y,
        )
        return center_x, center_y

    # Fallback for a template without an old picture: center in the dynamic
    # region derived from the RiskoMeterTable rows.
    center_x = (region[0] + region[2]) / 2.0
    center_y = (region[1] + region[3]) / 2.0
    logger.warning(
        "RISKOMETER_OLD_IMAGE_NOT_FOUND | slide=%s | kind=%s | "
        "using_region_center=(%.2f,%.2f)",
        slide_number,
        image_kind,
        center_x,
        center_y,
    )
    return center_x, center_y


def _add_picture_at_center(
    slide,
    image_path: Path,
    picture_name: str,
    center_x: float,
    center_y: float,
) -> None:
    left = center_x - RISKOMETER_IMAGE_WIDTH_PT / 2.0
    top = center_y - RISKOMETER_IMAGE_HEIGHT_PT / 2.0
    picture = slide.Shapes.AddPicture(
        str(image_path.resolve()),
        MSO_FALSE,
        -1,
        left,
        top,
        RISKOMETER_IMAGE_WIDTH_PT,
        RISKOMETER_IMAGE_HEIGHT_PT,
    )
    try:
        picture.Name = picture_name
    except Exception:
        pass



def _start_powerpoint(logger):
    """
    Return a responsive PowerPoint application and whether this module owns it.

    DispatchEx can block for several minutes when a hidden PowerPoint instance
    is already registered but busy. Reusing a healthy active instance avoids
    that delay. If no healthy active instance exists, a new isolated instance
    is created.
    """
    pythoncom.PumpWaitingMessages()

    try:
        active = win32com.client.GetActiveObject("PowerPoint.Application")
        # Force a harmless COM round-trip to verify responsiveness.
        _ = int(active.Presentations.Count)
        logger.info(
            "RISKOMETER_POWERPOINT_REUSED | presentations=%s",
            active.Presentations.Count,
        )
        return active, False
    except Exception as active_error:
        logger.info(
            "RISKOMETER_NO_RESPONSIVE_ACTIVE_POWERPOINT | reason=%s",
            active_error,
        )

    try:
        application = win32com.client.DispatchEx("PowerPoint.Application")
        _ = int(application.Presentations.Count)
        logger.info("RISKOMETER_POWERPOINT_STARTED_NEW")
        return application, True
    except Exception as error:
        raise RuntimeError(
            "PowerPoint could not be started. Close every PowerPoint window, "
            "end any hidden POWERPNT.EXE process in Task Manager, and run the "
            "Riskometer operation again."
        ) from error


def _retry_com(name, operation, logger, attempts=5):
    delay = 0.75
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(
                error,
                "hresult",
                error.args[0]
                if error.args and isinstance(error.args[0], int)
                else None,
            )
            if code not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise
            logger.warning(
                "RISKOMETER_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(4.0, delay * 1.7)


def apply_riskometer(
    current_ppt_bytes: bytes,
    riskometer_excel_bytes: bytes,
    fund_object: str,
    riskometer_table_object: str,
    logger,
    strict: bool = False,
    source_file: str = "riskometer.xlsx",
    riskometer_change_table_object: str | None = None,
) -> bytes:
    # riskometer_change_table_object is retained only so an existing app.py
    # call does not fail. RiskoMeterTable2 is intentionally not processed.
    del riskometer_change_table_object

    records = read_riskometer_excel(
        riskometer_excel_bytes,
        logger,
        classify_risk=False,
        detailed_logging=True,
    )
    logger.info(
        "RISKOMETER_START | file=%s | funds=%s | width_cm=%.2f | "
        "height_cm=%.2f",
        source_file,
        len(records),
        RISKOMETER_IMAGE_WIDTH_CM,
        RISKOMETER_IMAGE_HEIGHT_CM,
    )
    pythoncom.CoInitialize()
    powerpoint = presentation = None
    owns_powerpoint = False
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            input_path = temp / "working.pptx"
            output_path = temp / "riskometer_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)
            powerpoint, owns_powerpoint = _start_powerpoint(logger)
            _retry_com(
                "set alerts",
                lambda: setattr(powerpoint, "DisplayAlerts", False),
                logger,
                3,
            )
            presentation = _retry_com(
                "open presentation",
                lambda: powerpoint.Presentations.Open(
                    str(input_path.resolve()), False, False, False
                ),
                logger,
            )
            matched = unmatched = updated = 0
            for slide_number in range(1, presentation.Slides.Count + 1):
                pythoncom.PumpWaitingMessages()
                slide = presentation.Slides.Item(slide_number)
                table_shape = find_shape_recursive(
                    slide.Shapes,
                    riskometer_table_object,
                )
                if table_shape is None:
                    continue
                fund_shape = find_shape_recursive(slide.Shapes, fund_object)
                if fund_shape is None:
                    if strict:
                        raise ValueError(
                            f"'{fund_object}' missing on slide {slide_number}."
                        )
                    continue
                record = _match_fund(fund_shape, records)
                if record is None:
                    unmatched += 1
                    if strict:
                        raise ValueError(
                            f"Riskometer record not found for "
                            f"{' | '.join(shape_texts(fund_shape))!r}."
                        )
                    continue
                if not table_shape.HasTable:
                    raise ValueError(
                        f"'{riskometer_table_object}' on slide {slide_number} "
                        "is not a table."
                    )
                table = table_shape.Table
                scheme_heading_row = _find_text_row(table, "Scheme Riskometer")
                benchmark_heading_row = _find_text_row(
                    table,
                    "Benchmark Riskometer",
                )
                if scheme_heading_row is None or benchmark_heading_row is None:
                    raise ValueError(
                        f"Scheme Riskometer or Benchmark Riskometer heading "
                        f"missing on slide {slide_number}."
                    )
                fund_name_row = scheme_heading_row + 1
                fund_image_row = scheme_heading_row + 2
                benchmark_name_row = benchmark_heading_row + 1
                benchmark_image_row = benchmark_heading_row + 2
                if benchmark_name_row > table.Rows.Count:
                    raise ValueError(
                        f"RiskoMeterTable does not contain the benchmark-name "
                        f"row on slide {slide_number}."
                    )
                _replace_text_preserve_format(
                    _first_text_shape_on_row(table, fund_name_row),
                    record.canonical_fund_name,
                )
                _replace_text_preserve_format(
                    _first_text_shape_on_row(table, benchmark_name_row),
                    record.benchmark_name,
                )
                fund_path = temp / (
                    f"fund_{slide_number}.{record.fund_image_extension}"
                )
                benchmark_path = temp / (
                    f"benchmark_{slide_number}."
                    f"{record.benchmark_image_extension}"
                )
                fund_path.write_bytes(record.fund_image_bytes)
                benchmark_path.write_bytes(record.benchmark_image_bytes)
                # Derive picture search regions from the actual heading
                # geometry. This supports compact/merged templates where the
                # scheme picture has no dedicated physical table row.
                scheme_region, benchmark_region = (
                    _riskometer_regions_from_headings(
                        table=table,
                        table_shape=table_shape,
                        scheme_heading_row=scheme_heading_row,
                        benchmark_heading_row=benchmark_heading_row,
                    )
                )

                fund_picture_name = f"RiskoMeterFundImage_{slide_number}"
                benchmark_picture_name = (
                    f"RiskoMeterBenchmarkImage_{slide_number}"
                )
                fund_center = _remove_old_riskometer_and_get_center(
                    slide=slide,
                    region=scheme_region,
                    generated_picture_name=fund_picture_name,
                    logger=logger,
                    slide_number=slide_number,
                    image_kind="fund",
                )
                benchmark_center = _remove_old_riskometer_and_get_center(
                    slide=slide,
                    region=benchmark_region,
                    generated_picture_name=benchmark_picture_name,
                    logger=logger,
                    slide_number=slide_number,
                    image_kind="benchmark",
                )
                _add_picture_at_center(
                    slide=slide,
                    image_path=fund_path,
                    picture_name=fund_picture_name,
                    center_x=fund_center[0],
                    center_y=fund_center[1],
                )
                _add_picture_at_center(
                    slide=slide,
                    image_path=benchmark_path,
                    picture_name=benchmark_picture_name,
                    center_x=benchmark_center[0],
                    center_y=benchmark_center[1],
                )
                matched += 1
                updated += 4
                logger.info(
                    "RISKOMETER_UPDATED | slide=%s | fund=%s | benchmark=%s",
                    slide_number,
                    record.canonical_fund_name,
                    record.benchmark_name,
                )
            _retry_com(
                "save presentation",
                lambda: presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )
            _retry_com("close presentation", presentation.Close, logger, 4)
            presentation = None
            output = output_path.read_bytes()
            logger.info(
                "RISKOMETER_COMPLETE | matched=%s | unmatched=%s | "
                "items_updated=%s | bytes=%s",
                matched,
                unmatched,
                updated,
                len(output),
            )
            return output
    except Exception:
        logger.exception("RISKOMETER_FAILED")
        raise
    finally:
        if presentation is not None:
            try:
                _retry_com("cleanup close", presentation.Close, logger, 3)
            except Exception:
                pass
        if powerpoint is not None and owns_powerpoint:
            try:
                _retry_com("quit PowerPoint", powerpoint.Quit, logger, 3)
            except Exception:
                pass
        pythoncom.CoUninitialize()
