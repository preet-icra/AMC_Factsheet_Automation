from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

import pythoncom
import pywintypes
import win32com.client

from utils.powerpoint import find_shape_recursive


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
RPC_E_CALL_REJECTED = -2147418111
RPC_E_SERVERCALL_RETRYLATER = -2147417846
MSO_GROUP = 6

SOURCE_FUND_OBJECT = "FundName"
SOURCE_TABLE_OBJECT = "ExposureTable"

TARGET_TABLE_OBJECT = "DetailsofExposureTable"
TARGET_BOX_OBJECT = "DetailsofExposureBox"
TARGET_TEXT_BG_OBJECT = "DetailsofExposureTextBG"
TARGET_ICON_OBJECT = "DetailsofExposureIcon"

EXPOSURE_HEADER_ALIASES = {
    "security_name": {
        "security name",
        "security",
        "instrument name",
        "instrument",
    },
    "rating": {
        "rating",
        "credit rating",
    },
    "market_value": {
        "market value as % of net asset",
        "market value as % of net assets",
        "market value % of net asset",
        "market value % of net assets",
        "% of net asset",
        "% of net assets",
    },
}

# Source FundName -> target FundDetails genuine naming differences.
DETAILS_OF_EXPOSURE_FUND_ALIASES = {
    "Axis Childrens Fund": "Axis Children's Fund",
    "Axis Focused 25 Fund": "Axis Focused Fund",
}


@dataclass(frozen=True)
class ExposureRow:
    security_name: str
    rating: str
    market_value: str
    source_row: int


@dataclass(frozen=True)
class ExposureRecord:
    source_fund_name: str
    canonical_fund_name: str
    source_slide_number: int
    rows: tuple[ExposureRow, ...]


# -----------------------------------------------------------------------------
# Text and fund normalization
# -----------------------------------------------------------------------------


def _clean_text(value: object) -> str:
    text = str(value or "").strip()
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\xa0": " ",
        "\r": " ",
        "\n": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return " ".join(text.split())


def _text_key(value: object) -> str:
    text = _clean_text(value).casefold().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", "", text)


def _base_fund_name(value: object) -> str:
    text = _clean_text(value)

    patterns = (
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*-\s*"
        r"growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:compulsory\s+lock-in|no\s+lock-in)(?=\s*-|$)",
        r"\s*-\s*(?:regular|direct)(?:\s+plan)?\s*$",
    )
    for pattern in patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text


def _canonical_fund_name(value: object) -> str:
    base_name = _base_fund_name(value)
    aliases = {
        _text_key(source_name): target_name
        for source_name, target_name in (
            DETAILS_OF_EXPOSURE_FUND_ALIASES.items()
        )
    }
    return aliases.get(_text_key(base_name), base_name)


def _fund_key(value: object) -> str:
    return _text_key(_canonical_fund_name(value))


def _is_valid_fund_name(value: object) -> bool:
    """Accept actual Axis fund names and reject website/disclosure text."""
    text = _clean_text(value)
    key = _text_key(text)
    if not text or len(text) > 150:
        return False
    if any(token in key for token in (
        "http",
        "www",
        "riskometer",
        "pleasevisit",
        "pleasereferwebsite",
        "forviewinglatest",
    )):
        return False
    return "axis" in key and "fund" in key


def _header_type(value: object) -> str | None:
    key = _text_key(value)
    for field_name, aliases in EXPOSURE_HEADER_ALIASES.items():
        if key in {_text_key(alias) for alias in aliases}:
            return field_name
    return None


# -----------------------------------------------------------------------------
# PowerPoint helpers
# -----------------------------------------------------------------------------


def _shape_text(shape) -> str:
    parts: list[str] = []
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                text = _shape_text(shape.GroupItems.Item(index))
                if text:
                    parts.append(text)
        elif shape.HasTable:
            table = shape.Table
            for row in range(1, table.Rows.Count + 1):
                for column in range(1, table.Columns.Count + 1):
                    parts.append(_cell_text(table, row, column))
        elif shape.HasTextFrame and shape.TextFrame.HasText:
            parts.append(str(shape.TextFrame.TextRange.Text or ""))
    except Exception:
        return ""

    return " ".join(
        _clean_text(part) for part in parts if _clean_text(part)
    )


def _cell_text(table, row: int, column: int) -> str:
    try:
        shape = table.Cell(row, column).Shape
        if shape.HasTextFrame and shape.TextFrame.HasText:
            return _clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def _shape_name_key(shape) -> str:
    try:
        return _text_key(str(shape.Name))
    except Exception:
        return ""


def _find_named_shape_with_owner(slide, object_name: str):
    """
    Return (matched_shape, top_level_owner).

    If the named object is nested inside a group, the owner is the top-level
    group on the slide. Deleting the owner removes the complete visual section
    instead of leaving its heading, icon, or border behind.
    """
    wanted = _text_key(object_name)

    def walk(shape, owner):
        if _shape_name_key(shape) == wanted:
            return shape, owner
        try:
            if int(shape.Type) == MSO_GROUP:
                for child_index in range(1, shape.GroupItems.Count + 1):
                    child = shape.GroupItems.Item(child_index)
                    result = walk(child, owner)
                    if result is not None:
                        return result
        except Exception:
            pass
        return None

    for index in range(1, slide.Shapes.Count + 1):
        try:
            top_level = slide.Shapes.Item(index)
        except Exception:
            continue
        result = walk(top_level, top_level)
        if result is not None:
            return result
    return None, None


def _find_named_shape_robust(slide, object_name: str):
    shape, _ = _find_named_shape_with_owner(slide, object_name)
    if shape is not None:
        return shape
    # Retain compatibility with the project's existing recursive finder.
    return find_shape_recursive(slide.Shapes, object_name)


def _find_table_shape(shape):
    """Return a real table shape from a table or a grouped named object."""
    if shape is None:
        return None
    try:
        if shape.HasTable:
            return shape
    except Exception:
        pass
    try:
        if int(shape.Type) == MSO_GROUP:
            for index in range(1, shape.GroupItems.Count + 1):
                result = _find_table_shape(shape.GroupItems.Item(index))
                if result is not None:
                    return result
    except Exception:
        pass
    return None


def _set_cell_text_preserve_format(cell_shape, value: str) -> None:
    if not cell_shape.HasTextFrame:
        raise ValueError("An exposure table cell does not support text.")

    text_range = cell_shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")
    if old_text:
        text_range.Characters(1, len(old_text)).Text = str(value)
    else:
        text_range.Text = str(value)


def _map_exposure_table(shape) -> tuple[object, int, dict[str, int]]:
    table_shape = _find_table_shape(shape)
    if table_shape is None:
        object_name = getattr(shape, "Name", "<missing>")
        raise ValueError(
            f"Object '{object_name}' does not contain a PowerPoint table."
        )

    table = table_shape.Table
    required = set(EXPOSURE_HEADER_ALIASES)

    for row in range(1, table.Rows.Count + 1):
        columns: dict[str, int] = {}
        for column in range(1, table.Columns.Count + 1):
            field_name = _header_type(_cell_text(table, row, column))
            if field_name and field_name not in columns:
                columns[field_name] = column

        if required.issubset(columns):
            return table_shape, row, columns

    raise ValueError(
        f"Table '{shape.Name}' does not contain the required exact headers: "
        "Security Name, Rating, and Market Value as % of Net Asset."
    )


def _format_market_value(value: object) -> str:
    text = _clean_text(value)
    if not text or text.casefold() in {"na", "n/a", "-"}:
        return ""
    if text.endswith("%"):
        return text

    try:
        number = float(text.replace(",", ""))
    except ValueError:
        return text

    if abs(number) <= 1:
        number *= 100
    return f"{number:.2f}%"


def _retry_com(name: str, operation, logger, attempts: int = 6):
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            pythoncom.PumpWaitingMessages()
            return operation()
        except pywintypes.com_error as error:
            code = getattr(
                error,
                "hresult",
                error.args[0]
                if error.args and isinstance(error.args[0], int)
                else None,
            )
            if code not in {
                RPC_E_CALL_REJECTED,
                RPC_E_SERVERCALL_RETRYLATER,
            } or attempt == attempts:
                raise

            logger.warning(
                "EXPOSURE_COM_RETRY | operation=%s | attempt=%s/%s",
                name,
                attempt,
                attempts,
            )
            time.sleep(delay)
            delay = min(3.0, delay * 1.7)


def _iter_shapes_recursive(shapes):
    """Yield every top-level and nested shape in a PowerPoint collection."""
    for index in range(1, shapes.Count + 1):
        try:
            shape = shapes.Item(index)
        except Exception:
            continue
        yield shape
        try:
            if int(shape.Type) == MSO_GROUP:
                yield from _iter_shapes_recursive(shape.GroupItems)
        except Exception:
            pass


def _find_exposure_table_by_content(slide):
    """
    Find an exposure table by visible headers, regardless of object name.

    This is required because many source presentations name the table with a
    generated PowerPoint name such as Table 7 rather than ExposureTable.
    """
    best_shape = None
    best_score = 0
    required = set(EXPOSURE_HEADER_ALIASES)

    for shape in _iter_shapes_recursive(slide.Shapes):
        try:
            if not shape.HasTable:
                continue
        except Exception:
            continue

        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            found: set[str] = set()
            for column in range(1, table.Columns.Count + 1):
                field_name = _header_type(_cell_text(table, row, column))
                if field_name:
                    found.add(field_name)
            score = len(found)
            if score > best_score:
                best_score = score
                best_shape = shape
            if required.issubset(found):
                return shape

    return best_shape if best_score == len(required) else None


def _find_fund_shape_by_content(slide):
    """Find a short visible Axis fund name when object naming is inconsistent."""
    candidates = []
    for shape in _iter_shapes_recursive(slide.Shapes):
        try:
            if shape.HasTable:
                continue
        except Exception:
            pass

        text = _shape_text(shape)
        if not _is_valid_fund_name(text):
            continue

        key = _text_key(text)
        score = 10
        if "regularplan" in key or "directplan" in key:
            score += 1
        candidates.append((score, len(text), shape))

    if not candidates:
        return None
    candidates.sort(key=lambda item: (-item[0], item[1]))
    return candidates[0][2]


# -----------------------------------------------------------------------------
# Source PPT: FundName + ExposureTable
# -----------------------------------------------------------------------------


def _read_source_rows(source_table_shape) -> tuple[ExposureRow, ...]:
    table_shape, header_row, columns = _map_exposure_table(
        source_table_shape
    )
    table = table_shape.Table
    rows: list[ExposureRow] = []

    for row in range(header_row + 1, table.Rows.Count + 1):
        security_name = _cell_text(
            table,
            row,
            columns["security_name"],
        )
        rating = _cell_text(table, row, columns["rating"])
        market_value = _cell_text(
            table,
            row,
            columns["market_value"],
        )

        # Only real data rows are copied. Blank/footer rows are ignored.
        if not security_name:
            continue
        if not rating and not market_value:
            continue

        rows.append(
            ExposureRow(
                security_name=security_name,
                rating=rating,
                market_value=_format_market_value(market_value),
                source_row=row,
            )
        )

    return tuple(rows)


def _build_source_index(
    source_presentation,
    source_fund_object: str,
    source_table_object: str,
    logger,
) -> dict[str, ExposureRecord]:
    """
    Index source exposure data, including split two-slide fund layouts.

    Some source presentations place FundName on one slide and ExposureTable on
    the immediately following slide. The most recent fund name is therefore
    carried forward until its exposure table is found. A new FundName replaces
    the pending one only after any table on the current slide is processed.
    """
    records: dict[str, ExposureRecord] = {}
    pending_fund_name = ""
    pending_fund_slide = 0

    for slide_number in range(1, source_presentation.Slides.Count + 1):
        pythoncom.PumpWaitingMessages()
        slide = source_presentation.Slides.Item(slide_number)

        fund_shape = _find_named_shape_robust(slide, source_fund_object)
        if fund_shape is None:
            fund_shape = _find_fund_shape_by_content(slide)
        current_fund_name = _shape_text(fund_shape) if fund_shape else ""
        if current_fund_name and not _is_valid_fund_name(current_fund_name):
            logger.warning(
                "EXPOSURE_SOURCE_INVALID_FUND_TEXT | slide=%s | text=%s",
                slide_number,
                current_fund_name,
            )
            current_fund_name = ""

        table_shape = _find_named_shape_robust(slide, source_table_object)
        if _find_table_shape(table_shape) is None:
            table_shape = _find_exposure_table_by_content(slide)

        # Prefer the FundName on this slide. Otherwise associate a table-only
        # slide with the most recent preceding FundName slide.
        effective_fund_name = current_fund_name or pending_fund_name
        effective_fund_slide = (
            slide_number if current_fund_name else pending_fund_slide
        )

        if table_shape is None:
            if current_fund_name:
                pending_fund_name = current_fund_name
                pending_fund_slide = slide_number
                logger.info(
                    "EXPOSURE_SOURCE_FUND_PENDING | slide=%s | fund=%s",
                    slide_number,
                    current_fund_name,
                )
            else:
                logger.info(
                    "EXPOSURE_SOURCE_SKIPPED | slide=%s | fund_found=False | "
                    "table_found=False | source_table_name=<none>",
                    slide_number,
                )
            continue

        if not effective_fund_name:
            logger.warning(
                "EXPOSURE_SOURCE_TABLE_UNASSIGNED | slide=%s | table=%s | "
                "reason=no FundName on this or preceding slide",
                slide_number,
                getattr(table_shape, "Name", "<unnamed>"),
            )
            continue

        try:
            rows = _read_source_rows(table_shape)
        except ValueError as error:
            logger.warning(
                "EXPOSURE_SOURCE_SKIPPED | slide=%s | fund=%s | table=%s | "
                "reason=%s",
                slide_number,
                effective_fund_name,
                getattr(table_shape, "Name", "<unnamed>"),
                error,
            )
            # Do not carry a fund beyond an invalid table intended for it.
            pending_fund_name = ""
            pending_fund_slide = 0
            continue

        if not rows:
            logger.info(
                "EXPOSURE_SOURCE_EMPTY | fund_slide=%s | table_slide=%s | "
                "fund=%s",
                effective_fund_slide,
                slide_number,
                effective_fund_name,
            )
            pending_fund_name = ""
            pending_fund_slide = 0
            continue

        key = _fund_key(effective_fund_name)
        if not key:
            pending_fund_name = ""
            pending_fund_slide = 0
            continue

        record = ExposureRecord(
            source_fund_name=effective_fund_name,
            canonical_fund_name=_canonical_fund_name(effective_fund_name),
            source_slide_number=slide_number,
            rows=rows,
        )

        if key in records:
            logger.warning(
                "EXPOSURE_SOURCE_DUPLICATE | fund=%s | retained_table_slide=%s | "
                "ignored_table_slide=%s",
                record.canonical_fund_name,
                records[key].source_slide_number,
                slide_number,
            )
        else:
            records[key] = record
            logger.info(
                "EXPOSURE_SOURCE_FOUND | fund_slide=%s | table_slide=%s | "
                "fund=%s | rows=%s | table=%s",
                effective_fund_slide,
                slide_number,
                record.canonical_fund_name,
                len(record.rows),
                getattr(table_shape, "Name", "<unnamed>"),
            )

        # The table has consumed the pending fund. A new fund found on the same
        # slide can remain pending only when it was not the one just consumed.
        pending_fund_name = ""
        pending_fund_slide = 0

    logger.info("EXPOSURE_SOURCE_INDEX_COMPLETE | funds=%s", len(records))
    if not records:
        raise ValueError(
            "No usable Details of Exposure source tables were found. The "
            "operation was stopped before modifying the target presentation. "
            "The source is searched by object name 'ExposureTable', by visible "
            "headers, and by pairing a FundName slide with the immediately "
            "following table slide."
        )
    return records


# -----------------------------------------------------------------------------
# Target PPT: DetailsofExposureTable and companions
# -----------------------------------------------------------------------------


def _template_data_row_height(table, header_row: int) -> float | None:
    if table.Rows.Count <= header_row:
        return None
    try:
        return float(table.Rows.Item(header_row + 1).Height)
    except Exception:
        return None


def _resize_target_rows(
    table,
    header_row: int,
    required_data_rows: int,
    template_row_height: float | None,
) -> None:
    existing_data_rows = table.Rows.Count - header_row

    while existing_data_rows < required_data_rows:
        table.Rows.Add()
        existing_data_rows += 1

    while existing_data_rows > required_data_rows:
        table.Rows.Item(table.Rows.Count).Delete()
        existing_data_rows -= 1

    # Ensure newly added rows use the original target body-row height.
    if template_row_height is not None:
        for row in range(header_row + 1, table.Rows.Count + 1):
            try:
                table.Rows.Item(row).Height = template_row_height
            except Exception:
                pass


def _copy_rows_into_target(
    target_table_shape,
    record: ExposureRecord,
) -> int:
    table_shape, header_row, columns = _map_exposure_table(
        target_table_shape
    )
    table = table_shape.Table
    row_height = _template_data_row_height(table, header_row)

    _resize_target_rows(
        table,
        header_row,
        len(record.rows),
        row_height,
    )

    changed = 0
    for offset, source_row in enumerate(record.rows, start=1):
        target_row = header_row + offset
        _set_cell_text_preserve_format(
            table.Cell(target_row, columns["security_name"]).Shape,
            source_row.security_name,
        )
        _set_cell_text_preserve_format(
            table.Cell(target_row, columns["rating"]).Shape,
            source_row.rating,
        )
        _set_cell_text_preserve_format(
            table.Cell(target_row, columns["market_value"]).Shape,
            source_row.market_value,
        )
        changed += 3

    return changed


def _resize_exposure_layout(
    table_shape,
    box_shape,
    text_bg_shape,
    icon_shape,
    old_table_height: float,
    old_table_bottom: float,
    logger,
    slide_number: int,
) -> None:
    new_table_height = float(table_shape.Height)
    delta = new_table_height - old_table_height
    if abs(delta) < 0.01:
        return

    # The box grows or shrinks with the table.
    if box_shape is not None:
        try:
            box_shape.Height = max(
                1.0,
                float(box_shape.Height) + delta,
            )
        except Exception:
            pass

    # Companion objects below the old table move by the same amount.
    for companion in (text_bg_shape, icon_shape):
        if companion is None:
            continue
        try:
            if float(companion.Top) >= old_table_bottom - 1.0:
                companion.Top = float(companion.Top) + delta
        except Exception:
            pass

    logger.info(
        "EXPOSURE_LAYOUT_RESIZED | slide=%s | table_height_delta=%.2f | "
        "new_table_height=%.2f",
        slide_number,
        delta,
        new_table_height,
    )


def _delete_all_exposure_objects(
    slide,
    table_object: str,
    box_object: str,
    text_bg_object: str,
    icon_object: str,
    logger,
) -> int:
    """
    Delete only the Details of Exposure table, box, heading background, and icon.

    The table and box are resolved by configured Selection Pane names. The
    heading background is also resolved by its distinctive visible heading
    text because many templates give that shape an automatic name. The icon
    fallback is intentionally narrow: it accepts only a small shape vertically
    aligned immediately to the left of the identified heading. Large IDCW
    objects and unrelated shapes are explicitly excluded.
    """
    owners: dict[str, tuple[object, set[str]]] = {}

    def add_owner(owner, reason: str) -> None:
        if owner is None:
            return
        try:
            owner_name = str(owner.Name)
        except Exception:
            owner_name = ""
        owner_key_text = _text_key(owner_name)
        if owner_key_text in {_text_key("IDCWNote"), _text_key("IDCWBox")}:
            logger.info(
                "EXPOSURE_DELETE_PROTECTED | slide=%s | object=%s",
                slide.SlideIndex,
                owner_name,
            )
            return
        try:
            key = str(owner.Id)
        except Exception:
            key = f"owner:{owner_key_text}:{id(owner)}"
        if key not in owners:
            owners[key] = (owner, set())
        owners[key][1].add(reason)

    # Exact configured objects and their top-level owners.
    for object_name in (
        table_object,
        box_object,
        text_bg_object,
        icon_object,
    ):
        matched, owner = _find_named_shape_with_owner(slide, object_name)
        if matched is None or owner is None:
            logger.info(
                "EXPOSURE_OBJECT_NAME_NOT_FOUND | slide=%s | object=%s",
                slide.SlideIndex,
                object_name,
            )
            continue
        add_owner(owner, object_name)

    # Find the purple exposure heading by its unique visible text. This is a
    # semantic lookup, not a broad proximity lookup.
    heading_tokens = (
        "detailsofexposuretoperpetualbondsat1bondstieriibonds",
        "detailsofexposuretoperpetualbonds",
    )
    heading_owner = None
    heading_geometry = None

    for index in range(1, slide.Shapes.Count + 1):
        try:
            candidate = slide.Shapes.Item(index)
            candidate_name = str(candidate.Name)
        except Exception:
            continue
        if _text_key(candidate_name) in {
            _text_key("IDCWNote"),
            _text_key("IDCWBox"),
        }:
            continue

        visible_key = _text_key(_shape_text(candidate))
        if not any(token in visible_key for token in heading_tokens):
            continue

        heading_owner = candidate
        add_owner(candidate, "exposure_heading_text")
        try:
            heading_geometry = (
                float(candidate.Left),
                float(candidate.Top),
                float(candidate.Width),
                float(candidate.Height),
            )
        except Exception:
            heading_geometry = None
        break

    # Find only the small icon immediately left of the heading. Tight size,
    # horizontal-gap, and vertical-alignment limits prevent IDCW shapes from
    # being selected.
    if heading_geometry is not None:
        h_left, h_top, h_width, h_height = heading_geometry
        h_center_y = h_top + h_height / 2.0
        best_icon = None
        best_distance = None

        for index in range(1, slide.Shapes.Count + 1):
            try:
                candidate = slide.Shapes.Item(index)
                candidate_name = str(candidate.Name)
                c_left = float(candidate.Left)
                c_top = float(candidate.Top)
                c_width = float(candidate.Width)
                c_height = float(candidate.Height)
            except Exception:
                continue

            if _text_key(candidate_name) in {
                _text_key("IDCWNote"),
                _text_key("IDCWBox"),
            }:
                continue
            if candidate is heading_owner:
                continue

            c_right = c_left + c_width
            c_center_y = c_top + c_height / 2.0
            horizontal_gap = h_left - c_right
            vertical_offset = abs(c_center_y - h_center_y)

            is_small_icon = 12.0 <= c_width <= 70.0 and 12.0 <= c_height <= 70.0
            is_immediately_left = -8.0 <= horizontal_gap <= 45.0
            is_vertically_aligned = vertical_offset <= max(12.0, h_height * 0.75)

            if not (
                is_small_icon
                and is_immediately_left
                and is_vertically_aligned
            ):
                continue

            distance = abs(horizontal_gap) + vertical_offset
            if best_distance is None or distance < best_distance:
                best_icon = candidate
                best_distance = distance

        if best_icon is not None:
            add_owner(best_icon, "exposure_icon_geometry")
        else:
            logger.info(
                "EXPOSURE_ICON_FALLBACK_NOT_FOUND | slide=%s",
                slide.SlideIndex,
            )

    deleted = 0
    # Resolve all candidates before deleting. Delete in reverse z-order to keep
    # COM references stable while several top-level shapes are removed.
    owner_list = list(owners.values())
    owner_list.sort(
        key=lambda item: int(getattr(item[0], "ZOrderPosition", 0)),
        reverse=True,
    )

    for owner, reasons in owner_list:
        try:
            owner_name = str(owner.Name)
        except Exception:
            owner_name = "<group>"
        try:
            owner.Delete()
            deleted += 1
            logger.info(
                "EXPOSURE_OWNER_DELETED | slide=%s | owner=%s | reasons=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
            )
        except Exception as error:
            logger.warning(
                "EXPOSURE_OWNER_DELETE_FAILED | slide=%s | owner=%s | "
                "reasons=%s | error=%s",
                slide.SlideIndex,
                owner_name,
                ",".join(sorted(reasons)),
                error,
            )

    return deleted


# -----------------------------------------------------------------------------
# Public operation
# -----------------------------------------------------------------------------


def apply_details_of_exposure(
    current_ppt_bytes: bytes,
    exposure_source_ppt_bytes: bytes | None = None,
    fund_object: str = "FundDetails",
    exposure_table_object: str = TARGET_TABLE_OBJECT,
    exposure_box_object: str = TARGET_BOX_OBJECT,
    exposure_text_bg_object: str = TARGET_TEXT_BG_OBJECT,
    exposure_icon_object: str = TARGET_ICON_OBJECT,
    logger=None,
    strict: bool = False,
    source_file: str = "",
    source_fund_object: str = SOURCE_FUND_OBJECT,
    source_exposure_table_object: str = SOURCE_TABLE_OBJECT,
    # Legacy keyword retained for a clear migration error.
    exposure_excel_bytes: bytes | None = None,
) -> bytes:
    """
    Copy source ExposureTable data into target DetailsofExposureTable.

    Source matching:
        FundName + ExposureTable

    Target matching:
        FundDetails + DetailsofExposureTable

    If a matched target fund has no usable source ExposureTable, all target
    exposure objects are deleted.
    """
    if logger is None:
        raise ValueError("A logger is required for exposure processing.")

    if exposure_source_ppt_bytes is None:
        if exposure_excel_bytes is not None:
            raise ValueError(
                "Details of Exposure now requires a source PowerPoint instead "
                "of Excel. Pass exposure_source_ppt_bytes."
            )
        raise ValueError("Upload a source Details of Exposure PowerPoint.")

    if not current_ppt_bytes:
        raise ValueError("The target PowerPoint is empty.")
    if not exposure_source_ppt_bytes:
        raise ValueError("The source exposure PowerPoint is empty.")

    logger.info(
        "EXPOSURE_START | source_file=%s | target_bytes=%s | "
        "source_bytes=%s | strict=%s",
        source_file or "uploaded_exposure.pptx",
        len(current_ppt_bytes),
        len(exposure_source_ppt_bytes),
        strict,
    )

    pythoncom.CoInitialize()
    powerpoint = source_presentation = target_presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "exposure_source.pptx"
            target_path = temp / "exposure_target.pptx"
            output_path = temp / "exposure_output.pptx"

            source_path.write_bytes(exposure_source_ppt_bytes)
            target_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.DisplayAlerts = False

            source_presentation = _retry_com(
                "open exposure source presentation",
                lambda: powerpoint.Presentations.Open(
                    str(source_path.resolve()),
                    True,
                    False,
                    False,
                ),
                logger,
            )
            target_presentation = _retry_com(
                "open exposure target presentation",
                lambda: powerpoint.Presentations.Open(
                    str(target_path.resolve()),
                    False,
                    False,
                    False,
                ),
                logger,
            )

            source_records = _build_source_index(
                source_presentation,
                source_fund_object,
                source_exposure_table_object,
                logger,
            )

            updated_slides = 0
            unmatched_funds = 0
            deleted_objects = 0
            skipped_slides = 0
            total_changes = 0

            for slide_number in range(1, target_presentation.Slides.Count + 1):
                pythoncom.PumpWaitingMessages()
                slide = target_presentation.Slides.Item(slide_number)

                target_table = _find_named_shape_robust(
                    slide,
                    exposure_table_object,
                )
                target_box = _find_named_shape_robust(
                    slide,
                    exposure_box_object,
                )
                target_text_bg = _find_named_shape_robust(
                    slide,
                    exposure_text_bg_object,
                )
                target_icon = _find_named_shape_robust(
                    slide,
                    exposure_icon_object,
                )

                # Ignore slides with no exposure section at all. If companion
                # objects exist without the table, remove the partial section.
                if target_table is None:
                    if any(
                        shape is not None
                        for shape in (
                            target_box,
                            target_text_bg,
                            target_icon,
                        )
                    ):
                        deleted_objects += _delete_all_exposure_objects(
                            slide,
                            exposure_table_object,
                            exposure_box_object,
                            exposure_text_bg_object,
                            exposure_icon_object,
                            logger,
                        )
                    continue

                fund_shape = _find_named_shape_robust(slide, fund_object)
                if fund_shape is None:
                    message = (
                        f"Object '{fund_object}' is missing on exposure slide "
                        f"{slide_number}."
                    )
                    if strict:
                        raise ValueError(message)
                    logger.warning(
                        "EXPOSURE_SKIP | slide=%s | reason=%s",
                        slide_number,
                        message,
                    )
                    skipped_slides += 1
                    continue

                target_fund_name = _shape_text(fund_shape)
                record = source_records.get(_fund_key(target_fund_name))

                # No source ExposureTable for this fund, or no usable rows.
                if record is None or not record.rows:
                    unmatched_funds += 1
                    deleted = _delete_all_exposure_objects(
                        slide,
                        exposure_table_object,
                        exposure_box_object,
                        exposure_text_bg_object,
                        exposure_icon_object,
                        logger,
                    )
                    deleted_objects += deleted
                    logger.info(
                        "EXPOSURE_DATA_ABSENT | slide=%s | fund=%s | "
                        "objects_deleted=%s",
                        slide_number,
                        target_fund_name,
                        deleted,
                    )
                    continue

                actual_target_table = _find_table_shape(target_table)
                if actual_target_table is None:
                    actual_target_table = target_table
                old_table_height = float(actual_target_table.Height)
                old_table_bottom = (
                    float(actual_target_table.Top) + old_table_height
                )

                try:
                    changes = _copy_rows_into_target(target_table, record)
                    _resize_exposure_layout(
                        actual_target_table,
                        target_box,
                        target_text_bg,
                        target_icon,
                        old_table_height,
                        old_table_bottom,
                        logger,
                        slide_number,
                    )
                except ValueError as error:
                    if strict:
                        raise
                    logger.warning(
                        "EXPOSURE_TARGET_INVALID | slide=%s | fund=%s | "
                        "reason=%s | action=objects_deleted",
                        slide_number,
                        target_fund_name,
                        error,
                    )
                    deleted_objects += _delete_all_exposure_objects(
                        slide,
                        exposure_table_object,
                        exposure_box_object,
                        exposure_text_bg_object,
                        exposure_icon_object,
                        logger,
                    )
                    skipped_slides += 1
                    continue

                updated_slides += 1
                total_changes += changes
                logger.info(
                    "EXPOSURE_UPDATED | target_slide=%s | source_slide=%s | "
                    "fund=%s | rows=%s | changes=%s",
                    slide_number,
                    record.source_slide_number,
                    record.canonical_fund_name,
                    len(record.rows),
                    changes,
                )

            _retry_com(
                "save exposure target presentation",
                lambda: target_presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                ),
                logger,
            )

            target_presentation.Close()
            target_presentation = None
            source_presentation.Close()
            source_presentation = None

            output = output_path.read_bytes()
            if not output:
                raise RuntimeError("The generated exposure PowerPoint is empty.")

            logger.info(
                "EXPOSURE_COMPLETE | source_funds=%s | slides_updated=%s | "
                "unmatched_funds=%s | objects_deleted=%s | "
                "slides_skipped=%s | changes=%s | bytes=%s",
                len(source_records),
                updated_slides,
                unmatched_funds,
                deleted_objects,
                skipped_slides,
                total_changes,
                len(output),
            )
            return output

    except Exception:
        logger.exception("EXPOSURE_FAILED")
        raise

    finally:
        for presentation in (target_presentation, source_presentation):
            if presentation is not None:
                try:
                    presentation.Close()
                except Exception:
                    pass

        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass

        pythoncom.CoUninitialize()
