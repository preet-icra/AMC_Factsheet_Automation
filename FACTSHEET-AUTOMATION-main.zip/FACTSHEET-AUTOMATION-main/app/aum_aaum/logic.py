from __future__ import annotations

import io
import re
import tempfile
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize, shape_texts

PP_SAVE_AS_OPEN_XML_PRESENTATION = 24


@dataclass(frozen=True)
class AumRecord:
    scheme_name: str
    aum: Decimal
    aaum: Decimal


def format_crore(value: Decimal) -> str:
    rounded = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return f"{rounded:,.2f}"


def read_aum_excel(excel_bytes: bytes, logger) -> dict[str, AumRecord]:
    logger.info("STEP_2_EXCEL_START | bytes=%s", len(excel_bytes))
    workbook = load_workbook(io.BytesIO(excel_bytes), data_only=True, read_only=False)
    worksheet = workbook.worksheets[0]
    rows = list(worksheet.iter_rows(values_only=True))

    header_index = None
    columns: dict[str, int] = {}
    for row_index, row in enumerate(rows):
        mapped = {normalize(value): index for index, value in enumerate(row)}
        if {"scheme name", "aum", "aaum"}.issubset(mapped):
            header_index = row_index
            columns = mapped
            break
    if header_index is None:
        raise ValueError("Columns Scheme Name, AUM and AAUM were not found.")

    records: dict[str, AumRecord] = {}
    for row_number, row in enumerate(rows[header_index + 1 :], start=header_index + 2):
        name = str(row[columns["scheme name"]] or "").strip()
        if not name:
            continue
        key = normalize(name)
        if key in records:
            raise ValueError(f"Duplicate scheme in AUM Excel: '{name}'.")
        record = AumRecord(
            scheme_name=name,
            aum=Decimal(str(row[columns["aum"]])),
            aaum=Decimal(str(row[columns["aaum"]])),
        )
        records[key] = record
        logger.info(
            "STEP_2_EXCEL_SCHEME | row=%s | scheme=%s | AUM=%s | AAUM=%s",
            row_number,
            name,
            format_crore(record.aum),
            format_crore(record.aaum),
        )
    logger.info("STEP_2_EXCEL_COMPLETE | schemes=%s", len(records))
    return records


def _matched_scheme(fund_shape, records: dict[str, AumRecord]):
    for text in shape_texts(fund_shape):
        record = records.get(normalize(text))
        if record:
            return record
    return None


def _clean_metric_text(value: object) -> str:
    text = normalize(value)

    # Remove punctuation commonly placed after labels.
    text = text.rstrip(":")
    text = text.strip()

    return text


def _find_metric_row(
    table,
    label: str,
):
    target = normalize(label)

    for row in range(
        1,
        table.Rows.Count + 1,
    ):
        for column in range(
            1,
            table.Columns.Count + 1,
        ):
            try:
                cell = table.Cell(
                    row,
                    column,
                ).Shape

            except Exception:
                # Ignore inaccessible merged-cell coordinates.
                continue

            if not cell.HasTextFrame:
                continue

            text = _clean_metric_text(
                cell.TextFrame.TextRange.Text
            )

            # Exact label:
            # AUM
            if text == target:
                return row

            # Descriptive labels:
            # AUM (Cr.)
            # AUM in Cr.
            # AUM as on ...
            if text.startswith(
                target + " "
            ):
                return row

            if text.startswith(
                target + "("
            ):
                return row

    return None

def _find_value_cell(table, row: int):
    for column in range(table.Columns.Count, 0, -1):
        cell = table.Cell(row, column).Shape
        if cell.HasTextFrame and str(cell.TextFrame.TextRange.Text or "").strip():
            return cell, column
    return table.Cell(row, table.Columns.Count).Shape, table.Columns.Count


def _replace_number_preserve_format(text_range, new_number: str):
    old_text = str(text_range.Text)
    match = re.search(r"[-+]?\d[\d,]*(?:\.\d+)?", old_text)
    if not match:
        raise ValueError(f"Numeric value not found in {old_text!r}.")
    text_range.Characters(match.start() + 1, match.end() - match.start()).Text = new_number
    return old_text, str(text_range.Text)


def apply_aum_aaum(
    current_ppt_bytes: bytes,
    excel_bytes: bytes,
    fund_object: str,
    scheme_details_object: str,
    logger,
) -> bytes:
    records = read_aum_excel(excel_bytes, logger)
    logger.info("STEP_2_START | ppt_bytes=%s", len(current_ppt_bytes))

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            input_path = Path(temp_dir) / "working.pptx"
            output_path = Path(temp_dir) / "aum_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False
            presentation = powerpoint.Presentations.Open(
                str(input_path.resolve()), False, False, False
            )

            matched = 0
            changed = 0
            unmatched = 0
            for slide_number in range(1, presentation.Slides.Count + 1):
                slide = presentation.Slides.Item(slide_number)
                details_shape = find_shape_recursive(slide.Shapes, scheme_details_object)
                if details_shape is None:
                    logger.debug(
                        "STEP_2_SLIDE_SKIPPED | slide=%s | reason=no %s",
                        slide_number,
                        scheme_details_object,
                    )
                    continue

                fund_shape = find_shape_recursive(slide.Shapes, fund_object)
                if fund_shape is None:
                    logger.warning(
                        "STEP_2_SLIDE_SKIPPED | slide=%s | reason=no %s",
                        slide_number,
                        fund_object,
                    )
                    continue

                record = _matched_scheme(fund_shape, records)
                ppt_scheme = " | ".join(shape_texts(fund_shape))
                if record is None:
                    unmatched += 1
                    logger.warning(
                        "STEP_2_SCHEME_NOT_MATCHED | slide=%s | ppt_scheme=%r | no changes",
                        slide_number,
                        ppt_scheme,
                    )
                    continue

                if not details_shape.HasTable:
                    raise ValueError(
                        f"'{scheme_details_object}' on slide {slide_number} is not a table."
                    )

                matched += 1
                logger.info(
                    "STEP_2_SCHEME_MATCHED | slide=%s | scheme=%s",
                    slide_number,
                    record.scheme_name,
                )

                for metric, value in (("AUM", record.aum), ("AAUM", record.aaum)):
                    row = _find_metric_row(details_shape.Table, metric)
                    if row is None:
                        raise ValueError(
                            f"'{metric}' row missing in '{scheme_details_object}' "
                            f"on slide {slide_number}."
                        )
                    value_cell, column = _find_value_cell(details_shape.Table, row)
                    old_text, new_text = _replace_number_preserve_format(
                        value_cell.TextFrame.TextRange,
                        format_crore(value),
                    )
                    changed += 1
                    logger.info(
                        "STEP_2_%s_CHANGED | scheme=%s | slide=%s | cell=%s,%s | %s --> %s",
                        metric,
                        record.scheme_name,
                        slide_number,
                        row,
                        column,
                        old_text,
                        new_text,
                    )

            presentation.SaveAs(
                str(output_path.resolve()), PP_SAVE_AS_OPEN_XML_PRESENTATION
            )
            presentation.Close()
            presentation = None
            output = output_path.read_bytes()
            logger.info(
                "STEP_2_COMPLETE | matched=%s | unmatched=%s | values_changed=%s | bytes=%s",
                matched,
                unmatched,
                changed,
                len(output),
            )
            return output
    except Exception:
        logger.exception("STEP_2_FAILED")
        raise
    finally:
        if presentation is not None:
            presentation.Close()
        if powerpoint is not None:
            powerpoint.Quit()
        pythoncom.CoUninitialize()
