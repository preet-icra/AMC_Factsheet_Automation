from __future__ import annotations

import re
import tempfile
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from pathlib import Path

import pythoncom
import win32com.client
import xlrd

from config import NAV_FUND_NAME_ALIASES
from utils.powerpoint import (
    find_shape_recursive,
    normalize,
    shape_texts,
)


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24

PP_ALIGN_LEFT = 1
PP_ALIGN_RIGHT = 3

MSO_FALSE = 0
MSO_TRUE = -1

PP_BORDER_TOP = 1
PP_BORDER_LEFT = 2
PP_BORDER_BOTTOM = 3
PP_BORDER_RIGHT = 4
PP_BORDER_DIAGONAL_DOWN = 5
PP_BORDER_DIAGONAL_UP = 6

ALL_BORDER_TYPES = (
    PP_BORDER_TOP,
    PP_BORDER_LEFT,
    PP_BORDER_BOTTOM,
    PP_BORDER_RIGHT,
    PP_BORDER_DIAGONAL_DOWN,
    PP_BORDER_DIAGONAL_UP,
)

NORMALIZED_NAV_ALIASES = {
    normalize(source): normalize(target)
    for source, target in NAV_FUND_NAME_ALIASES.items()
}


@dataclass(frozen=True)
class NavRow:
    scheme: str
    nav: str


@dataclass(frozen=True)
class FundNavData:
    fund_name: str
    canonical_fund_name: str
    nav_heading: str
    rows: tuple[NavRow, ...]
    sheet_name: str


@dataclass(frozen=True)
class BorderStyle:
    color: int | None = None
    weight: float | None = None
    dash_style: int | None = None
    transparency: float | None = None


def _display_value(value: object) -> str:
    """Show exactly four decimals and truncate extra digits."""
    value_text = str(value).strip()

    if not value_text:
        raise ValueError("Blank NAV value found in the factsheet.")

    try:
        number = Decimal(value_text)
    except InvalidOperation as error:
        raise ValueError(f"Invalid NAV value: {value!r}") from error

    number = number.quantize(Decimal("0.0001"), rounding=ROUND_DOWN)
    return format(number, ".4f")


def _canonical_name(factsheet_name: str) -> str:
    return NAV_FUND_NAME_ALIASES.get(factsheet_name, factsheet_name)


def _excel_cell_text(sheet, row: int, column: int) -> str:
    """Return stripped display text from an XLS cell."""
    try:
        value = sheet.cell_value(row, column)
    except Exception:
        return ""
    return str(value or "").strip()


def _is_ignored_factsheet_text(value: object) -> bool:
    """Return True for labels that must not be treated as fund names."""
    text = normalize(value)
    if not text:
        return True

    exact_exclusions = {
        "classification - internal",
        "portfolio holdings",
        "rating",
        "% of net assets",
        "total",
        "maturity profile",
        "% weightage",
        "scheme",
        "nav (in rs.)",
        "performance as on",
    }
    if text in exact_exclusions:
        return True
    return any(
        text.startswith(prefix)
        for prefix in (
            "classification - internal",
            "nav as on",
            "performance as on",
        )
    )


def _find_fund_name(sheet, nav_heading_row: int) -> str:
    """Find a fund heading without relying on an AMC name or name suffix."""
    portfolio_rows: list[int] = []
    for row in range(nav_heading_row):
        for column in range(sheet.ncols):
            if normalize(_excel_cell_text(sheet, row, column)) == "portfolio holdings":
                portfolio_rows.append(row)

    # The relevant portfolio heading is the last one before the NAV section.
    if portfolio_rows:
        portfolio_row = max(portfolio_rows)
        for row in range(portfolio_row - 1, -1, -1):
            for column in range(sheet.ncols):
                text = _excel_cell_text(sheet, row, column)
                if text and not _is_ignored_factsheet_text(text):
                    return text

    # High-confidence fallback: an explicitly configured alias.
    for row in range(nav_heading_row):
        for column in range(sheet.ncols):
            text = _excel_cell_text(sheet, row, column)
            if normalize(text) in NORMALIZED_NAV_ALIASES:
                return text

    return ""


def read_nav_workbook(
    file_bytes: bytes,
    logger,
) -> dict[str, FundNavData]:
    logger.info("NAV_EXCEL_START | bytes=%s", len(file_bytes))

    workbook = xlrd.open_workbook(file_contents=file_bytes)
    records: dict[str, FundNavData] = {}

    for sheet_name in workbook.sheet_names():
        sheet = workbook.sheet_by_name(sheet_name)
        if sheet.nrows == 0:
            continue

        nav_heading_row = None
        nav_heading = ""
        for row in range(sheet.nrows):
            for column in range(sheet.ncols):
                text = _excel_cell_text(sheet, row, column)
                if normalize(text).startswith("nav as on"):
                    nav_heading_row = row
                    nav_heading = text
                    break
            if nav_heading_row is not None:
                break

        fund_name = ""
        if nav_heading_row is not None:
            fund_name = _find_fund_name(sheet, nav_heading_row)

        if not fund_name or nav_heading_row is None:
            logger.debug(
                "NAV_SHEET_SKIPPED | sheet=%s | fund=%r | nav_heading=%s",
                sheet_name,
                fund_name,
                nav_heading_row is not None,
            )
            continue

        header_row = None
        scheme_column = None
        nav_column = None
        for row in range(
            nav_heading_row + 1,
            min(sheet.nrows, nav_heading_row + 8),
        ):
            scheme_candidate = None
            nav_candidate = None
            for column in range(sheet.ncols):
                text = normalize(sheet.cell_value(row, column))
                if text == "scheme":
                    scheme_candidate = column
                elif text.startswith("nav"):
                    nav_candidate = column
            if scheme_candidate is not None and nav_candidate is not None:
                header_row = row
                scheme_column = scheme_candidate
                nav_column = nav_candidate
                break

        if header_row is None:
            logger.warning(
                "NAV_HEADERS_NOT_FOUND | sheet=%s | fund=%s",
                sheet_name,
                fund_name,
            )
            continue

        nav_rows: list[NavRow] = []
        for row in range(header_row + 1, sheet.nrows):
            scheme = str(sheet.cell_value(row, scheme_column) or "").strip()
            nav_value = sheet.cell_value(row, nav_column)
            if not scheme or nav_value in (None, ""):
                break
            if normalize(scheme).startswith("performance as on"):
                break
            nav_rows.append(NavRow(scheme=scheme, nav=_display_value(nav_value)))

        if not nav_rows:
            logger.warning(
                "NAV_ROWS_NOT_FOUND | sheet=%s | fund=%s",
                sheet_name,
                fund_name,
            )
            continue

        factsheet_key = normalize(fund_name)
        canonical_name = _canonical_name(fund_name)
        canonical_key = NORMALIZED_NAV_ALIASES.get(factsheet_key, factsheet_key)

        if canonical_key in records:
            raise ValueError(f"Duplicate/colliding NAV fund: '{fund_name}'.")

        if canonical_key != factsheet_key:
            logger.info(
                "NAV_FUND_ALIAS_APPLIED | factsheet=%s | canonical=%s",
                fund_name,
                canonical_name,
            )

        records[canonical_key] = FundNavData(
            fund_name=fund_name,
            canonical_fund_name=canonical_name,
            nav_heading=nav_heading,
            rows=tuple(nav_rows),
            sheet_name=sheet_name,
        )
        logger.info(
            "NAV_FUND_READ | sheet=%s | factsheet_fund=%s | "
            "canonical_fund=%s | rows=%s",
            sheet_name,
            fund_name,
            canonical_name,
            len(nav_rows),
        )

    logger.info("NAV_EXCEL_COMPLETE | funds=%s", len(records))
    return records


def _match_fund(
    fund_shape,
    records: dict[str, FundNavData],
) -> FundNavData | None:
    for text in shape_texts(fund_shape):
        record = records.get(normalize(text))

        if record:
            return record

    return None


def _find_text_row(
    table,
    predicate,
    start_row: int = 1,
):
    for row in range(start_row, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            shape = table.Cell(row, column).Shape

            if shape.HasTextFrame and shape.TextFrame.HasText:
                text = normalize(shape.TextFrame.TextRange.Text)

                if predicate(text):
                    return row, column

    return None, None


def _metric_label_matches(value: object, metric: str) -> bool:
    """Match AUM-like labels without matching AUM inside AAUM."""
    text = normalize(str(value or ""))
    target = re.escape(normalize(metric))
    return re.match(rf"^{target}(?:\s|:|\(|$)", text, flags=re.IGNORECASE) is not None


def _find_metric_row(table, metric: str, start_row: int = 1):
    """Find a metric row while safely handling merged PowerPoint cells."""
    for row in range(start_row, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            try:
                shape = table.Cell(row, column).Shape
            except Exception:
                continue
            if not shape.HasTextFrame:
                continue
            if _metric_label_matches(shape.TextFrame.TextRange.Text, metric):
                return row, column
    return None, None


def _set_text(cell_shape, new_text: str) -> tuple[str, str]:
    text_range = cell_shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")

    text_range.Text = new_text
    return old_text, str(text_range.Text)


def _set_nav(cell_shape, nav: str) -> tuple[str, str]:
    """Delete the old NAV and write the rupee symbol plus four decimals."""
    return _set_text(cell_shape, f"₹ {nav}")


def _format_text(text_range, alignment: int) -> None:
    text_range.Font.Name = "Arial"
    text_range.Font.Size = 7
    text_range.Font.Bold = MSO_FALSE
    text_range.ParagraphFormat.Alignment = alignment


def _format_nav_text(table, row: int) -> None:
    """Format only NAV row text. Border formatting is done separately."""
    scheme_shape = table.Cell(row, 1).Shape
    nav_shape = table.Cell(row, table.Columns.Count).Shape

    if scheme_shape.HasTextFrame:
        _format_text(
            scheme_shape.TextFrame.TextRange,
            PP_ALIGN_LEFT,
        )

    if nav_shape.HasTextFrame:
        _format_text(
            nav_shape.TextFrame.TextRange,
            PP_ALIGN_RIGHT,
        )


def _get_cell(table, row: int, column: int):
    """
    Return a table cell where possible.

    PowerPoint can raise an exception when a coordinate falls inside a merged
    cell but is not the merged cell's top-left coordinate.
    """
    try:
        return table.Cell(row, column)
    except Exception:
        return None


def _capture_bottom_border_style(
    table,
    row: int,
) -> BorderStyle:
    """
    Capture the template separator style.

    The first usable visible bottom border in the row is used. If PowerPoint
    reports no usable border attributes, the function returns an empty style
    and PowerPoint's existing/default line attributes are retained.
    """
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)

        if cell is None:
            continue

        try:
            border = cell.Borders(PP_BORDER_BOTTOM)

            if border.Visible != MSO_TRUE:
                continue

            color = None
            weight = None
            dash_style = None
            transparency = None

            try:
                color = int(border.ForeColor.RGB)
            except Exception:
                pass

            try:
                weight = float(border.Weight)
            except Exception:
                pass

            try:
                dash_style = int(border.DashStyle)
            except Exception:
                pass

            try:
                transparency = float(border.Transparency)
            except Exception:
                pass

            return BorderStyle(
                color=color,
                weight=weight,
                dash_style=dash_style,
                transparency=transparency,
            )

        except Exception:
            continue

    return BorderStyle()


def _set_border_invisible(border) -> None:
    """
    Fully disable a PowerPoint border.

    Visible is the main setting. Transparency is also set where supported so
    theme/table-style rendering cannot leave a faint visible line.
    """
    try:
        border.Visible = MSO_FALSE
    except Exception:
        return

    try:
        border.Transparency = 1.0
    except Exception:
        pass


def _remove_cell_borders(cell) -> None:
    for border_type in ALL_BORDER_TYPES:
        try:
            _set_border_invisible(cell.Borders(border_type))
        except Exception:
            pass


def _remove_row_borders(table, row: int) -> None:
    """
    Remove every border from every accessible cell in a physical table row.

    Iterating all physical columns is required because the scheme cell may be
    merged across several columns.
    """
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)

        if cell is not None:
            _remove_cell_borders(cell)


def _apply_border_style(
    border,
    style: BorderStyle,
) -> None:
    try:
        border.Visible = MSO_TRUE
    except Exception:
        return

    try:
        border.Transparency = 0.0
    except Exception:
        pass

    if style.color is not None:
        try:
            border.ForeColor.RGB = style.color
        except Exception:
            pass

    if style.weight is not None:
        try:
            border.Weight = style.weight
        except Exception:
            pass

    if style.dash_style is not None:
        try:
            border.DashStyle = style.dash_style
        except Exception:
            pass

    if style.transparency is not None:
        try:
            border.Transparency = style.transparency
        except Exception:
            pass


def _add_bottom_border(
    table,
    row: int,
    style: BorderStyle,
) -> None:
    """
    Add only a bottom border across the complete physical table row.

    Applying the border to every accessible physical cell ensures that the
    separator crosses both the merged scheme area and the NAV value cell.
    """
    for column in range(1, table.Columns.Count + 1):
        cell = _get_cell(table, row, column)

        if cell is None:
            continue

        try:
            border = cell.Borders(PP_BORDER_BOTTOM)
            _apply_border_style(border, style)
        except Exception:
            pass


def _finalize_nav_borders(
    table,
    first_row: int,
    aum_row: int,
    populated_count: int,
    bottom_style: BorderStyle,
) -> None:
    """
    Make the NAV section borderless and add one separator after its final NAV.

    This function must run after all row insertion, cell merging, PickUp/Apply,
    text writing and text formatting have completed.
    """
    for row in range(first_row, aum_row):
        _remove_row_borders(table, row)

    if populated_count:
        last_populated_row = first_row + populated_count - 1

        _add_bottom_border(
            table,
            last_populated_row,
            bottom_style,
        )


def _insert_rows(
    table,
    aum_row: int,
    count: int,
    logger,
    fund: str,
    slide: int,
) -> int:
    columns = table.Columns.Count
    template_row = aum_row - 1

    for number in range(1, count + 1):
        new_row = table.Rows.Add(aum_row)

        try:
            new_row.Height = table.Rows.Item(template_row).Height
        except Exception:
            pass

        if columns > 2:
            try:
                table.Cell(aum_row, 1).Merge(
                    table.Cell(aum_row, columns - 1)
                )
            except Exception:
                pass

        source_target_pairs = (
            (
                table.Cell(template_row, 1).Shape,
                table.Cell(aum_row, 1).Shape,
            ),
            (
                table.Cell(template_row, columns).Shape,
                table.Cell(aum_row, columns).Shape,
            ),
        )

        for source, target in source_target_pairs:
            try:
                source.PickUp()
                target.Apply()
            except Exception:
                pass

            try:
                source.TextFrame.TextRange.Copy()
                target.TextFrame.TextRange.Paste()
            except Exception:
                pass

        _format_nav_text(table, aum_row)

        # Remove inherited formatting immediately. A final full cleanup is
        # still performed after every row has been inserted and populated.
        _remove_row_borders(table, aum_row)

        logger.info(
            "NAV_ROW_INSERTED | fund=%s | slide=%s | "
            "row=%s | number=%s/%s",
            fund,
            slide,
            aum_row,
            number,
            count,
        )

        template_row = aum_row
        aum_row += 1

    return aum_row


def apply_nav(
    current_ppt_bytes: bytes,
    nav_excel_bytes: bytes,
    fund_object: str,
    scheme_details_object: str,
    logger,
    fail_on_overflow: bool = True,
) -> bytes:
    records = read_nav_workbook(nav_excel_bytes, logger)

    logger.info(
        "NAV_STEP_START | ppt_bytes=%s",
        len(current_ppt_bytes),
    )

    pythoncom.CoInitialize()

    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "working.pptx"
            output_path = Path(temp_dir) / "nav_updated.pptx"

            input_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx(
                "PowerPoint.Application"
            )
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False

            presentation = powerpoint.Presentations.Open(
                str(input_path.resolve()),
                False,
                False,
                False,
            )

            matched = 0
            unmatched = 0
            changed = 0
            inserted = 0
            cleared = 0

            for slide_number in range(
                1,
                presentation.Slides.Count + 1,
            ):
                slide = presentation.Slides.Item(slide_number)

                details = find_shape_recursive(
                    slide.Shapes,
                    scheme_details_object,
                )

                if details is None:
                    continue

                fund_shape = find_shape_recursive(
                    slide.Shapes,
                    fund_object,
                )

                if fund_shape is None:
                    continue

                record = _match_fund(fund_shape, records)

                if record is None:
                    unmatched += 1

                    logger.warning(
                        "NAV_FUND_NOT_MATCHED | slide=%s | ppt_fund=%r",
                        slide_number,
                        " | ".join(shape_texts(fund_shape)),
                    )
                    continue

                if not details.HasTable:
                    raise ValueError(
                        f"'{scheme_details_object}' on slide "
                        f"{slide_number} is not a table."
                    )

                table = details.Table

                heading_row, heading_column = _find_text_row(
                    table,
                    lambda text: text.startswith("nav as on"),
                )

                if heading_row is None:
                    raise ValueError(
                        f"NAV heading missing on slide {slide_number}."
                    )

                aum_row, aum_label_column = _find_metric_row(
                    table=table,
                    metric="AUM",
                    start_row=heading_row + 1,
                )

                if aum_row is None:
                    raise ValueError(
                        f"AUM row missing after NAV on slide "
                        f"{slide_number}."
                    )

                first_row = heading_row + 1
                capacity = aum_row - first_row
                excel_count = len(record.rows)

                # Capture the template separator before insertion and border
                # cleanup change the original row formatting.
                template_last_nav_row = max(first_row, aum_row - 1)

                bottom_border_style = _capture_bottom_border_style(
                    table,
                    template_last_nav_row,
                )

                if excel_count > capacity:
                    missing = excel_count - capacity

                    if fail_on_overflow:
                        raise ValueError(
                            "NAV rows do not fit for "
                            f"'{record.canonical_fund_name}': "
                            f"Excel={excel_count}, PPT={capacity}. "
                            "Disable overflow stop to insert rows."
                        )

                    aum_row = _insert_rows(
                        table=table,
                        aum_row=aum_row,
                        count=missing,
                        logger=logger,
                        fund=record.canonical_fund_name,
                        slide=slide_number,
                    )

                    inserted += missing
                    capacity = aum_row - first_row

                matched += 1

                old_heading, new_heading = _set_text(
                    table.Cell(
                        heading_row,
                        heading_column,
                    ).Shape,
                    record.nav_heading,
                )

                logger.info(
                    "NAV_HEADING_CHANGED | fund=%s | slide=%s | "
                    "%s --> %s",
                    record.canonical_fund_name,
                    slide_number,
                    old_heading,
                    new_heading,
                )

                for offset, excel_row in enumerate(record.rows):
                    ppt_row = first_row + offset

                    scheme_cell = table.Cell(ppt_row, 1).Shape
                    nav_cell = table.Cell(
                        ppt_row,
                        table.Columns.Count,
                    ).Shape

                    old_scheme, new_scheme = _set_text(
                        scheme_cell,
                        excel_row.scheme,
                    )

                    old_nav, new_nav = _set_nav(
                        nav_cell,
                        excel_row.nav,
                    )

                    _format_nav_text(table, ppt_row)
                    changed += 1

                    logger.info(
                        "NAV_ROW_CHANGED | fund=%s | slide=%s | "
                        "row=%s | scheme: %s --> %s | nav: %s --> %s",
                        record.canonical_fund_name,
                        slide_number,
                        ppt_row,
                        old_scheme,
                        new_scheme,
                        old_nav,
                        new_nav,
                    )

                for ppt_row in range(
                    first_row + excel_count,
                    first_row + capacity,
                ):
                    old_scheme, _ = _set_text(
                        table.Cell(ppt_row, 1).Shape,
                        "",
                    )

                    old_nav, _ = _set_text(
                        table.Cell(
                            ppt_row,
                            table.Columns.Count,
                        ).Shape,
                        "",
                    )

                    _format_nav_text(table, ppt_row)
                    cleared += 1

                    logger.info(
                        "NAV_ROW_CLEARED | fund=%s | slide=%s | "
                        "row=%s | scheme=%r | nav=%r",
                        record.canonical_fund_name,
                        slide_number,
                        ppt_row,
                        old_scheme,
                        old_nav,
                    )

                # IMPORTANT:
                # This must be the final table-formatting operation for the
                # NAV section. It removes all inherited/internal borders and
                # then adds one bottom separator under the final NAV entry.
                _finalize_nav_borders(
                    table=table,
                    first_row=first_row,
                    aum_row=aum_row,
                    populated_count=excel_count,
                    bottom_style=bottom_border_style,
                )

                logger.info(
                    "NAV_BORDERS_FINALIZED | fund=%s | slide=%s | "
                    "first_row=%s | last_row=%s | aum_row=%s",
                    record.canonical_fund_name,
                    slide_number,
                    first_row,
                    first_row + excel_count - 1,
                    aum_row,
                )

            presentation.SaveAs(
                str(output_path.resolve()),
                PP_SAVE_AS_OPEN_XML_PRESENTATION,
            )

            presentation.Close()
            presentation = None

            output = output_path.read_bytes()

            logger.info(
                "NAV_STEP_COMPLETE | matched=%s | unmatched=%s | "
                "rows_changed=%s | rows_inserted=%s | "
                "rows_cleared=%s | bytes=%s",
                matched,
                unmatched,
                changed,
                inserted,
                cleared,
                len(output),
            )

            return output

    except Exception:
        logger.exception("NAV_STEP_FAILED")
        raise

    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass

        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass

        pythoncom.CoUninitialize()