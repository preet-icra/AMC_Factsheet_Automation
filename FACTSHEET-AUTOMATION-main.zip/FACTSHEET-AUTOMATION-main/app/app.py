from __future__ import annotations

from datetime import datetime
from decimal import Decimal

import streamlit as st

from aum_aaum.logic import apply_aum_aaum, read_aum_excel
from config import (
    FINAL_OUTPUT_NAME,
    FUND_DETAILS_OBJECT,
    FUND_NAME_COLUMN,
    FUND_NAME_SHEET,
    MEASURES_TABLE_OBJECT,
    SCHEME_DETAILS_OBJECT,
    SLIDES_PER_FUND,
    TEMPLATE_FUND_NAME,
)
from expense_ratio.logic import (
    apply_expense_ratio,
    format_expense_ratio,
    read_multiple_expense_ratio_files,
)
from nav.logic import apply_nav, read_nav_workbook
from risk_measures.logic import (
    apply_risk_measures,
    format_risk_measure,
    read_multiple_risk_measures_files,
)
from scheme_creation.logic import create_scheme_presentation, read_fund_names
from utils.logger import build_logger, logs_to_bytes


# -----------------------------------------------------------------------------
# Page configuration
# -----------------------------------------------------------------------------

st.set_page_config(
    page_title="Fund PPT Optional Modules",
    layout="wide",
)

st.title("Fund PowerPoint - Optional Modules")
st.caption(
    "Run only the modules you need, in any order. Upload an existing "
    "PowerPoint to run NAV, AUM/AAUM, Expense Ratio, or Risk Measures "
    "directly."
)


# -----------------------------------------------------------------------------
# Session state
# -----------------------------------------------------------------------------

SESSION_DEFAULTS = {
    "working_ppt": None,
    "working_name": "",
    "workflow_logs": [],
    "applied_modules": [],
}

for key, default_value in SESSION_DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = (
            default_value.copy()
            if isinstance(default_value, list)
            else default_value
        )


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def callback_for(box):
    """Return a logger callback that refreshes the visible log area."""

    def callback(_message: str) -> None:
        recent_logs = st.session_state.workflow_logs[-35:]
        box.code("\n".join(recent_logs), language="text")

    return callback


def set_working_ppt(data: bytes, name: str) -> None:
    """Store the current working PowerPoint in session state."""

    st.session_state.working_ppt = data
    st.session_state.working_name = name


def add_applied_module(module_name: str) -> None:
    """Add a module to the applied-module list only once."""

    if module_name not in st.session_state.applied_modules:
        st.session_state.applied_modules.append(module_name)


def clear_workflow_state() -> None:
    """Clear logs and applied-module history for a newly loaded PowerPoint."""

    st.session_state.workflow_logs = []
    st.session_state.applied_modules = []


def display_optional_metric(value: Decimal | None) -> str:
    """Display an optional Risk Measures value in the preview."""

    if value is None:
        return ""
    return format_risk_measure(value)


# -----------------------------------------------------------------------------
# A. Choose or create the working PowerPoint
# -----------------------------------------------------------------------------

st.subheader("A. Choose or create the working PowerPoint")

source_choice = st.radio(
    "PowerPoint source",
    [
        "Upload an existing PowerPoint",
        "Create scheme slides from template",
    ],
    horizontal=True,
)

if source_choice == "Upload an existing PowerPoint":
    existing_ppt = st.file_uploader(
        "Upload existing PPTX",
        type=["pptx"],
        key="existing_ppt",
    )

    if existing_ppt and st.button(
        "Use this PowerPoint",
        key="use_existing_ppt_button",
    ):
        ppt_bytes = existing_ppt.getvalue()
        clear_workflow_state()
        set_working_ppt(ppt_bytes, existing_ppt.name)

        st.session_state.workflow_logs.append(
            "SOURCE_PPT_LOADED | "
            f"file={existing_ppt.name} | "
            f"bytes={len(ppt_bytes)}"
        )

        st.success(
            "Working PowerPoint loaded. You can now apply any optional module."
        )

else:
    template_file = st.file_uploader(
        "Upload PowerPoint template",
        type=["pptx"],
        key="template_file",
    )

    fund_file = st.file_uploader(
        "Upload fund-name Excel",
        type=["xlsx"],
        key="fund_name_file",
    )

    if template_file and fund_file:
        fund_preview_logs: list[str] = []
        preview_logger = build_logger(
            "fund_preview",
            fund_preview_logs,
            None,
        )

        try:
            funds = read_fund_names(
                fund_file.getvalue(),
                FUND_NAME_SHEET,
                FUND_NAME_COLUMN,
                preview_logger,
            )

            fund_names = (
                funds[FUND_NAME_COLUMN]
                .dropna()
                .astype(str)
                .tolist()
            )

            selected_funds = st.multiselect(
                "Funds to create",
                fund_names,
                default=fund_names,
                key="selected_funds",
            )

            if selected_funds:
                selected_data = (
                    funds.set_index(FUND_NAME_COLUMN)
                    .loc[selected_funds]
                    .reset_index()
                )
            else:
                selected_data = funds.iloc[0:0]

            st.dataframe(
                selected_data[[FUND_NAME_COLUMN]],
                hide_index=True,
                use_container_width=True,
            )

            scheme_log_box = st.empty()

            if st.button(
                "Create scheme slides",
                type="primary",
                key="create_scheme_slides_button",
                disabled=selected_data.empty,
            ):
                clear_workflow_state()

                logger = build_logger(
                    "scheme_creation",
                    st.session_state.workflow_logs,
                    callback_for(scheme_log_box),
                )

                output = create_scheme_presentation(
                    template_file.getvalue(),
                    selected_data,
                    FUND_NAME_COLUMN,
                    FUND_DETAILS_OBJECT,
                    TEMPLATE_FUND_NAME,
                    SLIDES_PER_FUND,
                    logger,
                )

                set_working_ppt(output, "scheme_created.pptx")
                add_applied_module("Scheme creation")
                st.success("Scheme slides created successfully.")

        except Exception as error:
            st.error(f"Scheme creation failed: {error}")


# -----------------------------------------------------------------------------
# Working PowerPoint status
# -----------------------------------------------------------------------------

st.divider()

if st.session_state.working_ppt:
    st.success(
        "Working PowerPoint ready: "
        f"{st.session_state.working_name} "
        f"({len(st.session_state.working_ppt):,} bytes)"
    )
else:
    st.warning(
        "Load or create a working PowerPoint before applying a module."
    )


# -----------------------------------------------------------------------------
# B. Optional module selector
# -----------------------------------------------------------------------------

module = st.selectbox(
    "B. Select one optional update module",
    [
        "NAV",
        "AUM & AAUM",
        "Expense Ratio",
        "Risk Measures",
    ],
    disabled=st.session_state.working_ppt is None,
    key="optional_module",
)


# -----------------------------------------------------------------------------
# NAV
# -----------------------------------------------------------------------------

if st.session_state.working_ppt and module == "NAV":
    st.subheader("NAV update")

    nav_file = st.file_uploader(
        "Upload NAV factsheet",
        type=["xls"],
        key="nav_file",
    )

    strict_overflow = st.checkbox(
        "Stop if Excel has more NAV rows than the PowerPoint NAV section",
        value=True,
        key="strict_nav_overflow",
        help=(
            "Enabled: stop when NAV rows exceed the current PowerPoint "
            "capacity. Disabled: insert the missing rows before AUM."
        ),
    )

    if nav_file:
        nav_preview_logs: list[str] = []
        nav_preview_logger = build_logger(
            "nav_preview",
            nav_preview_logs,
            None,
        )

        try:
            nav_records = read_nav_workbook(
                nav_file.getvalue(),
                nav_preview_logger,
            )

            st.dataframe(
                [
                    {
                        "Factsheet Fund": record.fund_name,
                        "PowerPoint Fund": record.canonical_fund_name,
                        "NAV as on": record.nav_heading,
                        "NAV Rows": len(record.rows),
                        "Sheet": record.sheet_name,
                    }
                    for record in nav_records.values()
                ],
                hide_index=True,
                use_container_width=True,
            )

            nav_log_box = st.empty()

            if st.button(
                "Apply NAV to working PowerPoint",
                type="primary",
                key="apply_nav_button",
            ):
                logger = build_logger(
                    "nav",
                    st.session_state.workflow_logs,
                    callback_for(nav_log_box),
                )

                updated_ppt = apply_nav(
                    current_ppt_bytes=st.session_state.working_ppt,
                    nav_excel_bytes=nav_file.getvalue(),
                    fund_object=FUND_DETAILS_OBJECT,
                    scheme_details_object=SCHEME_DETAILS_OBJECT,
                    logger=logger,
                    fail_on_overflow=strict_overflow,
                )

                set_working_ppt(updated_ppt, "nav_updated.pptx")
                add_applied_module("NAV")
                st.success("NAV applied successfully.")

        except Exception as error:
            st.error(f"NAV processing failed: {error}")


# -----------------------------------------------------------------------------
# AUM and AAUM
# -----------------------------------------------------------------------------

if st.session_state.working_ppt and module == "AUM & AAUM":
    st.subheader("AUM and AAUM update")

    aum_file = st.file_uploader(
        "Upload AUM and AAUM Excel",
        type=["xlsx"],
        key="aum_file",
    )

    if aum_file:
        aum_preview_logs: list[str] = []
        aum_preview_logger = build_logger(
            "aum_preview",
            aum_preview_logs,
            None,
        )

        try:
            aum_records = read_aum_excel(
                aum_file.getvalue(),
                aum_preview_logger,
            )

            st.dataframe(
                [
                    {
                        "Fund": record.scheme_name,
                        "AUM": str(record.aum),
                        "AAUM": str(record.aaum),
                    }
                    for record in aum_records.values()
                ],
                hide_index=True,
                use_container_width=True,
            )

            aum_log_box = st.empty()

            if st.button(
                "Apply AUM and AAUM to working PowerPoint",
                type="primary",
                key="apply_aum_aaum_button",
            ):
                logger = build_logger(
                    "aum_aaum",
                    st.session_state.workflow_logs,
                    callback_for(aum_log_box),
                )

                updated_ppt = apply_aum_aaum(
                    current_ppt_bytes=st.session_state.working_ppt,
                    excel_bytes=aum_file.getvalue(),
                    fund_object=FUND_DETAILS_OBJECT,
                    scheme_details_object=SCHEME_DETAILS_OBJECT,
                    logger=logger,
                )

                set_working_ppt(updated_ppt, "aum_aaum_updated.pptx")
                add_applied_module("AUM & AAUM")
                st.success("AUM and AAUM applied successfully.")

        except Exception as error:
            st.error(f"AUM and AAUM processing failed: {error}")


# -----------------------------------------------------------------------------
# Expense Ratio
# -----------------------------------------------------------------------------

if st.session_state.working_ppt and module == "Expense Ratio":
    st.subheader("Expense Ratio update")

    expense_files = st.file_uploader(
        "Upload one or more Expense Ratio / TER Excel files",
        type=["xls", "xlsx"],
        accept_multiple_files=True,
        key="expense_ratio_files",
        help=(
            "Records from all uploaded files will be combined before the "
            "PowerPoint is updated."
        ),
    )

    strict_expense_ratio = st.checkbox(
        "Stop if a fund or Expense Ratio section cannot be matched",
        value=False,
        key="strict_expense_ratio",
    )

    if expense_files:
        expense_file_inputs = [
            (uploaded_file.name, uploaded_file.getvalue())
            for uploaded_file in expense_files
        ]

        expense_preview_logs: list[str] = []
        expense_preview_logger = build_logger(
            "expense_ratio_preview",
            expense_preview_logs,
            None,
        )

        try:
            expense_records = read_multiple_expense_ratio_files(
                excel_files=expense_file_inputs,
                logger=expense_preview_logger,
            )

            st.caption(
                f"{len(expense_files)} file(s) uploaded; "
                f"{len(expense_records)} unique fund record(s) found."
            )

            st.dataframe(
                [
                    {
                        "Fund": record.canonical_fund_name,
                        "Excel Fund Name": record.excel_fund_name,
                        "Regular BER": format_expense_ratio(
                            record.regular_ber
                        ),
                        "Direct BER": format_expense_ratio(
                            record.direct_ber
                        ),
                        "Source File": record.source_file,
                    }
                    for record in expense_records.values()
                ],
                hide_index=True,
                use_container_width=True,
            )

            expense_log_box = st.empty()

            if st.button(
                "Apply Expense Ratio to working PowerPoint",
                type="primary",
                key="apply_expense_ratio_button",
            ):
                logger = build_logger(
                    "expense_ratio",
                    st.session_state.workflow_logs,
                    callback_for(expense_log_box),
                )

                updated_ppt = apply_expense_ratio(
                    current_ppt_bytes=st.session_state.working_ppt,
                    expense_excel_files=expense_file_inputs,
                    fund_object=FUND_DETAILS_OBJECT,
                    scheme_details_object=SCHEME_DETAILS_OBJECT,
                    logger=logger,
                    strict=strict_expense_ratio,
                )

                set_working_ppt(
                    updated_ppt,
                    "expense_ratio_updated.pptx",
                )
                add_applied_module("Expense Ratio")
                st.success("Expense Ratio applied successfully.")

        except Exception as error:
            st.error(f"Expense Ratio processing failed: {error}")


# -----------------------------------------------------------------------------
# Risk Measures
# -----------------------------------------------------------------------------

if st.session_state.working_ppt and module == "Risk Measures":
    st.subheader("Risk Measures update")

    st.caption(
        "Upload one or more Risk Measures files. The module combines "
        "fund-wise PTO Ratio, Portfolio Yield, Average Maturity, Macaulay "
        "Duration, Modified Duration, Standard Deviation, Beta, and Sharpe "
        "Ratio values before updating MeasuresTable and scheme_details."
    )

    risk_files = st.file_uploader(
        "Upload one or more Risk Measures Excel files",
        type=["xls", "xlsx", "xlsb"],
        accept_multiple_files=True,
        key="risk_measures_files",
        help=(
            "Supported formats: XLS, XLSX and XLSB. Files may contain "
            "different subsets of supported Risk Measures columns."
        ),
    )

    strict_risk_measures = st.checkbox(
        "Stop if a fund, MeasuresTable, or metric row cannot be matched",
        value=False,
        key="strict_risk_measures",
        help=(
            "Enabled: stop on the first missing or ambiguous record. "
            "Disabled: log and skip only the affected fund or metric."
        ),
    )

    if risk_files:
        risk_file_inputs = [
            (uploaded_file.name, uploaded_file.getvalue())
            for uploaded_file in risk_files
        ]

        risk_preview_logs: list[str] = []
        risk_preview_logger = build_logger(
            "risk_measures_preview",
            risk_preview_logs,
            None,
        )

        try:
            risk_records = read_multiple_risk_measures_files(
                excel_files=risk_file_inputs,
                logger=risk_preview_logger,
            )

            st.caption(
                f"{len(risk_files)} file(s) uploaded; "
                f"{len(risk_records)} unique fund record(s) found."
            )

            st.dataframe(
                [
                    {
                        "PowerPoint Fund": record.canonical_fund_name,
                        "Excel Scheme Name": record.excel_fund_name,
                        "Equity Turnover": display_optional_metric(
                            record.pto_ratio
                        ),
                        "Average Maturity": display_optional_metric(
                            record.average_maturity
                        ),
                        "Macaulay Duration": display_optional_metric(
                            record.macaulay_duration
                        ),
                        "Modified Duration": display_optional_metric(
                            record.modified_duration
                        ),
                        "Annualized Portfolio Yield": display_optional_metric(
                            record.portfolio_yield
                        ),
                        "Standard Deviation": display_optional_metric(
                            record.standard_deviation
                        ),
                        "Beta": display_optional_metric(record.beta),
                        "Sharpe Ratio": display_optional_metric(
                            record.sharpe_ratio
                        ),
                        "Source Files": ", ".join(record.source_files),
                    }
                    for record in risk_records.values()
                ],
                hide_index=True,
                use_container_width=True,
            )

            with st.expander("Risk Measures preview logs"):
                st.code(
                    "\n".join(risk_preview_logs) or "No preview logs.",
                    language="text",
                )

            risk_log_box = st.empty()

            if st.button(
                "Apply Risk Measures to working PowerPoint",
                type="primary",
                key="apply_risk_measures_button",
            ):
                logger = build_logger(
                    "risk_measures",
                    st.session_state.workflow_logs,
                    callback_for(risk_log_box),
                )

                updated_ppt = apply_risk_measures(
                    current_ppt_bytes=st.session_state.working_ppt,
                    risk_excel_files=risk_file_inputs,
                    fund_object=FUND_DETAILS_OBJECT,
                    measures_table_object=MEASURES_TABLE_OBJECT,
                    scheme_details_object=SCHEME_DETAILS_OBJECT,
                    logger=logger,
                    strict=strict_risk_measures,
                )

                set_working_ppt(
                    updated_ppt,
                    "risk_measures_updated.pptx",
                )
                add_applied_module("Risk Measures")

                st.success(
                    "Risk Measures applied successfully. Available Equity "
                    "Turnover, Average Maturity, Macaulay Duration, Modified "
                    "Duration, Annualized Portfolio Yield, Standard Deviation, "
                    "Beta and Sharpe Ratio values were updated."
                )

        except Exception as error:
            st.error(f"Risk Measures processing failed: {error}")


# -----------------------------------------------------------------------------
# C. Downloads
# -----------------------------------------------------------------------------

st.divider()
st.subheader("C. Download whenever you are finished")

applied_modules_text = ", ".join(
    st.session_state.applied_modules
) or "None"

st.write("Applied modules:", applied_modules_text)

if st.session_state.working_ppt:
    st.download_button(
        label="Download current/final PowerPoint",
        data=st.session_state.working_ppt,
        file_name=FINAL_OUTPUT_NAME,
        mime=(
            "application/vnd.openxmlformats-officedocument."
            "presentationml.presentation"
        ),
        type="primary",
        key="download_final_ppt",
    )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    st.download_button(
        label="Download complete log",
        data=logs_to_bytes(st.session_state.workflow_logs),
        file_name=f"fund_ppt_{timestamp}.log",
        mime="text/plain",
        key="download_complete_log",
    )


# -----------------------------------------------------------------------------
# Logs
# -----------------------------------------------------------------------------

with st.expander("Logs", expanded=False):
    st.code(
        "\n".join(st.session_state.workflow_logs) or "No logs yet",
        language="text",
    )


# -----------------------------------------------------------------------------
# Reset
# -----------------------------------------------------------------------------

if st.button(
    "Reset working file and logs",
    key="reset_workflow_button",
):
    st.session_state.working_ppt = None
    st.session_state.working_name = ""
    st.session_state.workflow_logs = []
    st.session_state.applied_modules = []
    st.rerun()
