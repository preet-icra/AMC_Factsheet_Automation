FUND_NAME_SHEET = "Sheet1"
FUND_NAME_COLUMN = "scheme details"
FUND_DETAILS_OBJECT = "FundDetails"
SCHEME_DETAILS_OBJECT = "scheme_details"
TEMPLATE_FUND_NAME = "Navi Large & Midcap Fund"
SLIDES_PER_FUND = 4
FINAL_OUTPUT_NAME = "Navi_Final_Fund_Presentation.pptx"


NAV_FUND_NAME_ALIASES = {
    "Navi Ttl Stk Mkt US Specific Eq Pass FoF":
        "Navi US Total Stock Market Fund of Fund",

    "Navi Nasdaq100 US Specific Eq Pass FOF":
        "Navi NASDAQ 100 Fund of Fund",

    "Navi Nifty India Manufacturing Indx Fund":
        "Navi Nifty India Manufacturing Index Fund",
}
# Optional mappings for genuine naming differences between
# the expense-ratio Excel and PowerPoint FundDetails.
#
# This is not tied to any AMC. Add mappings only when the
# same fund has different names in the two sources.
EXPENSE_RATIO_FUND_ALIASES = {
    # "Excel Scheme Name": "PowerPoint FundDetails Name",
}


# Excel heading names.
EXPENSE_RATIO_SCHEME_HEADER = "Scheme Name"
EXPENSE_RATIO_REGULAR_PLAN_HEADER = "Regular Plan"
EXPENSE_RATIO_DIRECT_PLAN_HEADER = "Direct Plan"
EXPENSE_RATIO_BER_HEADER = "Base Expense Ratio (BER) (%)"


# PowerPoint section and row patterns.
EXPENSE_RATIO_SECTION_PATTERN = r"expense\s+ratio\s*:?\s*$"
EXPENSE_RATIO_REGULAR_PATTERN = r"^regular(?:\b|/|\s|-).*"
EXPENSE_RATIO_DIRECT_PATTERN = r"^direct(?:\b|/|\s|-).*"

EXPENSE_RATIO_FUND_ALIASES = {
    "Navi Nifty 500 Multicap 50:25:25 Index Fund":
        "Navi Nifty 500 Multicap 50:25:25 Index",

    "Navi Nifty Smallcap250 Momentum Quality 100 Index Fund":
        "Navi Nifty SmallCap250 Momentum Qlty 100",

    "Navi Nifty Midsmallcap 400 Index Fund":
        "Navi Nifty MidSmallcap 400 Index Fund",
}


MEASURES_TABLE_OBJECT = "MeasuresTable"


# Optional mappings for genuine naming differences between
# the PTO Excel and PowerPoint FundDetails.
#
# Left side  = Excel Scheme Name
# Right side = PowerPoint FundDetails name
#
# Do not hardcode AMC matching inside the module.
RISK_MEASURES_FUND_ALIASES = {
    "Navi Nifty India Manufacturing Indx Fund":
        "Navi Nifty India Manufacturing Index Fund",

    "Navi S&P BSE Sensex Index Fund":
        "Navi BSE Sensex Index Fund",

    "NAVI NIFTY 500 MULTICAP 50:25:25 INDEX FUND":
        "Navi Nifty 500 Multicap 50:25:25 Index",

    "Nifty MidSmallcap 400 Index Fund":
        "Navi Nifty MidSmallcap 400 Index Fund",
}