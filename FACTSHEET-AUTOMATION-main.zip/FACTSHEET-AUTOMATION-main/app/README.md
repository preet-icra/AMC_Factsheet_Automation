# Navi PPT Optional Modules

The app no longer forces Step 1, then Step 2, then Step 3.

You can either:

- upload an existing PPT and run NAV only;
- upload an existing PPT and run AUM/AAUM only;
- create scheme slides and then run any optional module;
- run multiple modules on the same in-memory PPT;
- download whenever finished.

## Run

```bat
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## NAV behavior

- Reads each `.xls` sheet separately.
- Finds the fund name near the top of the sheet.
- Finds `NAV as on ...`.
- Reads `Scheme` and `NAV (in Rs.)` rows below it.
- Matches the PPT `FundDetails` name exactly after case/space normalization.
- Finds `NAV as on` inside the PPT `scheme_details` table.
- Updates the NAV heading, scheme labels, and NAV values.
- Logs every `old --> new` change.
- Stops on NAV row overflow by default to prevent silent data loss.

## NAV capacity behavior

- Checkbox enabled: stop if the XLS has more NAV rows than the current PPT section.
- Checkbox disabled: insert the missing table rows immediately before AUM, copy the NAV row formatting, and paste every Scheme/NAV pair. No NAV rows are truncated.
