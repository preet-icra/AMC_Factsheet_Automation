from __future__ import annotations

import logging
from datetime import datetime
from typing import Callable, Optional

LogCallback = Optional[Callable[[str], None]]


class ListHandler(logging.Handler):
    def __init__(self, records: list[str], callback: LogCallback = None):
        super().__init__()
        self.records = records
        self.callback = callback

    def emit(self, record: logging.LogRecord) -> None:
        message = self.format(record)
        self.records.append(message)
        if self.callback:
            self.callback(message)


def build_logger(
    step_name: str,
    shared_records: list[str],
    callback: LogCallback = None,
) -> logging.Logger:
    logger = logging.getLogger(
        f"navi_workflow.{step_name}.{datetime.now().timestamp()}"
    )
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    handler = ListHandler(shared_records, callback)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logger.addHandler(handler)
    return logger


def logs_to_bytes(records: list[str]) -> bytes:
    return ("\n".join(records) + "\n").encode("utf-8")
