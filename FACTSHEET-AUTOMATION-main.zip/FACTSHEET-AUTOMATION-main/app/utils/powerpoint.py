from __future__ import annotations

MSO_GROUP = 6


def normalize(value: object) -> str:
    return " ".join(str(value or "").strip().split()).casefold()


def find_shape_recursive(shapes, object_name: str):
    target = normalize(object_name)
    for index in range(1, shapes.Count + 1):
        shape = shapes.Item(index)
        if normalize(shape.Name) == target:
            return shape
        if shape.Type == MSO_GROUP:
            found = find_shape_recursive(shape.GroupItems, object_name)
            if found is not None:
                return found
    return None


def shape_texts(shape) -> list[str]:
    texts: list[str] = []
    if shape.HasTable:
        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell = table.Cell(row, column).Shape
                if cell.HasTextFrame and cell.TextFrame.HasText:
                    text = str(cell.TextFrame.TextRange.Text).strip()
                    if text:
                        texts.append(text)
    elif shape.HasTextFrame and shape.TextFrame.HasText:
        text = str(shape.TextFrame.TextRange.Text).strip()
        if text:
            texts.append(text)
    return texts
