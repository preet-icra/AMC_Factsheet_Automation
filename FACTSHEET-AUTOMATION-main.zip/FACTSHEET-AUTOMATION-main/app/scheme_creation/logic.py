from __future__ import annotations

import io
import tempfile
from pathlib import Path

import pandas as pd
import pythoncom
import win32com.client
from openpyxl import load_workbook

from utils.powerpoint import find_shape_recursive, normalize

PP_SAVE_AS_OPEN_XML_PRESENTATION = 24


def _unique_headers(values: list[object]) -> list[str]:
    seen: dict[str, int] = {}
    result: list[str] = []
    for index, value in enumerate(values, start=1):
        base = str(value or "").strip() or f"Column_{index}"
        seen[base] = seen.get(base, 0) + 1
        result.append(base if seen[base] == 1 else f"{base}_{seen[base]}")
    return result


def read_fund_names(excel_bytes: bytes, sheet_name: str, fund_column: str, logger) -> pd.DataFrame:
    """Read the authoritative one-column Navi fund-name workbook."""
    logger.info("STEP_1_FUND_FILE_START | bytes=%s", len(excel_bytes))
    workbook = load_workbook(io.BytesIO(excel_bytes), data_only=True, read_only=False)
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"Sheet '{sheet_name}' was not found.")
    worksheet = workbook[sheet_name]
    rows = [[cell.value for cell in row] for row in worksheet.iter_rows()]
    header_index = next((i for i,row in enumerate(rows) if any(normalize(v)==normalize(fund_column) for v in row)), None)
    if header_index is None:
        raise ValueError(f"Column '{fund_column}' was not found in sheet '{sheet_name}'.")
    headers = _unique_headers(rows[header_index])
    data = pd.DataFrame(rows[header_index+1:], columns=headers)
    actual = next(c for c in data.columns if normalize(c)==normalize(fund_column))
    data = data[data[actual].fillna("").astype(str).str.strip().ne("")].copy()
    data.rename(columns={actual: fund_column}, inplace=True)
    data[fund_column] = data[fund_column].astype(str).str.strip()
    normalized = data[fund_column].map(normalize)
    duplicates = data.loc[normalized.duplicated(keep=False), fund_column].tolist()
    if duplicates:
        raise ValueError("Duplicate fund names: " + ", ".join(duplicates))
    data.reset_index(drop=True, inplace=True)
    logger.info("STEP_1_FUND_FILE_COMPLETE | funds=%s", len(data))
    for i,name in enumerate(data[fund_column],1):
        logger.info("STEP_1_FUND_FOUND | index=%s | fund=%s", i, name)
    return data


def _replace_in_funddetails(shape, old_name: str, new_name: str) -> int:
    changed = 0
    if shape.HasTable:
        table = shape.Table
        for row in range(1, table.Rows.Count + 1):
            for column in range(1, table.Columns.Count + 1):
                cell = table.Cell(row, column).Shape
                if cell.HasTextFrame and cell.TextFrame.HasText:
                    result = cell.TextFrame.TextRange.Replace(
                        FindWhat=old_name,
                        ReplaceWhat=new_name,
                        After=0,
                        MatchCase=False,
                        WholeWords=False,
                    )
                    if result is not None:
                        changed += 1
    elif shape.HasTextFrame and shape.TextFrame.HasText:
        result = shape.TextFrame.TextRange.Replace(
            FindWhat=old_name,
            ReplaceWhat=new_name,
            After=0,
            MatchCase=False,
            WholeWords=False,
        )
        if result is not None:
            changed += 1
    return changed


def create_scheme_presentation(
    template_bytes: bytes,
    selected_funds: pd.DataFrame,
    fund_column: str,
    fund_object: str,
    template_fund_name: str,
    slides_per_fund: int,
    logger,
) -> bytes:
    if selected_funds.empty:
        raise ValueError("Select at least one scheme.")

    logger.info(
        "STEP_1_START | schemes=%s | expected_slides=%s",
        len(selected_funds),
        len(selected_funds) * slides_per_fund,
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_path = Path(temp_dir) / "template.pptx"
            output_path = Path(temp_dir) / "scheme_output.pptx"
            template_path.write_bytes(template_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False
            presentation = powerpoint.Presentations.Open(
                str(template_path.resolve()), False, False, False
            )

            if presentation.Slides.Count != slides_per_fund:
                raise ValueError(
                    f"Template must have {slides_per_fund} slides; "
                    f"found {presentation.Slides.Count}."
                )

            for block in range(2, len(selected_funds) + 1):
                before = presentation.Slides.Count
                presentation.Slides.Range(list(range(1, slides_per_fund + 1))).Copy()
                presentation.Slides.Paste(presentation.Slides.Count + 1)
                logger.info(
                    "STEP_1_BLOCK_COPIED | block=%s | slides=%s --> %s",
                    block,
                    before,
                    presentation.Slides.Count,
                )

            total_changes = 0
            for fund_index, (_, fund) in enumerate(selected_funds.iterrows(), start=1):
                fund_name = str(fund[fund_column]).strip()
                first_slide = (fund_index - 1) * slides_per_fund + 1
                last_slide = first_slide + slides_per_fund - 1
                logger.info(
                    "STEP_1_FUND_START | scheme=%s | slides=%s-%s",
                    fund_name,
                    first_slide,
                    last_slide,
                )

                for slide_number in range(first_slide, last_slide + 1):
                    slide = presentation.Slides.Item(slide_number)
                    shape = find_shape_recursive(slide.Shapes, fund_object)
                    if shape is None:
                        raise ValueError(
                            f"Object '{fund_object}' missing on slide {slide_number}."
                        )

                    changes = _replace_in_funddetails(
                        shape, template_fund_name, fund_name
                    )
                    if changes == 0:
                        raise ValueError(
                            f"Text '{template_fund_name}' not found inside "
                            f"'{fund_object}' on slide {slide_number}."
                        )
                    total_changes += changes
                    logger.info(
                        "STEP_1_FUNDDETAILS_CHANGED | slide=%s | %s --> %s",
                        slide_number,
                        template_fund_name,
                        fund_name,
                    )

            presentation.SaveAs(
                str(output_path.resolve()), PP_SAVE_AS_OPEN_XML_PRESENTATION
            )
            presentation.Close()
            presentation = None
            output = output_path.read_bytes()
            logger.info(
                "STEP_1_COMPLETE | schemes=%s | slides=%s | changes=%s | bytes=%s",
                len(selected_funds),
                len(selected_funds) * slides_per_fund,
                total_changes,
                len(output),
            )
            return output
    except Exception:
        logger.exception("STEP_1_FAILED")
        raise
    finally:
        if presentation is not None:
            presentation.Close()
        if powerpoint is not None:
            powerpoint.Quit()
        pythoncom.CoUninitialize()
