from __future__ import annotations

import io
import re
import tempfile
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import win32com.client
import xlrd
from openpyxl import load_workbook

from config import (
    EXPENSE_RATIO_BER_HEADER,
    EXPENSE_RATIO_DIRECT_PATTERN,
    EXPENSE_RATIO_DIRECT_PLAN_HEADER,
    EXPENSE_RATIO_FUND_ALIASES,
    EXPENSE_RATIO_REGULAR_PATTERN,
    EXPENSE_RATIO_REGULAR_PLAN_HEADER,
    EXPENSE_RATIO_SCHEME_HEADER,
    EXPENSE_RATIO_SECTION_PATTERN,
)
from utils.powerpoint import (
    find_shape_recursive,
    normalize,
    shape_texts,
)


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24


@dataclass(frozen=True)
class ExpenseRatioRecord:
    """
    Fund-wise expense-ratio values read from Excel.
    """

    excel_fund_name: str
    canonical_fund_name: str
    regular_ber: Decimal
    direct_ber: Decimal
    source_file: str


_NORMALIZED_EXPENSE_RATIO_ALIASES = {
    normalize(excel_name): normalize(powerpoint_name)
    for excel_name, powerpoint_name
    in EXPENSE_RATIO_FUND_ALIASES.items()
}


def _canonical_fund_name(
    excel_fund_name: str,
) -> str:
    """
    Convert an Excel scheme name to its configured
    PowerPoint FundDetails name.
    """

    return EXPENSE_RATIO_FUND_ALIASES.get(
        excel_fund_name,
        excel_fund_name,
    )


def _to_decimal(
    value: object,
    field_name: str,
    fund_name: str,
) -> Decimal:
    """
    Convert an Excel value to Decimal without introducing
    additional binary floating-point artifacts.
    """

    if value is None:
        raise ValueError(
            f"Blank {field_name} for '{fund_name}'."
        )

    value_text = str(value).strip()

    if not value_text:
        raise ValueError(
            f"Blank {field_name} for '{fund_name}'."
        )

    try:
        return Decimal(value_text)

    except InvalidOperation as error:
        raise ValueError(
            f"Invalid {field_name} value "
            f"{value!r} for '{fund_name}'."
        ) from error


def format_expense_ratio(
    value: Decimal,
) -> str:
    """
    Format an Excel percentage figure with two decimals.

    Excel value 2.1 means 2.10%, not 210%.
    """

    rounded_value = value.quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )

    return f"{rounded_value:.2f}%"


def _fill_horizontal_headers(
    row_values: list[object],
) -> list:
    """
    Forward-fill merged or blank plan headers.

    Example:

        Regular Plan | blank | blank | Direct Plan | blank

    becomes:

        Regular Plan | Regular Plan | Regular Plan |
        Direct Plan  | Direct Plan
    """

    result: list[str] = []
    current_header = ""

    for value in row_values:
        text = str(
            value or ""
        ).strip()

        if text:
            current_header = text

        result.append(current_header)

    return result


def _find_excel_header_layout(
    rows: list[list[object]],
):
    """
    Detect the multi-row Excel header dynamically.

    Returns:

        data_start_row
        scheme_column
        regular_ber_column
        direct_ber_column
    """

    scheme_target = normalize(
        EXPENSE_RATIO_SCHEME_HEADER
    )

    regular_target = normalize(
        EXPENSE_RATIO_REGULAR_PLAN_HEADER
    )

    direct_target = normalize(
        EXPENSE_RATIO_DIRECT_PLAN_HEADER
    )

    ber_target = normalize(
        EXPENSE_RATIO_BER_HEADER
    )

    for detail_row_index, detail_row in enumerate(rows):
        normalized_detail_row = [
            normalize(value)
            for value in detail_row
        ]

        if ber_target not in normalized_detail_row:
            continue

        # Search a small number of rows above the BER headings
        # for the parent Regular Plan / Direct Plan headers.
        search_start = max(
            0,
            detail_row_index - 3,
        )

        for parent_row_index in range(
            detail_row_index,
            search_start - 1,
            -1,
        ):
            parent_headers = _fill_horizontal_headers(
                rows[parent_row_index]
            )

            normalized_parent_headers = [
                normalize(value)
                for value in parent_headers
            ]

            regular_column = None
            direct_column = None

            for column_index, detail_text in enumerate(
                normalized_detail_row
            ):
                if detail_text != ber_target:
                    continue

                parent_text = (
                    normalized_parent_headers[column_index]
                    if column_index
                    < len(normalized_parent_headers)
                    else ""
                )

                if parent_text == regular_target:
                    regular_column = column_index

                elif parent_text == direct_target:
                    direct_column = column_index

            if (
                regular_column is None
                or direct_column is None
            ):
                continue

            # Scheme Name may occur on either the parent row
            # or the BER detail row.
            scheme_column = None

            for row_index in range(
                search_start,
                detail_row_index + 1,
            ):
                for column_index, value in enumerate(
                    rows[row_index]
                ):
                    if normalize(value) == scheme_target:
                        scheme_column = column_index
                        break

                if scheme_column is not None:
                    break

            if scheme_column is None:
                continue

            return (
                detail_row_index + 1,
                scheme_column,
                regular_column,
                direct_column,
            )

    raise ValueError(
        "Could not identify Scheme Name, Regular Plan BER "
        "and Direct Plan BER columns in the expense-ratio file."
    )


def _read_xlsx_rows(
    excel_bytes: bytes,
) -> list[list[object]]:
    """
    Read rows from an XLSX workbook.
    """

    workbook = load_workbook(
        io.BytesIO(excel_bytes),
        data_only=True,
        read_only=False,
    )

    worksheet = workbook.worksheets[0]

    return [
        list(row)
        for row in worksheet.iter_rows(
            values_only=True
        )
    ]


def _read_xls_rows(
    excel_bytes: bytes,
) -> list[list[object]]:
    """
    Read rows from a legacy XLS workbook.
    """

    workbook = xlrd.open_workbook(
        file_contents=excel_bytes
    )

    worksheet = workbook.sheet_by_index(0)

    return [
        [
            worksheet.cell_value(
                row,
                column,
            )
            for column in range(
                worksheet.ncols
            )
        ]
        for row in range(
            worksheet.nrows
        )
    ]


def _read_excel_rows(
    excel_bytes: bytes,
    file_name: str = "",
) -> list[list[object]]:
    """
    Support both XLS and XLSX expense-ratio files.
    """

    normalized_name = (
        file_name.casefold().strip()
    )

    if normalized_name.endswith(".xlsx"):
        return _read_xlsx_rows(
            excel_bytes
        )

    if normalized_name.endswith(".xls"):
        return _read_xls_rows(
            excel_bytes
        )

    # If no reliable file name was supplied, try XLSX first
    # and fall back to XLS.
    try:
        return _read_xlsx_rows(
            excel_bytes
        )

    except Exception:
        return _read_xls_rows(
            excel_bytes
        )


def read_expense_ratio_excel(
    excel_bytes: bytes,
    logger,
    file_name: str = "",
) -> dict[str, ExpenseRatioRecord]:
    """
    Read fund-wise Regular and Direct BER values.

    This uses column headings and does not depend on AMC names,
    sheet codes, or fixed column numbers.
    """

    logger.info(
        "EXPENSE_RATIO_EXCEL_START | bytes=%s",
        len(excel_bytes),
    )

    rows = _read_excel_rows(
        excel_bytes,
        file_name,
    )

    (
        data_start_row,
        scheme_column,
        regular_ber_column,
        direct_ber_column,
    ) = _find_excel_header_layout(
        rows
    )

    records: dict[
        str,
        ExpenseRatioRecord,
    ] = {}

    required_column = max(
        scheme_column,
        regular_ber_column,
        direct_ber_column,
    )

    for zero_based_row_number in range(
        data_start_row,
        len(rows),
    ):
        row = rows[
            zero_based_row_number
        ]

        if len(row) <= required_column:
            continue

        fund_name = str(
            row[scheme_column]
            or ""
        ).strip()

        if not fund_name:
            continue

        regular_value = row[
            regular_ber_column
        ]

        direct_value = row[
            direct_ber_column
        ]

        # Footnotes appearing after the fund table do not
        # contain both numeric BER values.
        if (
            regular_value in (None, "")
            or direct_value in (None, "")
        ):
            continue

        regular_ber = _to_decimal(
            regular_value,
            "Regular BER",
            fund_name,
        )

        direct_ber = _to_decimal(
            direct_value,
            "Direct BER",
            fund_name,
        )

        excel_key = normalize(
            fund_name
        )

        canonical_name = (
            _canonical_fund_name(
                fund_name
            )
        )

        canonical_key = (
            _NORMALIZED_EXPENSE_RATIO_ALIASES.get(
                excel_key,
                excel_key,
            )
        )

        if canonical_key in records:
            raise ValueError(
                "Duplicate or colliding expense-ratio "
                f"fund: '{fund_name}'."
            )

        records[canonical_key] = ExpenseRatioRecord(
    excel_fund_name=fund_name,
    canonical_fund_name=canonical_name,
    regular_ber=regular_ber,
    direct_ber=direct_ber,
    source_file=(
        file_name
        or "uploaded_expense_ratio_file"
    ),
)

        logger.info(
            (
                "EXPENSE_RATIO_FUND_READ | "
                "row=%s | "
                "excel_fund=%s | "
                "canonical_fund=%s | "
                "regular=%s | "
                "direct=%s"
            ),
            zero_based_row_number + 1,
            fund_name,
            canonical_name,
            format_expense_ratio(
                regular_ber
            ),
            format_expense_ratio(
                direct_ber
            ),
        )

    if not records:
        raise ValueError(
            "No valid fund expense-ratio records were "
            "found in the uploaded Excel file."
        )

    logger.info(
        "EXPENSE_RATIO_EXCEL_COMPLETE | funds=%s",
        len(records),
    )

    return records

def read_multiple_expense_ratio_files(
    excel_files: list[
        tuple[str, bytes]
    ],
    logger,
) -> dict[str, ExpenseRatioRecord]:
    """
    Read and combine multiple Expense Ratio Excel files.

    Each item in excel_files is:

        (
            file_name,
            file_bytes,
        )

    Duplicate policy:

    1. Same fund and same values:
       Keep one record and log the duplicate.

    2. Same fund but different values:
       Stop with an error to prevent silent use
       of the wrong expense ratio.
    """

    if not excel_files:
        raise ValueError(
            "At least one Expense Ratio Excel "
            "file is required."
        )

    combined_records: dict[
        str,
        ExpenseRatioRecord,
    ] = {}

    logger.info(
        (
            "EXPENSE_RATIO_MULTI_FILE_START | "
            "files=%s"
        ),
        len(excel_files),
    )

    for file_number, (
        file_name,
        file_bytes,
    ) in enumerate(
        excel_files,
        start=1,
    ):
        logger.info(
            (
                "EXPENSE_RATIO_FILE_START | "
                "file_number=%s/%s | "
                "file=%s | "
                "bytes=%s"
            ),
            file_number,
            len(excel_files),
            file_name,
            len(file_bytes),
        )

        file_records = (
            read_expense_ratio_excel(
                excel_bytes=file_bytes,
                logger=logger,
                file_name=file_name,
            )
        )

        for canonical_key, new_record in (
            file_records.items()
        ):
            existing_record = (
                combined_records.get(
                    canonical_key
                )
            )

            if existing_record is None:
                combined_records[
                    canonical_key
                ] = new_record

                continue

            same_regular = (
                existing_record.regular_ber
                == new_record.regular_ber
            )

            same_direct = (
                existing_record.direct_ber
                == new_record.direct_ber
            )

            if same_regular and same_direct:
                logger.warning(
                    (
                        "EXPENSE_RATIO_DUPLICATE_IDENTICAL | "
                        "fund=%s | "
                        "first_file=%s | "
                        "duplicate_file=%s | "
                        "regular=%s | "
                        "direct=%s | "
                        "action=kept_first"
                    ),
                    (
                        existing_record
                        .canonical_fund_name
                    ),
                    (
                        existing_record
                        .source_file
                    ),
                    new_record.source_file,
                    format_expense_ratio(
                        existing_record
                        .regular_ber
                    ),
                    format_expense_ratio(
                        existing_record
                        .direct_ber
                    ),
                )

                continue

            raise ValueError(
                "Conflicting Expense Ratio values "
                f"found for "
                f"'{new_record.canonical_fund_name}'. "
                f"File '{existing_record.source_file}' "
                f"contains Regular="
                f"{format_expense_ratio(existing_record.regular_ber)}, "
                f"Direct="
                f"{format_expense_ratio(existing_record.direct_ber)}; "
                f"file '{new_record.source_file}' "
                f"contains Regular="
                f"{format_expense_ratio(new_record.regular_ber)}, "
                f"Direct="
                f"{format_expense_ratio(new_record.direct_ber)}."
            )

        logger.info(
            (
                "EXPENSE_RATIO_FILE_COMPLETE | "
                "file=%s | "
                "funds_read=%s | "
                "combined_funds=%s"
            ),
            file_name,
            len(file_records),
            len(combined_records),
        )

    if not combined_records:
        raise ValueError(
            "No valid expense-ratio records were "
            "found in the uploaded files."
        )

    logger.info(
        (
            "EXPENSE_RATIO_MULTI_FILE_COMPLETE | "
            "files=%s | "
            "combined_funds=%s"
        ),
        len(excel_files),
        len(combined_records),
    )

    return combined_records
def _match_fund(
    fund_shape,
    records: dict[
        str,
        ExpenseRatioRecord,
    ],
):
    """
    Match PowerPoint FundDetails with the canonical
    Excel scheme name.
    """

    for text in shape_texts(
        fund_shape
    ):
        record = records.get(
            normalize(text)
        )

        if record is not None:
            return record

    return None


def _cell_text(
    table,
    row: int,
    column: int,
) -> str:
    """
    Safely read text from a PowerPoint table cell.
    """

    try:
        shape = table.Cell(
            row,
            column,
        ).Shape

    except Exception:
        return ""

    if not shape.HasTextFrame:
        return ""

    return str(
        shape.TextFrame.TextRange.Text
        or ""
    ).strip()


def _matches_pattern(
    value: object,
    pattern: str,
) -> bool:
    """
    Match normalized PowerPoint text against a
    configurable regular expression.
    """

    text = normalize(value)

    return re.search(
        pattern,
        text,
        flags=re.IGNORECASE,
    ) is not None


def _find_expense_ratio_sections(
    table,
) -> list[tuple[int, int, str]]:
    """
    Find visually distinct Expense Ratio headings.

    A merged PowerPoint heading can be exposed through
    several physical table-column coordinates. Matches
    on the same row with the same normalized text are
    treated as one visual section.
    """

    matches: list[
        tuple[int, int, str]
    ] = []

    seen: set[
        tuple[int, str]
    ] = set()

    for row in range(
        1,
        table.Rows.Count + 1,
    ):
        for column in range(
            1,
            table.Columns.Count + 1,
        ):
            text = _cell_text(
                table,
                row,
                column,
            )

            if not text:
                continue

            if not _matches_pattern(
                text,
                EXPENSE_RATIO_SECTION_PATTERN,
            ):
                continue

            normalized_text = normalize(
                text
            )

            identity = (
                row,
                normalized_text,
            )

            if identity in seen:
                continue

            seen.add(identity)

            matches.append(
                (
                    row,
                    column,
                    text,
                )
            )

    return matches
def _row_label_text(
    table,
    row: int,
) -> str:
    """
    Return the first populated text cell in a row.

    Regular and Direct labels are expected on the left,
    but this avoids hardcoding a specific physical column.
    """

    for column in range(
        1,
        table.Columns.Count + 1,
    ):
        text = _cell_text(
            table,
            row,
            column,
        )

        if text:
            return text

    return ""


def _find_plan_rows(
    table,
    heading_row: int,
):
    """
    Locate the first Regular... and Direct... rows
    appearing below the expense-ratio heading.

    Search ends after both rows are found or once a likely
    new section heading appears.
    """

    regular_row = None
    direct_row = None

    max_search_row = min(
        table.Rows.Count,
        heading_row + 8,
    )

    for row in range(
        heading_row + 1,
        max_search_row + 1,
    ):
        label = _row_label_text(
            table,
            row,
        )

        normalized_label = normalize(
            label
        )

        if not normalized_label:
            continue

        if (
            regular_row is None
            and _matches_pattern(
                normalized_label,
                EXPENSE_RATIO_REGULAR_PATTERN,
            )
        ):
            regular_row = row
            continue

        if (
            direct_row is None
            and _matches_pattern(
                normalized_label,
                EXPENSE_RATIO_DIRECT_PATTERN,
            )
        ):
            direct_row = row
            continue

        if (
            regular_row is not None
            and direct_row is not None
        ):
            break

    return regular_row, direct_row


def _find_value_cell(
    table,
    row: int,
):
    """
    Find the right-most populated cell in a plan row.

    This avoids assuming that every template uses
    the same physical value column.
    """

    for column in range(
        table.Columns.Count,
        0,
        -1,
    ):
        try:
            shape = table.Cell(
                row,
                column,
            ).Shape

        except Exception:
            continue

        if not shape.HasTextFrame:
            continue

        value = str(
            shape.TextFrame.TextRange.Text
            or ""
        ).strip()

        if value:
            return shape, column

    # If the value cell is blank, use the physical
    # right-most accessible cell.
    for column in range(
        table.Columns.Count,
        0,
        -1,
    ):
        try:
            return (
                table.Cell(
                    row,
                    column,
                ).Shape,
                column,
            )

        except Exception:
            continue

    raise ValueError(
        f"No accessible value cell found in row {row}."
    )


def _replace_value(
    cell_shape,
    new_text: str,
):
    """
    Replace the complete old expense-ratio value.

    Cell fill, borders, dimensions, placement and other
    table properties remain controlled by PowerPoint.
    """

    text_range = (
        cell_shape
        .TextFrame
        .TextRange
    )

    old_text = str(
        text_range.Text or ""
    )

    text_range.Text = new_text

    return old_text, str(
        text_range.Text
    )


def apply_expense_ratio(
    current_ppt_bytes: bytes,
    expense_excel_files: list[
        tuple[str, bytes]
    ],
    fund_object: str,
    scheme_details_object: str,
    logger,
    strict: bool = False,
) -> bytes:
    """
    Apply Regular and Direct BER values to the current PPT.

    This function is AMC-independent. Matching is based only
    on normalized fund names and optional configured aliases.
    """

    records = (
    read_multiple_expense_ratio_files(
        excel_files=expense_excel_files,
        logger=logger,
    )
)

    logger.info(
        "EXPENSE_RATIO_START | ppt_bytes=%s",
        len(current_ppt_bytes),
    )

    pythoncom.CoInitialize()

    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory(
            ignore_cleanup_errors=True,
        ) as temp_dir:

            input_path = (
                Path(temp_dir)
                / "working.pptx"
            )

            output_path = (
                Path(temp_dir)
                / "expense_ratio_updated.pptx"
            )

            input_path.write_bytes(
                current_ppt_bytes
            )

            powerpoint = (
                win32com.client.DispatchEx(
                    "PowerPoint.Application"
                )
            )

            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False

            try:
                presentation = (
                    powerpoint
                    .Presentations
                    .Open(
                        str(
                            input_path.resolve()
                        ),
                        False,
                        False,
                        False,
                    )
                )

                matched = 0
                unmatched = 0
                changed = 0
                skipped = 0

                for slide_number in range(
                    1,
                    presentation.Slides.Count + 1,
                ):
                    slide = (
                        presentation
                        .Slides
                        .Item(slide_number)
                    )

                    details = (
                        find_shape_recursive(
                            slide.Shapes,
                            scheme_details_object,
                        )
                    )

                    if details is None:
                        continue

                    fund_shape = (
                        find_shape_recursive(
                            slide.Shapes,
                            fund_object,
                        )
                    )

                    if fund_shape is None:
                        logger.warning(
                            (
                                "EXPENSE_RATIO_SLIDE_SKIPPED | "
                                "slide=%s | reason=no %s"
                            ),
                            slide_number,
                            fund_object,
                        )

                        skipped += 1
                        continue

                    record = _match_fund(
                        fund_shape,
                        records,
                    )

                    ppt_fund = " | ".join(
                        shape_texts(
                            fund_shape
                        )
                    )

                    if record is None:
                        unmatched += 1

                        logger.warning(
                            (
                                "EXPENSE_RATIO_FUND_NOT_MATCHED | "
                                "slide=%s | "
                                "ppt_fund=%r"
                            ),
                            slide_number,
                            ppt_fund,
                        )
                        continue

                    if not details.HasTable:
                        message = (
                            f"'{scheme_details_object}' "
                            f"on slide {slide_number} "
                            "is not a table."
                        )

                        if strict:
                            raise ValueError(
                                message
                            )

                        logger.warning(
                            "EXPENSE_RATIO_SLIDE_SKIPPED | %s",
                            message,
                        )

                        skipped += 1
                        continue

                    table = details.Table

                    sections = (
                        _find_expense_ratio_sections(
                            table
                        )
                    )

                    if not sections:
                        message = (
                            "Expense Ratio section was "
                            f"not found on slide {slide_number}."
                        )

                        if strict:
                            raise ValueError(
                                message
                            )

                        logger.warning(
                            (
                                "EXPENSE_RATIO_SECTION_NOT_FOUND | "
                                "slide=%s | fund=%s"
                            ),
                            slide_number,
                            record.canonical_fund_name,
                        )

                        skipped += 1
                        continue

                    if len(sections) > 1:
                        # Prioritize a heading that specifically
                        # starts with Base Expense Ratio.
                        base_sections = [
                            item
                            for item in sections
                            if normalize(
                                item[2]
                            ).startswith(
                                "base expense ratio"
                            )
                        ]

                        if len(base_sections) == 1:
                            section = (
                                base_sections[0]
                            )

                        else:
                            message = (
                                "Multiple Expense Ratio "
                                f"sections found on slide "
                                f"{slide_number}: "
                                f"{[item[2] for item in sections]}"
                            )

                            if strict:
                                raise ValueError(
                                    message
                                )

                            logger.warning(
                                (
                                    "EXPENSE_RATIO_SECTION_AMBIGUOUS | "
                                    "slide=%s | sections=%r"
                                ),
                                slide_number,
                                [
                                    item[2]
                                    for item in sections
                                ],
                            )

                            skipped += 1
                            continue

                    else:
                        section = sections[0]

                    (
                        heading_row,
                        heading_column,
                        heading_text,
                    ) = section

                    regular_row, direct_row = (
                        _find_plan_rows(
                            table,
                            heading_row,
                        )
                    )

                    if regular_row is None:
                        message = (
                            "Regular expense-ratio row "
                            f"was not found on slide "
                            f"{slide_number}."
                        )

                        if strict:
                            raise ValueError(
                                message
                            )

                        logger.warning(
                            (
                                "EXPENSE_RATIO_REGULAR_ROW_NOT_FOUND | "
                                "slide=%s | fund=%s"
                            ),
                            slide_number,
                            record.canonical_fund_name,
                        )

                        skipped += 1
                        continue

                    if direct_row is None:
                        message = (
                            "Direct expense-ratio row "
                            f"was not found on slide "
                            f"{slide_number}."
                        )

                        if strict:
                            raise ValueError(
                                message
                            )

                        logger.warning(
                            (
                                "EXPENSE_RATIO_DIRECT_ROW_NOT_FOUND | "
                                "slide=%s | fund=%s"
                            ),
                            slide_number,
                            record.canonical_fund_name,
                        )

                        skipped += 1
                        continue

                    matched += 1

                    logger.info(
                        (
                            "EXPENSE_RATIO_SECTION_FOUND | "
                            "slide=%s | "
                            "fund=%s | "
                            "heading=%s | "
                            "cell=%s,%s | "
                            "regular_row=%s | "
                            "direct_row=%s"
                        ),
                        slide_number,
                        record.canonical_fund_name,
                        heading_text,
                        heading_row,
                        heading_column,
                        regular_row,
                        direct_row,
                    )

                    regular_cell, regular_column = (
                        _find_value_cell(
                            table,
                            regular_row,
                        )
                    )

                    direct_cell, direct_column = (
                        _find_value_cell(
                            table,
                            direct_row,
                        )
                    )

                    (
                        old_regular,
                        new_regular,
                    ) = _replace_value(
                        regular_cell,
                        format_expense_ratio(
                            record.regular_ber
                        ),
                    )

                    changed += 1

                    logger.info(
                        (
                            "EXPENSE_RATIO_REGULAR_CHANGED | "
                            "fund=%s | "
                            "slide=%s | "
                            "cell=%s,%s | "
                            "%s --> %s"
                        ),
                        record.canonical_fund_name,
                        slide_number,
                        regular_row,
                        regular_column,
                        old_regular,
                        new_regular,
                    )

                    (
                        old_direct,
                        new_direct,
                    ) = _replace_value(
                        direct_cell,
                        format_expense_ratio(
                            record.direct_ber
                        ),
                    )

                    changed += 1

                    logger.info(
                        (
                            "EXPENSE_RATIO_DIRECT_CHANGED | "
                            "fund=%s | "
                            "slide=%s | "
                            "cell=%s,%s | "
                            "%s --> %s"
                        ),
                        record.canonical_fund_name,
                        slide_number,
                        direct_row,
                        direct_column,
                        old_direct,
                        new_direct,
                    )

                presentation.SaveAs(
                    str(
                        output_path.resolve()
                    ),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                )

                presentation.Close()
                presentation = None

                output = (
                    output_path.read_bytes()
                )

                logger.info(
                    (
                        "EXPENSE_RATIO_COMPLETE | "
                        "matched=%s | "
                        "unmatched=%s | "
                        "values_changed=%s | "
                        "skipped=%s | "
                        "bytes=%s"
                    ),
                    matched,
                    unmatched,
                    changed,
                    skipped,
                    len(output),
                )

                return output

            finally:
                # Close the COM objects before the temporary
                # directory attempts to delete working.pptx.
                if presentation is not None:
                    try:
                        presentation.Close()
                    except Exception:
                        pass

                    presentation = None

                if powerpoint is not None:
                    try:
                        powerpoint.Quit()
                    except Exception:
                        pass

                    powerpoint = None

    except Exception:
        logger.exception(
            "EXPENSE_RATIO_FAILED"
        )
        raise

    finally:
        pythoncom.CoUninitialize()