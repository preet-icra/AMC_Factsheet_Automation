FUND_NAME_SHEET = "Sheet1"
FUND_NAME_COLUMN = "scheme details"
FUND_DETAILS_OBJECT = "FundDetails"
SCHEME_DETAILS_OBJECT = "scheme_details"
TEMPLATE_FUND_NAME = "Navi Large & Midcap Fund"
SLIDES_PER_FUND = 4
FINAL_OUTPUT_NAME = "Navi_Final_Fund_Presentation.pptx"


NAV_FUND_NAME_ALIASES = {
    "Navi Ttl Stk Mkt US Specific Eq Pass FoF": "Navi US Total Stock Market Fund of Fund",
    "Navi Nasdaq100 US Specific Eq Pass FOF": "Navi NASDAQ 100 Fund of Fund",
    "Navi Nifty India Manufacturing Indx Fund": "Navi Nifty India Manufacturing Index Fund",
}
