from __future__ import annotations

import io
import re
import tempfile
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import pythoncom
import win32com.client
import xlrd
from openpyxl import load_workbook
from pyxlsb import open_workbook as open_xlsb_workbook

from config import RISK_MEASURES_FUND_ALIASES
from utils.powerpoint import find_shape_recursive, normalize, shape_texts


PP_SAVE_AS_OPEN_XML_PRESENTATION = 24


@dataclass(frozen=True)
class RiskMeasureRecord:
    """All available risk-measure values for one fund."""

    excel_fund_name: str
    canonical_fund_name: str
    source_files: tuple[str, ...]
    pto_ratio: Decimal | None = None
    portfolio_yield: Decimal | None = None
    average_maturity: Decimal | None = None
    macaulay_duration: Decimal | None = None
    modified_duration: Decimal | None = None
    standard_deviation: Decimal | None = None
    beta: Decimal | None = None
    sharpe_ratio: Decimal | None = None


@dataclass(frozen=True)
class PowerPointMetric:
    """Mapping between a record attribute and a PowerPoint row."""

    attribute: str
    display_name: str
    row_patterns: tuple[str, ...]


NORMALIZED_RISK_MEASURE_ALIASES = {
    normalize(excel_name): normalize(powerpoint_name)
    for excel_name, powerpoint_name in RISK_MEASURES_FUND_ALIASES.items()
}

SCHEME_HEADER_ALIASES = {
    "scheme",
    "scheme name",
    "fund",
    "fund name",
}

RISK_MEASURE_HEADER_ALIASES = {
    "pto_ratio": {
        "pto ratio",
        "portfolio turnover ratio",
        "portfolio turnover",
    },
    "portfolio_yield": {
        "portfolio yield",
        "annualized portfolio yield",
        "annualised portfolio yield",
    },
    "average_maturity": {
        "avg mat. (yrs)",
        "avg mat (yrs)",
        "avg maturity (yrs)",
        "average maturity",
        "average maturity (years)",
        "average maturity years",
    },
    "macaulay_duration": {
        "macaulay duration(yrs)",
        "macaulay duration (yrs)",
        "macaulay duration",
        "macaulay duration (years)",
        "macaulay duration years",
    },
    "modified_duration": {
        "mod. dur (yrs)",
        "mod dur (yrs)",
        "modified duration",
        "modified duration (yrs)",
        "modified duration (years)",
    },
    "standard_deviation": {
        "std.dev.", "std. dev.", "std dev", "standard deviation",
        "standard deviation (%)",
    },
    "beta": {"beta"},
    "sharpe_ratio": {
        "sharpe", "sharpe ratio", "sharpe ratio (%)",
    },
}

POWERPOINT_RISK_METRICS = (
    PowerPointMetric(
        attribute="pto_ratio",
        display_name="Equity Turnover",
        row_patterns=(
            r"^equity\s+turnover(?:\s+ratio)?\s*:?\s*$",
        ),
    ),
    PowerPointMetric(
        attribute="average_maturity",
        display_name="Average Maturity",
        row_patterns=(
            r"^average\s+maturity(?:\s*\(years?\))?\s*:?\s*$",
            r"^avg\.?\s+maturity(?:\s*\(years?\))?\s*:?\s*$",
        ),
    ),
    PowerPointMetric(
        attribute="macaulay_duration",
        display_name="Macaulay Duration",
        row_patterns=(
            r"^macaulay\s+duration(?:\s*\(years?\))?\s*:?\s*$",
        ),
    ),
    PowerPointMetric(
        attribute="modified_duration",
        display_name="Modified Duration",
        row_patterns=(
            r"^modified\s+duration(?:\s*\(%\))?\s*:?\s*$",
            r"^modified\s+duration(?:\s*\(years?\))?\s*:?\s*$",
            r"^mod\.?\s+dur(?:ation)?(?:\s*\(years?\))?\s*:?\s*$",
        ),
    ),
    PowerPointMetric(
        attribute="portfolio_yield",
        display_name="Annualized Portfolio Yield",
        row_patterns=(
            r"^annualized\s+portfolio\s+yield\s*:?\s*$",
            r"^annualised\s+portfolio\s+yield\s*:?\s*$",
            r"^portfolio\s+yield\s*:?\s*$",
        ),
    ),    PowerPointMetric(
        attribute="standard_deviation",
        display_name="Standard Deviation",
        row_patterns=(
            r"^standard\s+deviation(?:\s*\(%\))?\s*:?\s*$",
            r"^std\.?\s*dev\.?(?:\s*\(%\))?\s*:?\s*$",
        ),
    ),
    PowerPointMetric(
        attribute="beta",
        display_name="Beta",
        row_patterns=(r"^beta\s*:?\s*$",),
    ),
    PowerPointMetric(
        attribute="sharpe_ratio",
        display_name="Sharpe Ratio",
        row_patterns=(
            r"^sharpe\s+ratio(?:\s*\(%\))?\s*:?\s*$",
            r"^sharpe\s*:?\s*$",
        ),
    ),
)


def _canonical_fund_name(excel_fund_name: str) -> str:
    """Remove plan/option suffixes, then apply configured naming aliases."""
    cleaned = re.sub(
        r"\s*-\s*(?:dir(?:ect)?|reg(?:ular)?)\s*-\s*(?:growth|dividend).*$",
        "",
        excel_fund_name,
        flags=re.IGNORECASE,
    ).strip()
    return RISK_MEASURES_FUND_ALIASES.get(cleaned, cleaned)


def _to_decimal(value: object, field_name: str, fund_name: str) -> Decimal:
    if value is None:
        raise ValueError(f"Blank {field_name} for '{fund_name}'.")

    value_text = str(value).strip()
    if not value_text:
        raise ValueError(f"Blank {field_name} for '{fund_name}'.")

    if value_text.endswith("%"):
        value_text = value_text[:-1].strip()

    value_text = value_text.replace(",", "")

    try:
        return Decimal(value_text)
    except InvalidOperation as error:
        raise ValueError(
            f"Invalid {field_name} value {value!r} for '{fund_name}'."
        ) from error


def format_risk_measure(value: Decimal) -> str:
    """Format every risk measure with exactly two decimal places."""
    rounded = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return f"{rounded:.2f}"


def format_pto_ratio(value: Decimal) -> str:
    """Backward-compatible PTO formatter used by app.py."""
    return format_risk_measure(value)


def _format_optional(value: Decimal | None) -> str:
    if value is None:
        return "<not provided>"
    return format_risk_measure(value)


def _clean_header(value: object) -> str:
    text = str(value or "")
    text = text.replace("\u00a0", " ").replace("\r", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return normalize(text)


def _read_xlsx_sheets(file_bytes: bytes) -> list[tuple[str, list[list[object]]]]:
    workbook = load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=False)
    return [
        (
            worksheet.title,
            [list(row) for row in worksheet.iter_rows(values_only=True)],
        )
        for worksheet in workbook.worksheets
    ]


def _read_xls_sheets(file_bytes: bytes) -> list[tuple[str, list[list[object]]]]:
    workbook = xlrd.open_workbook(file_contents=file_bytes)
    sheets: list[tuple[str, list[list[object]]]] = []

    for worksheet in workbook.sheets():
        rows = [
            [worksheet.cell_value(row, column) for column in range(worksheet.ncols)]
            for row in range(worksheet.nrows)
        ]
        sheets.append((worksheet.name, rows))

    return sheets


def _read_xlsb_sheets(file_bytes: bytes) -> list[tuple[str, list[list[object]]]]:
    temporary_path: Path | None = None

    try:
        with tempfile.NamedTemporaryFile(suffix=".xlsb", delete=False) as temporary_file:
            temporary_file.write(file_bytes)
            temporary_path = Path(temporary_file.name)

        sheets: list[tuple[str, list[list[object]]]] = []

        with open_xlsb_workbook(str(temporary_path)) as workbook:
            for sheet_name in workbook.sheets:
                rows: list[list[object]] = []
                with workbook.get_sheet(sheet_name) as worksheet:
                    for row in worksheet.rows():
                        rows.append([cell.v for cell in row])
                sheets.append((sheet_name, rows))

        return sheets
    except Exception as error:
        raise ValueError(
            "Unable to read the XLSB Risk Measures workbook. "
            "Confirm that it is a valid Excel Binary Workbook."
        ) from error
    finally:
        if temporary_path is not None and temporary_path.exists():
            try:
                temporary_path.unlink()
            except Exception:
                pass


def _read_excel_sheets(
    file_bytes: bytes,
    file_name: str = "",
) -> list[tuple[str, list[list[object]]]]:
    normalized_name = file_name.casefold().strip()

    if normalized_name.endswith(".xlsx"):
        return _read_xlsx_sheets(file_bytes)
    if normalized_name.endswith(".xlsb"):
        return _read_xlsb_sheets(file_bytes)
    if normalized_name.endswith(".xls"):
        return _read_xls_sheets(file_bytes)

    errors: list[tuple[str, str]] = []
    for reader_name, reader in (
        ("XLSX", _read_xlsx_sheets),
        ("XLS", _read_xls_sheets),
        ("XLSB", _read_xlsb_sheets),
    ):
        try:
            return reader(file_bytes)
        except Exception as error:
            errors.append((reader_name, str(error)))

    raise ValueError(
        "The uploaded Risk Measures file could not be read as XLS, XLSX or "
        f"XLSB. Reader errors: {errors!r}"
    )


def _find_header_layout(
    rows: list[list[object]],
) -> tuple[int, int, dict[str, int]]:
    normalized_scheme_headers = {_clean_header(value) for value in SCHEME_HEADER_ALIASES}
    normalized_metric_headers = {
        metric_name: {_clean_header(alias) for alias in aliases}
        for metric_name, aliases in RISK_MEASURE_HEADER_ALIASES.items()
    }

    for row_index, row in enumerate(rows):
        normalized_cells = [_clean_header(value) for value in row]
        scheme_column = None
        metric_columns: dict[str, int] = {}

        for column_index, text in enumerate(normalized_cells):
            if text in normalized_scheme_headers:
                scheme_column = column_index

            for metric_name, accepted_headers in normalized_metric_headers.items():
                if text in accepted_headers:
                    metric_columns[metric_name] = column_index

        if scheme_column is not None and metric_columns:
            return row_index + 1, scheme_column, metric_columns

    raise ValueError(
        "No supported Risk Measures header was found. The sheet must contain "
        "Scheme or Scheme Name and at least one of: PTO Ratio, Portfolio Yield, "
        "Avg Mat. (yrs), Macaulay Duration(Yrs), Mod. Dur (Yrs), "
        "Std.Dev., Beta, Sharpe, or Sharpe Ratio."
    )


def _optional_decimal(
    row: list[object],
    column: int | None,
    field_name: str,
    fund_name: str,
) -> Decimal | None:
    if column is None or column >= len(row):
        return None

    value = row[column]
    if value in (None, ""):
        return None

    return _to_decimal(value, field_name, fund_name)


def _read_sheet_records(
    rows: list[list[object]],
    source_file: str,
    sheet_name: str,
    logger,
) -> dict[str, RiskMeasureRecord]:
    logger.info(
        "RISK_MEASURES_SHEET_INSPECTED | file=%s | sheet=%s | "
        "rows=%s | max_columns=%s",
        source_file,
        sheet_name,
        len(rows),
        max((len(row) for row in rows), default=0),
    )

    data_start_row, scheme_column, metric_columns = _find_header_layout(rows)

    logger.info(
        "RISK_MEASURES_HEADERS_FOUND | file=%s | sheet=%s | "
        "scheme_column=%s | metrics=%r",
        source_file,
        sheet_name,
        scheme_column,
        metric_columns,
    )

    records: dict[str, RiskMeasureRecord] = {}

    for row_index in range(data_start_row, len(rows)):
        row = rows[row_index]
        if scheme_column >= len(row):
            continue

        scheme_name = str(row[scheme_column] or "").strip()
        if not scheme_name:
            continue

        normalized_scheme_name = normalize(scheme_name)
        has_plan_suffix = re.search(
            r"\s*-\s*(?:dir(?:ect)?|reg(?:ular)?)(?:\s+plan)?"
            r"\s*-\s*(?:growth|dividend)(?:\s+option)?(?:\s*-.*)?$",
            scheme_name,
            flags=re.IGNORECASE,
        ) is not None

        # Statistical exports place benchmark rows between scheme rows.
        # Skip benchmark rows before parsing values such as Beta='--'.
        is_benchmark = (
            "suitable index" in normalized_scheme_name
            or normalized_scheme_name.endswith(" tri")
            or normalized_scheme_name.startswith("nifty ")
            or normalized_scheme_name.startswith("crisil ")
            or normalized_scheme_name.startswith("bse ")
        )
        if is_benchmark and not has_plan_suffix:
            logger.debug(
                "RISK_MEASURES_BENCHMARK_SKIPPED | file=%s | sheet=%s | "
                "row=%s | name=%r",
                source_file,
                sheet_name,
                row_index + 1,
                scheme_name,
            )
            continue

        pto_ratio = _optional_decimal(
            row, metric_columns.get("pto_ratio"), "PTO Ratio", scheme_name
        )
        portfolio_yield = _optional_decimal(
            row, metric_columns.get("portfolio_yield"), "Portfolio Yield", scheme_name
        )
        average_maturity = _optional_decimal(
            row, metric_columns.get("average_maturity"), "Average Maturity", scheme_name
        )
        macaulay_duration = _optional_decimal(
            row, metric_columns.get("macaulay_duration"), "Macaulay Duration", scheme_name
        )
        modified_duration = _optional_decimal(
            row, metric_columns.get("modified_duration"), "Modified Duration", scheme_name
        )
        standard_deviation = _optional_decimal(
            row, metric_columns.get("standard_deviation"), "Standard Deviation", scheme_name
        )
        beta = _optional_decimal(
            row, metric_columns.get("beta"), "Beta", scheme_name
        )
        sharpe_ratio = _optional_decimal(
            row, metric_columns.get("sharpe_ratio"), "Sharpe Ratio", scheme_name
        )

        if all(
            value is None
            for value in (
                pto_ratio,
                portfolio_yield,
                average_maturity,
                macaulay_duration,
                modified_duration,
                standard_deviation,
                beta,
                sharpe_ratio,
            )
        ):
            continue

        excel_key = normalize(scheme_name)
        canonical_name = _canonical_fund_name(scheme_name)
        canonical_key = normalize(canonical_name)

        if canonical_key in records:
            raise ValueError(
                f"Duplicate Risk Measures scheme '{scheme_name}' in "
                f"'{source_file}', sheet '{sheet_name}'."
            )

        records[canonical_key] = RiskMeasureRecord(
            excel_fund_name=scheme_name,
            canonical_fund_name=canonical_name,
            source_files=(source_file,),
            pto_ratio=pto_ratio,
            portfolio_yield=portfolio_yield,
            average_maturity=average_maturity,
            macaulay_duration=macaulay_duration,
            modified_duration=modified_duration,
            standard_deviation=standard_deviation,
            beta=beta,
            sharpe_ratio=sharpe_ratio,
        )

        if canonical_key != excel_key:
            logger.info(
                "RISK_MEASURES_ALIAS_APPLIED | excel_fund=%s | canonical_fund=%s",
                scheme_name,
                canonical_name,
            )

        logger.info(
            "RISK_MEASURES_FUND_READ | file=%s | sheet=%s | row=%s | "
            "excel_fund=%s | canonical_fund=%s | pto=%s | "
            "portfolio_yield=%s | average_maturity=%s | "
            "macaulay_duration=%s | modified_duration=%s | "
            "standard_deviation=%s | beta=%s | sharpe_ratio=%s",
            source_file,
            sheet_name,
            row_index + 1,
            scheme_name,
            canonical_name,
            _format_optional(pto_ratio),
            _format_optional(portfolio_yield),
            _format_optional(average_maturity),
            _format_optional(macaulay_duration),
            _format_optional(modified_duration),
            _format_optional(standard_deviation),
            _format_optional(beta),
            _format_optional(sharpe_ratio),
        )

    return records


def _merge_metric(
    fund_name: str,
    metric_name: str,
    existing_value: Decimal | None,
    new_value: Decimal | None,
    existing_sources: tuple[str, ...],
    new_source: str,
) -> Decimal | None:
    if new_value is None:
        return existing_value
    if existing_value is None:
        return new_value
    if existing_value == new_value:
        return existing_value

    raise ValueError(
        f"Conflicting {metric_name} values found for '{fund_name}'. Existing "
        f"source(s) {existing_sources!r} contain "
        f"{format_risk_measure(existing_value)}, while '{new_source}' contains "
        f"{format_risk_measure(new_value)}."
    )


def _merge_records(
    existing: RiskMeasureRecord,
    new: RiskMeasureRecord,
) -> RiskMeasureRecord:
    new_source = new.source_files[0] if new.source_files else "<unknown>"
    combined_sources = tuple(dict.fromkeys(existing.source_files + new.source_files))
    fund_name = existing.canonical_fund_name

    return RiskMeasureRecord(
        excel_fund_name=existing.excel_fund_name,
        canonical_fund_name=fund_name,
        source_files=combined_sources,
        pto_ratio=_merge_metric(
            fund_name, "PTO Ratio", existing.pto_ratio, new.pto_ratio,
            existing.source_files, new_source,
        ),
        portfolio_yield=_merge_metric(
            fund_name, "Portfolio Yield", existing.portfolio_yield,
            new.portfolio_yield, existing.source_files, new_source,
        ),
        average_maturity=_merge_metric(
            fund_name, "Average Maturity", existing.average_maturity,
            new.average_maturity, existing.source_files, new_source,
        ),
        macaulay_duration=_merge_metric(
            fund_name, "Macaulay Duration", existing.macaulay_duration,
            new.macaulay_duration, existing.source_files, new_source,
        ),
        modified_duration=_merge_metric(
            fund_name, "Modified Duration", existing.modified_duration,
            new.modified_duration, existing.source_files, new_source,
        ),
        standard_deviation=_merge_metric(
            fund_name, "Standard Deviation", existing.standard_deviation,
            new.standard_deviation, existing.source_files, new_source,
        ),
        beta=_merge_metric(
            fund_name, "Beta", existing.beta,
            new.beta, existing.source_files, new_source,
        ),
        sharpe_ratio=_merge_metric(
            fund_name, "Sharpe Ratio", existing.sharpe_ratio,
            new.sharpe_ratio, existing.source_files, new_source,
        ),
    )


def read_risk_measures_excel(
    file_bytes: bytes,
    logger,
    file_name: str = "",
) -> dict[str, RiskMeasureRecord]:
    source_file = file_name or "uploaded_risk_measures_file"

    logger.info(
        "RISK_MEASURES_EXCEL_START | file=%s | bytes=%s",
        source_file,
        len(file_bytes),
    )

    combined: dict[str, RiskMeasureRecord] = {}
    supported_sheet_count = 0

    for sheet_name, rows in _read_excel_sheets(file_bytes, file_name):
        try:
            sheet_records = _read_sheet_records(
                rows=rows,
                source_file=source_file,
                sheet_name=sheet_name,
                logger=logger,
            )
        except ValueError as error:
            logger.debug(
                "RISK_MEASURES_SHEET_SKIPPED | file=%s | sheet=%s | reason=%s",
                source_file,
                sheet_name,
                error,
            )
            continue

        supported_sheet_count += 1

        for canonical_key, new_record in sheet_records.items():
            existing = combined.get(canonical_key)
            combined[canonical_key] = (
                new_record if existing is None else _merge_records(existing, new_record)
            )

    if not combined:
        raise ValueError(
            f"No valid Risk Measures records were found in '{source_file}'. "
            "No worksheet contained a supported header layout."
        )

    logger.info(
        "RISK_MEASURES_EXCEL_COMPLETE | file=%s | sheets=%s | funds=%s",
        source_file,
        supported_sheet_count,
        len(combined),
    )
    return combined


def read_multiple_risk_measures_files(
    excel_files: list[tuple[str, bytes]],
    logger,
) -> dict[str, RiskMeasureRecord]:
    if not excel_files:
        raise ValueError("At least one Risk Measures Excel file is required.")

    combined_records: dict[str, RiskMeasureRecord] = {}

    logger.info("RISK_MEASURES_MULTI_FILE_START | files=%s", len(excel_files))

    for file_number, (file_name, file_bytes) in enumerate(excel_files, start=1):
        logger.info(
            "RISK_MEASURES_FILE_START | file_number=%s/%s | file=%s | bytes=%s",
            file_number,
            len(excel_files),
            file_name,
            len(file_bytes),
        )

        file_records = read_risk_measures_excel(
            file_bytes=file_bytes,
            logger=logger,
            file_name=file_name,
        )

        for canonical_key, new_record in file_records.items():
            existing_record = combined_records.get(canonical_key)
            if existing_record is None:
                combined_records[canonical_key] = new_record
            else:
                merged = _merge_records(existing_record, new_record)
                combined_records[canonical_key] = merged
                logger.info(
                    "RISK_MEASURES_RECORDS_MERGED | fund=%s | sources=%r | "
                    "pto=%s | portfolio_yield=%s | average_maturity=%s | "
                    "macaulay_duration=%s | modified_duration=%s | "
                    "standard_deviation=%s | beta=%s | sharpe_ratio=%s",
                    merged.canonical_fund_name,
                    merged.source_files,
                    _format_optional(merged.pto_ratio),
                    _format_optional(merged.portfolio_yield),
                    _format_optional(merged.average_maturity),
                    _format_optional(merged.macaulay_duration),
                    _format_optional(merged.modified_duration),
                    _format_optional(merged.standard_deviation),
                    _format_optional(merged.beta),
                    _format_optional(merged.sharpe_ratio),
                )

        logger.info(
            "RISK_MEASURES_FILE_COMPLETE | file=%s | funds_read=%s | "
            "combined_funds=%s",
            file_name,
            len(file_records),
            len(combined_records),
        )

    logger.info(
        "RISK_MEASURES_MULTI_FILE_COMPLETE | files=%s | combined_funds=%s",
        len(excel_files),
        len(combined_records),
    )
    return combined_records


def _match_fund(
    fund_shape,
    records: dict[str, RiskMeasureRecord],
) -> RiskMeasureRecord | None:
    for text in shape_texts(fund_shape):
        record = records.get(normalize(text))
        if record is not None:
            return record
    return None


def _get_cell(table, row: int, column: int):
    try:
        return table.Cell(row, column)
    except Exception:
        return None


def _cell_text(table, row: int, column: int) -> str:
    cell = _get_cell(table, row, column)
    if cell is None:
        return ""

    shape = cell.Shape
    if not shape.HasTextFrame:
        return ""

    return str(shape.TextFrame.TextRange.Text or "").strip()


def _clean_powerpoint_label(value: object) -> str:
    text = normalize(value)
    text = re.sub(
        r"^[a-z0-9]+\s*[\)\.\-:]\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )
    return text.strip()


def _matches_metric_label(value: object, patterns: tuple[str, ...]) -> bool:
    text = _clean_powerpoint_label(value)
    if not text:
        return False
    return any(
        re.match(pattern, text, flags=re.IGNORECASE) is not None
        for pattern in patterns
    )


def _find_metric_rows(
    table,
    patterns: tuple[str, ...],
) -> list[tuple[int, int, str]]:
    matches: list[tuple[int, int, str]] = []
    seen_rows: set[int] = set()

    for row in range(1, table.Rows.Count + 1):
        for column in range(1, table.Columns.Count + 1):
            text = _cell_text(table, row, column)
            if not _matches_metric_label(text, patterns):
                continue
            if row in seen_rows:
                continue
            seen_rows.add(row)
            matches.append((row, column, text))

    return matches


def _find_value_cell_on_right(table, row: int, label_column: int):
    # Prefer a populated cell to the right of the label.
    for column in range(table.Columns.Count, label_column, -1):
        cell = _get_cell(table, row, column)
        if cell is None:
            continue
        shape = cell.Shape
        if not shape.HasTextFrame:
            continue
        if str(shape.TextFrame.TextRange.Text or "").strip():
            return shape, column

    # Otherwise use the right-most accessible blank text cell.
    for column in range(table.Columns.Count, label_column, -1):
        cell = _get_cell(table, row, column)
        if cell is not None and cell.Shape.HasTextFrame:
            return cell.Shape, column

    raise ValueError(
        f"No value cell was found to the right of the label on table row {row}."
    )


def _replace_cell_text(cell_shape, new_text: str) -> tuple[str, str]:
    text_range = cell_shape.TextFrame.TextRange
    old_text = str(text_range.Text or "")
    text_range.Text = new_text
    return old_text, str(text_range.Text)


def _update_available_metrics(
    measures_table,
    scheme_details_table,
    record: RiskMeasureRecord,
    slide_number: int,
    logger,
    strict: bool,
) -> tuple[int, int]:
    values_changed = 0
    values_skipped = 0

    for metric in POWERPOINT_RISK_METRICS:
        value = getattr(record, metric.attribute)
        if value is None:
            continue

        target_table = (
            scheme_details_table
            if metric.attribute in {"standard_deviation", "beta", "sharpe_ratio"}
            else measures_table
        )
        target_name = (
            "scheme_details"
            if metric.attribute in {"standard_deviation", "beta", "sharpe_ratio"}
            else "MeasuresTable"
        )
        if target_table is None:
            if strict:
                raise ValueError(f"{target_name} is missing on slide {slide_number}.")
            logger.warning(
                "RISK_MEASURES_TARGET_MISSING | slide=%s | fund=%s | target=%s | metric=%s",
                slide_number, record.canonical_fund_name, target_name, metric.display_name,
            )
            values_skipped += 1
            continue
        matches = _find_metric_rows(target_table, metric.row_patterns)

        if not matches:
            message = (
                f"{metric.display_name} row was not found in {target_name} "
                f"on slide {slide_number}."
            )
            if strict:
                raise ValueError(message)
            logger.warning(
                "RISK_MEASURES_ROW_NOT_FOUND | slide=%s | fund=%s | metric=%s",
                slide_number,
                record.canonical_fund_name,
                metric.display_name,
            )
            values_skipped += 1
            continue

        if len(matches) > 1:
            message = (
                f"Multiple {metric.display_name} rows were found on slide "
                f"{slide_number}: {matches!r}"
            )
            if strict:
                raise ValueError(message)
            logger.warning(
                "RISK_MEASURES_ROW_AMBIGUOUS | slide=%s | fund=%s | "
                "metric=%s | matches=%r",
                slide_number,
                record.canonical_fund_name,
                metric.display_name,
                matches,
            )
            values_skipped += 1
            continue

        metric_row, label_column, label_text = matches[0]
        value_shape, value_column = _find_value_cell_on_right(
            table=target_table,
            row=metric_row,
            label_column=label_column,
        )

        old_text, written_text = _replace_cell_text(
            value_shape,
            format_risk_measure(value),
        )
        values_changed += 1

        logger.info(
            "RISK_MEASURES_VALUE_CHANGED | slide=%s | fund=%s | metric=%s | "
            "label=%r | cell=%s,%s | %s --> %s | sources=%r",
            slide_number,
            record.canonical_fund_name,
            metric.display_name,
            label_text,
            metric_row,
            value_column,
            old_text,
            written_text,
            record.source_files,
        )

    return values_changed, values_skipped


def apply_risk_measures(
    current_ppt_bytes: bytes,
    risk_excel_files: list[tuple[str, bytes]],
    fund_object: str,
    measures_table_object: str,
    scheme_details_object: str,
    logger,
    strict: bool = False,
) -> bytes:
    records = read_multiple_risk_measures_files(
        excel_files=risk_excel_files,
        logger=logger,
    )

    logger.info(
        "RISK_MEASURES_START | ppt_bytes=%s | funds=%s",
        len(current_ppt_bytes),
        len(records),
    )

    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp_dir:
            input_path = Path(temp_dir) / "working.pptx"
            output_path = Path(temp_dir) / "risk_measures_updated.pptx"
            input_path.write_bytes(current_ppt_bytes)

            powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
            powerpoint.Visible = True
            powerpoint.DisplayAlerts = False

            try:
                presentation = powerpoint.Presentations.Open(
                    str(input_path.resolve()),
                    False,
                    False,
                    False,
                )

                matched_funds = 0
                unmatched_funds = 0
                values_changed = 0
                slides_skipped = 0
                values_skipped = 0

                for slide_number in range(1, presentation.Slides.Count + 1):
                    slide = presentation.Slides.Item(slide_number)
                    measures_shape = find_shape_recursive(
                        slide.Shapes,
                        measures_table_object,
                    )
                    scheme_details_shape = find_shape_recursive(
                        slide.Shapes,
                        scheme_details_object,
                    )
                    if measures_shape is None and scheme_details_shape is None:
                        continue

                    fund_shape = find_shape_recursive(slide.Shapes, fund_object)
                    if fund_shape is None:
                        message = (
                            f"'{fund_object}' was not found on slide {slide_number}."
                        )
                        if strict:
                            raise ValueError(message)
                        logger.warning(
                            "RISK_MEASURES_SLIDE_SKIPPED | slide=%s | reason=no %s",
                            slide_number,
                            fund_object,
                        )
                        slides_skipped += 1
                        continue

                    record = _match_fund(fund_shape, records)
                    ppt_fund = " | ".join(shape_texts(fund_shape))

                    if record is None:
                        unmatched_funds += 1
                        logger.warning(
                            "RISK_MEASURES_FUND_NOT_MATCHED | slide=%s | ppt_fund=%r",
                            slide_number,
                            ppt_fund,
                        )
                        if strict:
                            raise ValueError(
                                f"Risk Measures record not found for {ppt_fund!r} "
                                f"on slide {slide_number}."
                            )
                        continue

                    measures_table = (
                        measures_shape.Table
                        if measures_shape is not None and measures_shape.HasTable
                        else None
                    )
                    scheme_details_table = (
                        scheme_details_shape.Table
                        if scheme_details_shape is not None and scheme_details_shape.HasTable
                        else None
                    )

                    fund_changed, fund_skipped = _update_available_metrics(
                        measures_table=measures_table,
                        scheme_details_table=scheme_details_table,
                        record=record,
                        slide_number=slide_number,
                        logger=logger,
                        strict=strict,
                    )

                    if fund_changed:
                        matched_funds += 1
                        values_changed += fund_changed
                    else:
                        slides_skipped += 1

                    values_skipped += fund_skipped

                presentation.SaveAs(
                    str(output_path.resolve()),
                    PP_SAVE_AS_OPEN_XML_PRESENTATION,
                )
                presentation.Close()
                presentation = None

                output = output_path.read_bytes()
                logger.info(
                    "RISK_MEASURES_COMPLETE | matched_funds=%s | "
                    "unmatched_funds=%s | values_changed=%s | "
                    "slides_skipped=%s | values_skipped=%s | bytes=%s",
                    matched_funds,
                    unmatched_funds,
                    values_changed,
                    slides_skipped,
                    values_skipped,
                    len(output),
                )
                return output

            finally:
                if presentation is not None:
                    try:
                        presentation.Close()
                    except Exception:
                        pass
                    presentation = None

                if powerpoint is not None:
                    try:
                        powerpoint.Quit()
                    except Exception:
                        pass
                    powerpoint = None

    except Exception:
        logger.exception("RISK_MEASURES_FAILED")
        raise
    finally:
        pythoncom.CoUninitialize()
