certutil -encode FACTSHEET-AUTOMATION-main.zip FACTSHEET-AUTOMATION-main-base64.txt
